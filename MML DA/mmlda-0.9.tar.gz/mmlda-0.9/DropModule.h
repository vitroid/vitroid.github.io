//	----------------------------------------------------------------------
//	DropModule.h
//
//	Use this header file to support Drag&Drop HACK.
//
//	Call CallModuleGimmic () at default case of starterPilotMain ().
//	And make DropTextFromModuleGimmic () to perform.
//
//		By Shuji Fukumoto		ver.1.1		16 Jun 1998.
//	----------------------------------------------------------------------
//#pragma	once
#ifndef __DROPMODULEH
#define __DROPMODULEH
//#include		<Common.h>

#define		dDropLaunchCmd						(sysAppLaunchCmdCustomBase + 1)
#define		dDropLaunchSupportCmd				(dDropLaunchCmd + 1)

#define		dYes_Support						'DRDP'
#define		dIconResourceType					'DRDP'
#define		dNameResourceType					'DNAM'
#define		dInfoResourceType					'DINF'


#define		dBaseFunctionIconID					1000
#define		dIconResourceSize					((16 / 8) * 16)


//	Use this constant value at DropTextFromModuleGimmic ()'s outBehavior
enum
{
	eBehavior_Do_Nothing	=	0,
	eBehavior_Insert_Before,
	eBehavior_Insert_After,
	eBehavior_Replace
};

typedef	struct
{
	Byte	selector;				//	Function selector ID.
	Word	srcTextLength;			//	Length of source text.
	char	*srcText;				//	Pointer to Memory Block of source text
	Word	resultTextLength;		//	Length of source text.
	char	*resultText;			//	Pointer to Memory Block of result text;
	Byte	resultBehavior;			//	One of eBehavior_
}	tDropLaunchCmdParamRec,	*tDropLaunchCmdParamPtr,	**tDropLaunchCmdParamHdl;



//	--------------------------------------------------------------------------------
//	FUNCTION:		CallModuleGimmic
//
//	DESCRIPTION:	Call this routine at default case of starterPilotMain ().
//	PARAMETERS:		inCmd			- word value specifying the launch code.
//					inCmdPBP		- pointer to a structure that is associated with the launch code. 
//					inLaunchFlags	- word value providing extra information about the launch.
//
//	RETURNED:		Result of launch
//
//	REVISION HISTORY:
//
//	--------------------------------------------------------------------------------
extern	DWord	CallModuleGimmic (Word inCmd, Ptr inCmdPBP, Word inLaunchFlags);

//	--------------------------------------------------------------------------------
//	FUNCTION:		DropTextFromModuleGimmic
//
//	DESCRIPTION:	Callback routine for Drag&Drop HACK.
//					You *SHOULD* create this routine to perform module.
//
//	PARAMETERS:		inModuleNo		:I N:	Module number which called. Begin with 0.
//					inDropTextLen	:I N:	Length of dropped text.
//					inDropText		:I N:	Pointer to dropped text. DO NOT CHANGE THIS TEXT.
//					outResultLen	:OUT:	Length of return text.
//					outResultText	:OUT:	Length of return text.
//					outBehavior		:OUT:	Set how Drag&Drop handled outResultText.
//
//	RETURNED:		Result of launch
//
//	REVISION HISTORY:
//
//	--------------------------------------------------------------------------------
extern	DWord	DropTextFromModuleGimmic (Word inModuleNo, Word inDropTextLen, Ptr inDropText, Word *outResultLen, Ptr *outResultText, Byte *outBehavior);
#endif /*__DROPMODULEH*/
