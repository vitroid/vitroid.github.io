#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#define DWord UInt32
#define Ptr void *
#define Byte Char
#define Word UInt16
#include "DropModule.h"
#include "mmlparser.h"

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
  tDropLaunchCmdParamPtr param = (tDropLaunchCmdParamPtr)cmdPBP;
  if(cmd == dDropLaunchSupportCmd) {
    DWord romVersion;
    FtrGet(sysFtrCreator,sysFtrNumROMVersion,&romVersion);
    if(romVersion<0x03000000)
      return 0;
    else
      return dYes_Support;
  } else if(cmd == dDropLaunchCmd) {
    MMLParser psr;
    Char *smfP;
    UInt16 size;
    // set as default settings
    param->resultBehavior = eBehavior_Do_Nothing;
    param->resultText = 0;
    // dispatch...
    switch (param->selector) {
    case 0:
      //size estimation mode: smf=NULL
      psr.smf=NULL;
      size=parser(&psr,param->srcText,param->srcTextLength);
      //store mode;smf will be modified inside the mml library
      smfP=psr.smf=(Char*) MemPtrNew(size+FMT0HDRSIZE+TRACKHDRSIZE);
      if(psr.smf){
	fmt0hdr(&psr);
	trackhdr(&psr,size);
	parser(&psr,param->srcText,param->srcTextLength);
	SndPlaySmf(0,sndSmfCmdPlay,smfP,NULL,NULL,NULL,false);
	//free smf
	MemPtrFree(smfP);
      }
      return 0;
    default:
      break;
    }
    return 0; // never executed.
  } else if(cmd == sysAppLaunchCmdNormalLaunch) {
  }
}
