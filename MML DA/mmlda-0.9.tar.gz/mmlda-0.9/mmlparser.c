#include <PalmOS.h>
#include "mmlparser.h"
/*Melody Editor Compatibility*/
#define MECOMPAT
#define SUTOTON

UInt16
output (MMLParser * m, Char ch)
{
  if (m->smf) {
    *(m->smf) = ch;
    m->smf++;
  }
  return 1;
}

UInt16
outputs (MMLParser * m, UInt32 v, UInt16 len)	//len:1..4
{
  Char bytes[4];
  UInt16 i = 0;
  if (m->smf) {
    do {
      bytes[i++] = v;
      v >>= 8;
    } while (i < len);
    while (--i) {
      output (m, bytes[i]);
    }
    output (m, bytes[0]);
  }
  return len;
}



UInt16
keyon (MMLParser * m, UInt16 note)
{
  output (m, 0x90);
  output (m, note);
  output (m, 0x7f);
  return 3;
}

UInt16
keyoff (MMLParser * m, UInt16 note)
{
  output (m, 0x80);
  output (m, note);
  output (m, 0x7f);
  return 3;
}

UInt16
delta (MMLParser * m, UInt32 length)
{
  Char bytes[4];
  UInt16 outbytes;
  UInt16 i = 0;
  do {
    bytes[i++] = length & 0x7f;
    length >>= 7;
  } while (length);
  outbytes = i;
  while (--i) {
    output (m, bytes[i] | 0x80);
  }
  output (m, bytes[0]);
  return outbytes;
}

UInt16
say (MMLParser * m, UInt16 note, UInt32 length, UInt16 gate)
{
  UInt16 outbytes = 0;
  UInt32 lnote;
  UInt32 lrest;
  if (note > 127) {
    return 0;
  }
  lnote = length * gate / 8;
  lrest = length - lnote;
  outbytes += delta (m, m->restlen);
  outbytes += keyon (m, note);
  outbytes += delta (m, lnote);
  outbytes += keyoff (m, note);
  m->restlen = lrest;
  return outbytes;
}

UInt16
shutup (MMLParser * m, UInt32 length)
{
  m->restlen += length;
  return 0;
}

int
nextchar (Char * p, UInt16 * ch)
{
  unsigned int c;
  c = *p;
  c &= 0xff;
  if ((0x81 <= c && c <= 0x9f) || (0xe0 <= c && c <= 0xFC)) {
    p++;
    *ch = (c << 8) + (*p & 0xff);
    return 2;
  }
  else {
    *ch = c;
    return 1;
  }
}


UInt16
getnum (Char ** p)
{
  UInt32 n = 0;
  while (**p >= '0' && **p <= '9') {
    n *= 10;
    n += (**p) - '0';
    (*p)++;
  }
  return n;
}

Int16
getmnum (Char ** p)
{
  UInt32 n;
  Boolean minus = false;
  if (**p == '-') {
    minus = true;
    (*p)++;
  }
  n = getnum (p);
  if (minus) {
    return -n;
  }
  else {
    return n;
  }
}

UInt32
getlength (Char ** p, UInt16 length)
{
  UInt32 n;
  UInt32 sum = 0;
  UInt32 del;
  WChar ch;
  UInt16 chw;
retry:
  n = getnum (p);
#ifdef MECOMPAT
  if (n != 3 && (n % 10 == 3)) {
    n /= 10;
    del = RESOLUTION * 2 / (n * 3);
  }
  else {
    if (n) {
      del = RESOLUTION / n;
    }
    else {
      del = length;
    }
  }
#else
  if (n) {
    del = RESOLUTION / n;
  }
  else {
    del = length;
  }
#endif
  sum += del;
  while (**p == '.') {
    (*p)++;
    del /= 2;
    sum += del;
  }
  chw = nextchar (*p, &ch);
  if (ch == '^' || ch == 0x815b) {	//'�['
    (*p) += chw;
    goto retry;
  }
  return sum;
}

Int16
getshift (Char ** p)
{
  Int16 n = 0;
  while (1) {
    if (**p == '-') {
      n--;
      (*p)++;
    }
    else if (**p == '+' || **p == '#') {
      n++;
      (*p)++;
#ifdef MECOMPAT
    }
    else if (**p == '~') {
      n += 12;
      (*p)++;
    }
    else if (**p == '_') {
      n -= 12;
      (*p)++;
#endif
    }
    else
      break;
  }
  return n;
}

UInt16
settempo (MMLParser * m, UInt16 tempo)
{
  UInt32 n = 60000000L / tempo;
  UInt16 outbytes = delta (m, m->restlen);
  m->restlen = 0;
  outputs (m, 0xff5103, 3);
  outputs (m, n, 3);
  return outbytes + 6;
}

UInt16
endoftrack (MMLParser * m)
{
  UInt16 outbytes = delta (m, m->restlen);
  //fprintf(stderr,"(%d)\n",outbytes);
  m->restlen = 0;
  outputs (m, 0xff2f00, 3);
  //fprintf(stderr,"(%d)\n",outbytes);
  return 3 + outbytes;
}

UInt32
parser (MMLParser * m, Char * mml, UInt16 mmllen)
{
  Char *p = mml, *plast;
  /*default values */
  UInt16 offset = 0;
  UInt16 octave = 5 * 12;
  UInt16 tempo = 120;
  UInt16 gate = 7;
  UInt32 length = RESOLUTION / 4;
  UInt16 n[] = { 9, 11, 0, 2, 4, 5, 7 };
  UInt16 outbytes = 0;

  m->restlen = 0;
  outbytes += settempo (m, tempo);
  while (p < &mml[mmllen]) {
    WChar ch, ch2;
    UInt32 tmp;
    UInt16 note;
    Int16 itmp;
    Int16 chw;
    //fprintf(stderr,"%d\n",outbytes);
    p += nextchar (p, &ch);
    if (ch == ';') {
      while (p < &mml[mmllen]) {
	p += nextchar (p, &ch);
	if (ch == '\n')
	  break;
      }
      continue;
    }
    if (ch >= 'A' && ch <= 'Z') {
      ch += 'a' - 'A';
    }
    plast = p;
    switch (ch) {
    case 't':
      tmp = getnum (&p);
      if (tmp) {
	tempo = tmp;
	outbytes += settempo (m, tempo);
      }
      break;
    case 'l':
      length = getlength (&p, length);
      break;
    case 'i':
      itmp = getmnum (&p);
      if (itmp > -96 && itmp < 96) {
	offset = itmp;
      }
      break;
    case 'o':
      itmp = getmnum (&p);
      if (p != plast) {
	octave = itmp * 12 + 12;
      }
      break;
    case 'q':
      tmp = getnum (&p);
      if (tmp > 0 && tmp <= 8) {
	gate = tmp;
      }
      break;
    case '<':
      octave -= 12;
      break;
    case '>':
      octave += 12;
      break;
#ifdef SUTOTON
    case 0x8368:		//'�h':
      note = 0;
      goto notecommon;
    case 0x838c:		//'��':
      note = 2;
      goto notecommon;
    case 0x837e:		//'�~':
      note = 4;
      goto notecommon;
    case 0x8374:		//'�t':
      chw = nextchar (p, &ch2);
      if (ch2 == 0x8340) {	//'�@'
	note = 5;
	p += 2;
	goto notecommon;
      }
      break;
    case 0x835c:		//'�\\':
      note = 7;
      goto notecommon;
    case 0x8389:		//'��':
      note = 9;
      goto notecommon;
    case 0x8356:		//'�V':
      note = 11;
      goto notecommon;
#endif
    case 'a':
    case 'b':
    case 'c':
    case 'd':
    case 'e':
    case 'f':
    case 'g':
      note = n[ch - (UInt16) 'a'];
    notecommon:
      note = offset + octave + note + getshift (&p);
      tmp = getlength (&p, length);
      outbytes += say (m, note, tmp, gate);
      break;
#ifdef MECOMPAT
    case '*':
#endif
#ifdef SUTOTON
    case 0x8362:		//'�b':
    case 0x8393:		//'��':
#endif
    case 'r':
      tmp = getlength (&p, length);
      outbytes += shutup (m, tmp);
      break;
    default:
    }
  }
  //fprintf(stderr,"%d\n",outbytes);
  outbytes += endoftrack (m);
  //fprintf(stderr,"%d\n",outbytes);
  return outbytes;
}

UInt16
fmt0hdr (MMLParser * m)
{
  //resolution is fixed to 1920/4
  Char hdr[] = { 0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, 01, 0xe0 };
  UInt16 i;
  for (i = 0; i < 14; i++) {
    output (m, hdr[i]);
  }
  return FMT0HDRSIZE;
}

UInt16
trackhdr (MMLParser * m, UInt16 bytes)
{
  outputs (m, 0x4d54726b, 4);
  outputs (m, bytes, 4);
  return TRACKHDRSIZE;
}
