/*Register MML to syssoundDB*/
#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>

/*
 * start routine
 */

#define Byte Char
#define DWord UInt32

#define prvFieldOffset(type,field) ((DWord)(&((type*)0)->field))

UInt16 AddSmfToDatabase(Char *smf, UInt16 length,Char *trackName)
{
  Err err=0;
  Byte bMidiOffset;
  SndMidiRecHdrType recHdr;
  DmOpenRef dbP;
  Byte *recP;
  UInt16 recIndex;
  MemHandle recH;
  bMidiOffset = sizeof(SndMidiRecHdrType) + StrLen(trackName)+1;
  recHdr.signature=sndMidiRecSignature;
  recHdr.reserved=0;
  recHdr.bDataOffset=bMidiOffset;
  dbP=DmOpenDatabaseByTypeCreator(sysFileTMidi,sysFileCSystem,dmModeReadWrite|dmModeExclusive);
  if(!dbP)
    return 1;
  recIndex=dmMaxRecordIndex;
  recH=DmNewRecord(dbP,&recIndex,length+bMidiOffset);
  if(!recH)
    return 2;
  recP=MemHandleLock(recH);
  err=DmWrite(recP,0,&recHdr,sizeof(recHdr));
  if(!err)
    err=DmStrCopy(recP,prvFieldOffset(SndMidiRecType,name),trackName);
  if(!err)
    err=DmWrite(recP,bMidiOffset,smf,length);
  MemHandleUnlock(recH);
  DmReleaseRecord(dbP,recIndex,1);
  DmCloseDatabase(dbP);
  return err;
}

