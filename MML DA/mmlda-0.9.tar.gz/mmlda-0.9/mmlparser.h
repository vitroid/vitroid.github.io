#ifndef MMLPARSER_H
#define MMLPARSER_H

//$BA42;Id$NJ,2rG=(B
#define RESOLUTION 1920
#define FMT0HDRSIZE 14
#define TRACKHDRSIZE 8

typedef struct
{
  Char *smf;
  UInt32 restlen;
}
MMLParser;

UInt32 parser (MMLParser * m, Char * mml, UInt16 mmllen);
UInt16 fmt0hdr (MMLParser * m);
UInt16 trackhdr (MMLParser * m, UInt16 bytes);

#endif
