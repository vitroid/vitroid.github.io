/*Register MML to syssoundDB*/
#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "mmlparser.h"
#include "regmmlda_rcp.h"
UInt16 AddSmfToDatabase(Char *smf, UInt16 length,Char *trackName);

static Boolean IsInside(RectanglePtr r, Int16 x, Int16 y)
{
  return (0 <= x && x <= r->extent.x && 0 <= y && y <= r->extent.y);
}

static Boolean IsOutside(RectanglePtr r, Int16 x, Int16 y)
{
  return (!IsInside(r, x, y));
}

static void *GetObjectPtr(UInt16 objectID)
{
    FormPtr form;
    UInt16     index;
    void    *ptr;

    form  = FrmGetActiveForm();
    index = FrmGetObjectIndex(form, objectID);
    ptr   = FrmGetObjectPtr(form, index);
    return (ptr);
}

static Boolean DAHandleEvent(EventPtr event, char *smfP,UInt16 smflen)
{
    Boolean done = false;
    Boolean handled = false;
    FormPtr form;
    FieldPtr field;
    UInt16 namelen;
    RectangleType rec;
    Char *name;
    switch (event->eType) {
    case keyDownEvent:
      /*
      if (TxtCharIsHardKey(event->data.keyDown.chr)) {
	EvtAddEventToQueue(event);
	done = true;
	handled = true;
      }else if(event->data.keyDown.chr == pageUpChr && g->len != 0){
	Findnext(g,-1,-1);
	handled = true;
      }else if(event->data.keyDown.chr == pageDownChr && g->len !=0){
	Findnext(g,1,1);
	handled = true;
      }
      */
      break;
    case appStopEvent:
      EvtAddEventToQueue(event);
      done = true;
      handled = true;
      break;
    case penDownEvent:
      RctSetRectangle( &rec, 0, 0, regMMLDAW, regMMLDAH );
      if ( ! RctPtInRectangle( event->screenX, event->screenY, &rec ) ){
          done = true;
          handled = true;
      }
      break;
      
    case ctlSelectEvent:
      
      switch (event->data.ctlSelect.controlID) {
        
      case IdButtonC:
        done = true;
        handled = true;
        break;
        
      case IdButtonR:
	//idfield$BJ8;zNs$r<hF@$7!"(BsmfP$B$rEPO?$9$k!#(B
	field=GetObjectPtr(IdField);
	namelen = FldGetTextLength(field);
	if (0<namelen){
	  name = FldGetTextPtr(field);
	  AddSmfToDatabase(smfP,smflen,name);
	}
        done = true;
        handled = true;
        break;
      }
      
      break;
      
    default:
      break;
    }
    if (!handled) {
      FrmHandleEvent(FrmGetActiveForm(), event);
    }
    return (done);
}


void EventLoop(char *smfP,UInt16 smflen)
{
    EventType event;
    Boolean done = false;
    UInt16 error;
    do {
	EvtGetEvent(&event, evtWaitForever);
	if (SysHandleEvent(&event))
	    continue;
	if (MenuHandleEvent(NULL, &event, &error))
	    continue;
	done = DAHandleEvent(&event, smfP,smflen);
    } while (!done);
}
