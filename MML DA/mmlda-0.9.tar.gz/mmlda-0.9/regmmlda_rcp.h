#define IdForm          1000
#define IdHelp          1001
#define IdLabelN        2000
#define IdField         3000
#define IdButtonR       4000
#define IdButtonC       4001

#define regMMLDAX       2
#define regMMLDAY       109
#define regMMLDAW       156
#define regMMLDAH       49
