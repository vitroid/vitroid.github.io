/*Register MML to syssoundDB*/
#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "mmlparser.h"
#ifdef REGMMLDA
#include "regmmlda_rcp.h"
extern void EventLoop(char *smfP,UInt16 smflen);
#endif

/*
 * start routine
 */

void da_main();

void start()
{
    da_main();
}

#ifdef REGMMLDA
#define CreatorID 'rmmD'
#else
#define CreatorID 'mmDA'
#endif

void da_main()
{
    UInt16 length=0;
    MemHandle handle=NULL;
    FormPtr form;
    FieldPtr field;
    UInt16 focus;
    UInt32 romVersion;
    Char *mml=NULL;
    UInt32 feature = 0;
    if (FtrGet(CreatorID, 0, &feature) == 0) {
	return;
    } else {
	FtrSet(CreatorID, 0, feature);
    }
    FtrGet(sysFtrCreator,sysFtrNumROMVersion,&romVersion);
    if(romVersion<0x03000000) return;
    form=FrmGetActiveForm();
    focus=FrmGetFocus(form);
    if(focus!=noFocus){
      UInt16 start,end;
      field=FrmGetObjectPtr(form,focus);
      switch(FrmGetObjectType(form,focus)){
      case frmTableObj:
	field=TblGetCurrentField(field);
        //continue
      case frmFieldObj:
	mml=FldGetTextPtr(field);
        if(mml!=NULL){
          FldGetSelection(field,&start,&end);
          mml+=start;
          length=end-start;
        }
	break;
      default:
	break;
      }
    }
    if(mml==NULL||length==0){
      handle = ClipboardGetItem(clipboardText,&length);
      if (handle != NULL) {
	mml=MemHandleLock(handle);
      }
    }else{
      //for debug, selected document is copied to clipboard
	//ClipboardAddItem(clipboardText,mml,length);
    }
    if(mml!=NULL){
      MMLParser psr;  /**/
      UInt16 size;
      //size estimation mode: smf=NULL
      Char *smfP;
      psr.smf=NULL;
      size=parser(&psr,mml,length);
      //store mode;smf willbe modified inside the mml library
      smfP=psr.smf=(Char*) MemPtrNew(size+FMT0HDRSIZE+TRACKHDRSIZE);
      if(psr.smf){
	fmt0hdr(&psr);
	trackhdr(&psr,size);
	parser(&psr,mml,length);
#ifdef REGMMLDA
        //$B$3$3$G%@%$%"%m%0$r3+$-!"6JL>F~NO$r5a$a$k!#(BOK$B$H(Bcancel$B%\%?%s$r=`Hw$9$k!#(B
        //$B$3$NItJ,0J30$OA4$/6&MQ$7$F$h$$$O$:!#(B
        form=FrmInitForm(IdForm);
        FrmSetActiveForm(form);
        FrmDrawForm(form);
        FrmSetFocus(form,FrmGetObjectIndex(form,IdField));
	//
#endif
	  SndPlaySmf(0,sndSmfCmdPlay,smfP,NULL,NULL,NULL,false);
#ifdef REGMMLDA
        //
	EventLoop(smfP,size+FMT0HDRSIZE+TRACKHDRSIZE);
        FrmEraseForm(form);
        FrmDeleteForm(form);
	//$B$3$3$^$G(Breg$BFCM-$N=hM}(B
#endif
	MemPtrFree(smfP);
      }
    }
    if(handle!=NULL)
      MemHandleUnlock(handle);
    /*release feature*/
    if (FtrGet(CreatorID, 0, &feature) == 0) {
	FtrUnregister(CreatorID, 0);
    }
}

