#ifndef MMLPACKER_H
#define MMLPACKER_H
int parser(Char** to, char* mml,int mmllen);
#endif
