#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#define DWord UInt32
#define Ptr void *
#define Byte Char
#define Word UInt16
#include "DropModule.h"
#include "mmlpacker.h"

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
  tDropLaunchCmdParamPtr param = (tDropLaunchCmdParamPtr)cmdPBP;
  if(cmd == dDropLaunchSupportCmd) {
    DWord romVersion;
    FtrGet(sysFtrCreator,sysFtrNumROMVersion,&romVersion);
    if(romVersion<0x03000000)
      return 0;
    else
      return dYes_Support;
  } else if(cmd == dDropLaunchCmd) {
    UInt16 size;
    Char* to;
    // set as default settings
    param->resultBehavior = eBehavior_Do_Nothing;
    param->resultText = 0;
    // dispatch...
    switch (param->selector) {
    case 0:
      param->resultBehavior = eBehavior_Replace;
      //size estimation mode: packed=NULL
      to=NULL;
      size=parser(&to, param->srcText,param->srcTextLength);
      //store mode;packed will be modified inside the mml library
      to=(Char*) MemPtrNew(size);
      if(to){
	param->resultText=to;
	param->resultTextLength=size;
	parser(&to, param->srcText,param->srcTextLength);
      }
      return 0;
    default:
      break;
    }
    return 0; // never executed.
  } else if(cmd == sysAppLaunchCmdNormalLaunch) {
  }
}
