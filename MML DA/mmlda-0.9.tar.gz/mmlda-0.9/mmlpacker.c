/*MMLcompressorDD*/
/*mmllib�Ɠ��l�A2pass�ŏ�������B*/
/*Melody Editor Compatibility*/
#include "StringMgr.h"
#include "MemoryMgr.h"
#include "mmlpacker.h"
#define MECOMPAT
#define SUTOTON
#define UChar unsigned char

void octaveshift(char *buf,int old,int new)
{
  int count=0;
  if(old<0){
    old=-old-1;
  }else{
    old/=12;
  }
  if(new<0){
    new=-new-1;
  }else{
    new/=12;
  }
  while(old>new){
    buf[count++]='<';
    new++;
  }
  while(old<new){
    buf[count++]='>';
    old++;
  }
  buf[count]=0;
}

int storeasis(Char** to, char *str)
{
  int length=StrLen(str);
  if(*to){
    MemMove(*to, str, length);
    *to+=length;
    return 0;
  }else{
    return length;
  }
}

int storenote(Char** to, int note)
{
  if(note<0){
    return storeasis(to, "r");
  }else{
    switch(note%12){
    case 0:return storeasis(to, "c");
    case 1:return storeasis(to, "c#");
    case 2:return storeasis(to, "d");
    case 3:return storeasis(to, "d#");
    case 4:return storeasis(to, "e");
    case 5:return storeasis(to, "f");
    case 6:return storeasis(to, "f#");
    case 7:return storeasis(to, "g");
    case 8:return storeasis(to, "g#");
    case 9:return storeasis(to, "a");
    case 10:return storeasis(to, "a#");
    case 11:return storeasis(to, "b");
    default:
    }
  }
  //never come here
  return 0;
}

int output(Char** to, char *A,int lastsym,char *B,char *internote,char *C)
{
  int size=0;
  if(*B){
    if(0==StrCompare(A,B)){
      //�I�N�^�[�u�͂��炩���ߒ�������Ă�����̂Ƃ���B
      size+=storenote(to, lastsym);
      //�����̓f�t�H���g�̂܂܂ł悢�B
    }else if(0==StrCompare(B,C)){
      size+=storeasis(to, "L");
      size+=storeasis(to, B);
      size+=storenote(to, lastsym);
      StrCopy(A,B);
    }else{
      size+=storenote(to, lastsym);
      size+=storeasis(to, B);
    }
  }
  StrCopy(B,C);
  size+=storeasis(to, internote);
  internote[0]=0;
  return size;
}

int nextchar(Char *p,UInt16 *ch)
{
  unsigned int c;
  c=*p;
  c&=0xff;
  if((0x81<=c&&c<=0x9f)||(0xe0<=c&&c<=0xFC)){
    p++;
    *ch=(c<<8)+(*p&0xff);
    return 2;
  }else{
    *ch=c;
    return 1;
  }
}

int append(char *dst,char *src,int srclen)
{
  int len=StrLen(dst);
  dst+=len;
  len+=srclen;
  while(srclen--){
    *dst=*src;
    dst++;
    src++;
  }
  *dst='\0';
  return len;
}

void hexbyte(char *dst,UChar ch)
{
  unsigned int hi=ch>>4;
  dst[0]=':';
  if(hi>9)
    hi+='A'-10;
  else
    hi+='0';
  dst[1]=hi;
  hi=ch&0x0f;
  if(hi>9)
    hi+='A'-10;
  else
    hi+='0';
  dst[2]=hi;
}

void appendhex(char *dst,UInt16 ch)
{
  int len=StrLen(dst);
  dst+=len;
  if(ch>255){
    hexbyte(dst,ch>>8);
    dst+=3;
  }
  hexbyte(dst,ch&0xff);
  dst+=3;
  *dst=0;
}

void GetLengthAsString(char **p,char *str)
{
  int count=0;
  while(1){
    UInt16 ch;
    UInt16 chw=nextchar(*p,&ch);
    if(ch==0x815b){//'�['
      str[count++]='^';
      (*p)+=chw;
    }else if((**p>='0'&&**p<='9')||(**p=='.')||(**p=='^')){
      str[count++]=**p;
      (*p)++;
    }else
      break;
  }
  str[count]=0;
}

int getshift(char **p)
{
  int n=0;
  while(1){
    if(**p == '-'){
      n--;
      (*p)++;
    }else if(**p == '+' || **p == '#'){
      n++;
      (*p)++;
#ifdef MECOMPAT
    }else if(**p == '~'){
      n+=12;
      (*p)++;
    }else if(**p == '_'){
      n-=12;
      (*p)++;
#endif
    }else
      break;
  }
  return n;
}

int getmnum(char **p)
{
  int n=0;
  int minus=0;
  if(**p=='-'){
    minus=1;
    (*p)++;
  }
  while(**p>='0' && **p<='9'){
    n*=10;
    n+=(**p)-'0';
    (*p)++;
  }
  if(minus){
    return -n;
  }else{
    return n;
  }
}

int parser(Char** to, char* mml,int mmllen)
{
  char lastdefaultlength[20]="4";
  char lastlength[20]="";
  char length[20];
  char internote[100]="";
  int lastsym=48;
  int lastisnote=1;
  int note;
  char *p=mml;
  int octave=4;
  int offset=0;
  /*abcdefgro<>l�ȊO�͓��߂���B*/
  int n[]={9,11,0,2,4,5,7};
  int size=0;
  
  char defaultlength[20]="4";
  while(p<&mml[mmllen]){
    UInt16 ch,ch2;
    int chw;
    char tmp[20];
    char *lastp;
    chw=nextchar(p,&ch);
    if(ch == ';'){
      char *comment=p;
      int len=0;
      while(p<&mml[mmllen]){
	if(*p=='\n')
	  break;
	p++;
	len++;
      }
      append(internote,comment,len);
      continue;
    }
    lastp=p;
    p+=chw;
    if('A'<=ch&&ch<='Z'){
      ch+='a'-'A';
    }
    switch(ch){
    case 'l':
      //������Ƃ��Ĉ����B
      GetLengthAsString(&p,tmp);
      if(*tmp){
	StrCopy(defaultlength,tmp);
      }
      break;
    case 'i':
      offset=getmnum(&p);
      break;
    case 'o':
      octave=getmnum(&p);
      break;
    case '<':
      octave--;
      break;
    case '>':
      octave++;
      break;
#ifdef SUTOTON
    case 0x8368://'�h':
      note=0;
      goto notecommon;
    case 0x838c://'��':
      note=2;
      goto notecommon;
    case 0x837e://'�~':
      note=4;
      goto notecommon;
    case 0x8374://'�t':
      chw=nextchar(p,&ch2);
      if(ch2==0x8340){//'�@'
	note=5;
	p+=2;
	goto notecommon;
      }
      break;
    case 0x835c://'�\\':
      note=7;
      goto notecommon;
    case 0x8389://'��':
      note=9;
      goto notecommon;
    case 0x8356://'�V':
      note=11;
      goto notecommon;
#endif
    case 'a':
    case 'b':
    case 'c':
    case 'd':
    case 'e':
    case 'f':
    case 'g':
      //���O�̉��̍������L�����Ă����A����Ƃ̍��œK�X"<>"��ǉ�����B
      //�����͕�����Ƃ��Ĉ����A���O�̉��Ɠ��������Ȃ�"l"��ݒ肷��B
      note=n[ch-'a'];
    notecommon:
      note=octave*12+offset+note+getshift(&p);
      GetLengthAsString(&p,length);
      if(*length==0){
	StrCopy(length,defaultlength);
      }
      octaveshift(&internote[StrLen(internote)],lastsym,note);
      if(lastisnote){
	size+=output(to, lastdefaultlength,lastsym,lastlength,internote,length);
      }else{
	size+=output(to, lastdefaultlength,-1,lastlength,internote,length);
      }
      lastsym=note;
      lastisnote=1;
      break;
#ifdef MECOMPAT
    case '*':
#endif
#ifdef SUTOTON
    case 0x8362://'�b':
    case 0x8393://'��':
#endif
    case 'r':
      //�����͕�����Ƃ��Ĉ����A���O�̉��Ɠ��������Ȃ�"l"��ݒ肷��B
      //note=-octave-1;
      GetLengthAsString(&p,length);
      if(*length==0){
	StrCopy(length,defaultlength);
      }
      if(lastisnote){
	size+=output(to, lastdefaultlength,lastsym,lastlength,internote,length);
      }else{
	size+=output(to, lastdefaultlength,-1,lastlength,internote,length);
      }
      //lastsym=note;
      lastisnote=0;
      break;
    default:
      //appendhex(internote,ch);
      append(internote,lastp,chw);
      break;
    }
  }
  //flush buffer
  length[0]=0;
  if(lastisnote)
    size+=output(to, lastdefaultlength,lastsym,lastlength,internote,length);
  else
    size+=output(to, lastdefaultlength,-1,lastlength,internote,length);
  return size;
}

