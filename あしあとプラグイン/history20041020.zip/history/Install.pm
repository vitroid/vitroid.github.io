###############################################################################
#
# ��������פ��ޤ���
#
###############################################################################
package plugin::history::Install;
#use strict;

sub install {
	my $wiki = shift;
	
	$wiki->add_hook("show","plugin::history::Show");
	$wiki->add_paragraph_plugin("history" ,"plugin::history::History" ,"WIKI");
}

1;
