package plugin::history::Show;
#use strict;
#===========================================================
# ���󥹥ȥ饯��
#===========================================================
sub new {
	my $class = shift;
	my $self = {};
	return bless $self,$class;
}

sub hook {
	my $self = shift;
	my $wiki = shift;
	my $cgi = $wiki->get_CGI;

	my $session = $cgi->get_session( $wiki );
	if ( $session ){
	    my $history  = $session->param( "wiki_history" );
	    my @history  = split( /\t/, $history );
	    my $pagename = $cgi->param("page");
	    if ( $history[0] ne $pagename ){
		unshift( @history, $pagename );
		while ( 30 < $#history ){
		    pop @history;
		}
		$history = join( "\t", @history );
		$session->param( "wiki_history", $history );
		$session->flush();
	    }
	}
    }
1;
