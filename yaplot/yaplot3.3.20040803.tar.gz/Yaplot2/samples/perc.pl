#!/usr/local/bin/perl
# test script for yaplot
# 3-dimensional site percolation
# try:
# perc.pl | yaplot -

$n=8;
if($#ARGV == 0){
    $n = $ARGV[0];
}
$nh=$n/2;
$nhm=-$nh;
$p=0.3;

sub value{
    local($x,$y,$z)=@_;
    $x %= $n;
    $y %= $n;
    $z %= $n;
    $c=($x*$n+$y)*$n+$z;
    if($d[$c]==0){
	$d[$c]=rand()<$p ? 1 : -1;
    }
    $d[$c];
}

srand;
print "r 0.1\n@ 2\n";
for($x=$nhm;$x<$nh;$x++){
    for($y=$nhm;$y<$nh;$y++){
	for($z=$nhm;$z<$nh;$z++){
	    if(&value($x,$y,$z)==1){
#		print "o $x $y $z\n";
	    }
	}
    }
}

for($i=$nhm;$i<=$nh;$i+=$n){
    for($j=$nhm;$j<=$nh;$j+=$n){
	print "l $nhm $i $j $nh $i $j\n";
	print "l $j $nhm $i $j $nh $i\n";
	print "l $i $j $nhm $i $j $nh\n";
    }
}

print "@ 3\n";
for($x=$nhm;$x<$nh;$x++){
    $xi=$x+1;
    for($y=$nhm;$y<$nh;$y++){
	$yi=$y+1;
	for($z=$nhm;$z<$nh;$z++){
	    $zi=$z+1;
	    if((&value($x,$y,$z)==1)&&(&value($xi,$y,$z)==1)){
		print "l $x $y $z $xi $y $z\n";
	    }
	    if((&value($x,$y,$z)==1)&&(&value($x,$yi,$z)==1)){
		print "l $x $y $z $x $yi $z\n";
	    }
	    if((&value($x,$y,$z)==1)&&(&value($x,$y,$zi)==1)){
		print "l $x $y $z $x $y $zi\n";
	    }
	}
    }
}
print "\n";
