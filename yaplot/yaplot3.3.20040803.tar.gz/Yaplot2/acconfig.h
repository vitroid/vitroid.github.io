#define PACKAGE yaplot
#define VERSION 3.0
