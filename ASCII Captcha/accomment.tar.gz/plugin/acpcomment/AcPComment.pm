############################################################
# 
# ���ԥ����Ȥ�񤭹��ि��Υե��������Ϥ��ޤ���
# Comment���礭�ʰ㤤�ϡ��㤦�ڡ����˥����Ȥ�������Ȥ����Ǥ���
# <pre>
# {{acpcomment �ڡ���̾��,[���ץ����]}}
# ���ץ����ϰʲ����̤ꡣ
# �ڡ���̾�Τ�ɬ���������ˤ��Ƥ���������
# ��������ʲ��Υ��ץ����ν��֤��äˤ���ޤ���
# {{acpcomment �ڡ���̾��,ɽ�����}}
# {{acpcomment �ڡ���̾��,��Ƭʸ��}} ... + or * ̤����� *
# {{acpcomment �ڡ���̾��,reverse}}  ... �ս�
# {{acpcomment �ڡ���̾��,reply}}    ... ��ץ饤�⡼��
# {{acpcomment �ڡ���̾��,suffix}}   ... �ڡ���̾�Τ�����ʸ����ˤ���
# ����ʸ����ϡ����ߤΥڡ����˰����Υڡ���̾�Τ��դ��ä����ڡ���̾�ˤʤ�ޤ���
# ��){{acpcomment _comment,suffix}}
#    FrontPage�˵��Ҥ�����硢FrontPage_comment�˥����Ȥ򵭽Ҥ��ޤ���
#    Footer�ʤɤ˵��Ҥ���������Ѥ�����������⤷��ޤ���
# </pre>
#
############################################################

# ����
# 2004/05/25 reply���ץ������ɲ�

package plugin::acpcomment::AcPComment;
#use lib qw(../../lib);
use Util;
use strict;
use Font::BDF::Reader;

#===========================================================
# ���󥹥ȥ饯��
#===========================================================
sub new {
    my $class = shift;
    my $self = {};

  $self->{bits} = {
			 '0'=>[ 0,0,0,0 ],
			 '1'=>[ 0,0,0,1 ],
			 '2'=>[ 0,0,1,0 ],
			 '3'=>[ 0,0,1,1 ],
			 '4'=>[ 0,1,0,0 ],
			 '5'=>[ 0,1,0,1 ],
			 '6'=>[ 0,1,1,0 ],
			 '7'=>[ 0,1,1,1 ],
			 '8'=>[ 1,0,0,0 ],
			 '9'=>[ 1,0,0,1 ],
			 'A'=>[ 1,0,1,0 ],
			 'B'=>[ 1,0,1,1 ],
			 'C'=>[ 1,1,0,0 ],
			 'D'=>[ 1,1,0,1 ],
			 'E'=>[ 1,1,1,0 ],
			 'F'=>[ 1,1,1,1 ],
			 };


	$self->{lightletters} = [ ',', '.', ' ', '`' ];
	$self->{heavyletters} = [ '#', 'W', 'G', '@' ];


	# See http://search.cpan.org/~dclee/Font-BDF-Reader-0.01/Reader.pm

    return bless $self,$class;
}

#===========================================================
# �����ȥե�����
#===========================================================
sub paragraph {
    my $self = shift;
    my $wiki = shift;
    my $save_page = shift; #�ǽ�ΰ�������¸�ڡ���̾

    #�ƥ��ץ����β��
    my $head_char = "*";
    my $reverse = 0;
    my $suffix = 0;
    my $reply = 0;
    my $page_count = -1;
    foreach(@_){
        if($_ eq "reverse"){
            $reverse = 1;
        }elsif($_ eq "*" or $_ eq "+"){
            $head_char = $_;
        }elsif($_ eq "suffix"){
            $suffix = 1;
        }elsif($_ eq "reply"){
            $reply = 1;
        }elsif($_ =~ /\d+/){
            $page_count = $_;
        }
    }

    my $cgi = $wiki->get_CGI;
    my $show_page  = $cgi->param("page");

    if($suffix){
        $save_page = $show_page . $save_page;
    }

    if($save_page eq ""){
        return &Util::paragraph_error("�ڡ��������ꤵ��Ƥ��ޤ���","WIKI");
    }

    if($save_page eq $show_page){
        return &Util::paragraph_error("Ʊ��Υڡ��������ѤǤ��ޤ���","WIKI");
    }

    # ̾�������
    my $name = $cgi->cookie(-name=>'post_name');
    if($name eq ''){
        my $login = $wiki->get_login_info();
        if(defined($login)){
            $name = $login->{id};
        }
    }

    my $comment = $self->_show_comment($wiki, $save_page, $page_count, $reverse, $reply);

  	my $tmpl = HTML::Template->new(filename=>$wiki->config('tmpl_dir')."/asciicaptchacomment.tmpl",
	                               die_on_bad_params=>0);
	$self->{BDF} = Font::BDF::Reader->new( $wiki->config('tmpl_dir') . "/helvR14.bdf" );
	$self->{BDF}->get_all_ENCODING;
        my ( $banner, $answer ) = $self->asciicaptcha2();
	#print STDERR $banner;
#        my $session = $cgi->get_session( $wiki );
#        if ( $session ){
#		$session->param( "answer", $answer );
#	}

        $answer = &Util::md5($answer,$show_page);

        $tmpl->param(NAME=>$name);
	$tmpl->param(BANNER=>$banner);


    my $buf = "<form method=\"post\" action=\"".$wiki->config('script_name')."\">\n";
    $buf .= $comment unless($reverse);
    $buf .= '<input type="radio" name="reply" value="0" checked="checked">' if($reply);
    $buf .= $tmpl->output();
    $buf .= $comment if($reverse);
    $buf .= "<input type=\"hidden\" name=\"action\" value=\"ACPCOMMENT\">\n";
    $buf .= "<input type=\"hidden\" name=\"save_page\" value=\"".&Util::escapeHTML($save_page)."\">\n";
    $buf .= "<input type=\"hidden\" name=\"show_page\" value=\"".&Util::escapeHTML($show_page)."\">\n";
    $buf .= "<input type=\"hidden\" name=\"head_char\" value=\"".&Util::escapeHTML($head_char)."\">\n";
    $buf .= "<input type=\"hidden\" name=\"answer\" value=\"".$answer."\">\n";

    $buf .= "</form>\n";

    return $buf;
}

# ����ڡ����Υ����Ȥ�������롣
sub _show_comment{
    my $self = shift;
    my $wiki = shift;
    my $page = shift;
    my $count = shift;
    my $reverse = shift;
    my $reply = shift;

    if(!$wiki->page_exists($page) or $count == 0){
        return "";
    }

    my $src = $wiki->get_page($page);

    # reverse�ΰ٤��к���
    # �ƥ����Ȥ˻ҥ����Ȥ򤯤äĤ������Τ�...
    my $comment = [];
    foreach(split(/\n/, $src)){
        next unless(/^([*+]{1,3})/);
        my $depth = length($1);
        if($reply){
            $_ = $1 . "{{acpcomment_radio_button " . $depth . "," . $_ . "}}";
        }
        if($depth == 1){
            push(@$comment, [$_]);
        }else{
            if(ref $$comment[-1]){
                push(@{$$comment[-1]}, $_);
            }else{#�ǽ餬**��***�ξ��Τ�����к���
                push(@$comment, [$_]);
            }
        }
    }

    if($count > 0 and $count < @$comment){
        @$comment = @$comment[@$comment - $count..@$comment - 1];
    }

    if($reverse){
        @$comment = reverse(@$comment);
    }

    # ���̤�����ˡ�
    my @comment;
    foreach(@$comment){
        foreach(@$_){
            push(@comment, $_);
        }
    }

    return $wiki->process_wiki(join("\n", @comment, "[[�����ȥڡ����򻲾�|$page]]"));
}




sub asciicaptcha1{
    my ( $self ) = @_;
    my $v1 = int rand 10;
    my $v2 = int rand 10;
    my $answer = $v1 * $v2;
    my $string = $v1 . "x" . $v2 . "=?";

    my ( $width, @pos ) = $self->letters( $string, 2 );
    my $banner = $self->toBanner( $width, @pos );
    ( $banner, $answer );
}



sub asciicaptcha2{
    my ( $self ) = @_;
    my @chars = ( 'a' .. 'z' );
    my $v1 = $chars[ int rand 26 ];
    my $v2 = $chars[ int rand 26 ];
    my $v3 = $chars[ int rand 26 ];
    my $v4 = $chars[ int rand 26 ];
    my $v5 = $chars[ int rand 26 ];
    my $answer = $v1.$v2.$v3.$v4.$v5;
    my $string = $answer;

    my ( $width, @pos ) = $self->letters( $string, 2 );
    my $banner = $self->toBanner( $width, @pos );
    ( $banner, $answer );
}



sub toBanner{
    my ( $self, $width, @pos ) = @_;
    my @map;
    my ( $columns, $rows, $xoffset, $yoffset ) = 
	split /\s+/, $self->{BDF}{METADATA}{FONTBOUNDINGBOX};
    foreach my $xy ( @pos ){
	my $x = $xy->[0] - $xoffset;
	my $y = $xy->[1] - $yoffset;
	$map[$y][$x] = 1;
    }

    my $lines;
    for(my $y=$rows-1; $y>=0;$y-- ){
	for(my $x=0; $x<=$width - $xoffset; $x++){
	    $lines .= $self->pix($map[$y][$x]);
	    $lines .= $self->pix($map[$y][$x]);
	}
	$lines .= "\n";
    }
    $lines;
}



sub pix{
    my ( $self, $v ) = @_;
    if ( $v ){
	$self->{heavyletters}[ rand( $#{$self->{heavyletters}} + 1 ) ];
    }
    else{
	if ( rand() < 0.05 ){
	    $self->{heavyletters}[ rand( $#{$self->{heavyletters}} + 1 ) ];
	}
	else{
	    $self->{lightletters}[ rand( $#{$self->{lightletters}} + 1 ) ];
	}
    }
}




    
sub letters{
    my ( $self, $string, $fluc ) = @_;
    my $xoffset = 0;
    my @pos;
    
    foreach my $letter ( split //, $string ){
	my ( $width, @p ) = $self->letter( $letter, $fluc );
	foreach my $xy ( @p ){
	    $xy->[0] +=  $xoffset;
	    push @pos, $xy;
	}
	$xoffset += $width;
    }
    ( $xoffset, @pos );
}


#
#
#
sub letter{
    my ( $self, $code, $fluc ) = @_;
    $code = ord( $code );
    my $char = $self->{BDF}->get_font_info_by_ENCODING( $code );

    my $width = $char->{DWIDTH}[0];
    my $firstline = $char->{BBX}[1] + $char->{BBX}[3] + int(rand($fluc*2+1)-$fluc);
    my $lines     = $char->{BBX}[1];
    my $xoffset   = $char->{BBX}[2];


    my @pos;
    foreach my $y ( 0 .. $lines - 1 ){
	my $line = $char->{BITMAP}[$y];
	my @chars = split //, $line;
	my @bits;
	foreach my $letter ( @chars ){
	    push @bits, @{$self->{bits}{$letter}};
	}
	for(my $x=0; $x<=$#bits; $x++){
	    if ( $bits[$x] ){
		push @pos, [ $x + $xoffset, $firstline - $y ];
	    }
	}
    }
    ( $width, @pos );
}
1;




#===========================================================
# �����Ȥν񤭹���
#===========================================================
sub do_action {
    my $self = shift;
    my $wiki = shift;
    my $cgi  = $wiki->get_CGI;
    
    my $name      = $cgi->param("name");
    my $message   = $cgi->param("message");
    my $save_page = $cgi->param("save_page");
    my $show_page = $cgi->param("show_page");
    my $head_char = $cgi->param("head_char");
    my $reply     = $cgi->param("reply");
    my $captcha = $cgi->param("captcha");
       $captcha = Util::md5($captcha,$show_page);
	
	my $answer = $cgi->param("answer");
#        my $session = $cgi->get_session( $wiki );
#        if ( $session ){
#		$answer = $session->param( "answer" );
#	}

    if($name eq ""){
        $name = "̵̾������";
    } else {
        # post_name�Ȥ��������ǥ��å����򥻥åȤ���
        my $cookie = $cgi->cookie(-name=>'post_name',-value=>$name,-expires=>'+1M');
        print "Set-Cookie: ",$cookie->as_string,"\n";
    }

     if($answer eq $captcha && $save_page ne "" && $message ne ""){
#    if($session && $answer eq $captcha && $save_page ne "" && $message ne ""){
#    if($save_page ne "" && $message ne ""){
        my $content;
        if($wiki->page_exists($save_page)){
            $content = $wiki->get_page($save_page);
            $content =~ s/\n+$//g; #�����β��Ԥ����ƽ���
        }else{
            $content = "[[$show_page]]\n";
        }
        my $new_content .= $head_char . "$message - $name (".Util::format_date(time()) . ")";

        unless($reply){
            $content .= "\n" if($content);
            $content .= $new_content . "\n";
        }else{
            my @content;
            my $reply_sw = 0; #��������...
            my $lev = 0;
            foreach(split /\n/, $content){
                /^([*+]+)/;
                if($reply_sw == 1 and $lev >= length($1)){
                    push(@content, $head_char x $lev . $new_content);
                    $reply_sw = 2;
                }
                if($reply_sw == 0 and $reply eq Util::md5($_)){
                    $lev = length($1);
                    $reply_sw = 1;
                }
                push(@content, $_);
            }
            if($reply_sw == 1){
                push(@content, $head_char x $lev . $new_content);
            }
            $content = join("\n", @content);
        }

        $wiki->save_page($save_page, $content);

        my $modtime = &Util::load_config_hash($wiki,$Wiki::DefaultStorage::MODTIME_FILE);
        $modtime->{$show_page} = time();
        &Util::save_config_hash($wiki,$Wiki::DefaultStorage::MODTIME_FILE,$modtime);

    }
    # ɽ������Ƥ����ڡ����˥�����쥯��
    $wiki->redirect($show_page);
}
1;
