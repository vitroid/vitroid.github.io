############################################################
# 
# AcComment�ץ饰����Υ��������ϥ�ɥ顣
# 
############################################################
package plugin::accomment::AcCommentHandler;
use strict;
#===========================================================
# ���󥹥ȥ饯��
#===========================================================
sub new {
	my $class = shift;
	my $self = {};
	return bless $self,$class;
}

#===========================================================
# �����Ȥν񤭹���
#===========================================================
sub do_action {
	my $self = shift;
	my $wiki = shift;
	my $cgi  = $wiki->get_CGI;
	
	my $name    = $cgi->param("name");
	my $message = $cgi->param("message");
	my $count   = $cgi->param("count");
	my $page    = $cgi->param("page");
	my $option  = $cgi->param("option");
	my $captcha = $cgi->param("captcha");
           $captcha = Util::md5($captcha,$page);
	
	my $answer = $cgi->param("answer");
#        my $session = $cgi->get_session( $wiki );
#        if ( $session ){
#		$answer = $session->param( "answer" );
#	}

       if($name eq ""){
		$name = "̵̾������";
	} else {
		# post_name�Ȥ��������ǥ��å����򥻥åȤ���
		my $path   = &Util::cookie_path($wiki);
		my $cookie = $cgi->cookie(-name=>'post_name',-value=>$name,-expires=>'+1M',-path=>$path);
		print "Set-Cookie: ",$cookie->as_string,"\n";
	}
	
	# �ե����ޥåȥץ饰����ؤ��б�
	my $format = $wiki->get_edit_format();
	$name    = $wiki->convert_to_fswiki($name   ,$format,1);
	$message = $wiki->convert_to_fswiki($message,$format,1);
	
	if($answer eq $captcha && $page ne "" && $message ne "" && $count ne ""){
#       if($session && $answer eq $captcha && $page ne "" && $message ne "" && $count ne ""){
#	if($page ne "" && $message ne "" && $count ne ""){
		
		my @lines = split(/\n/,$wiki->get_page($page));
		my $flag       = 0;
		my $form_count = 1;
		my $content    = "";
		
		foreach(@lines){
			# �����ξ��
			if($option eq "reverse"){
				$content = $content.$_."\n";
				if(/^{{accomment\s*.*}}$/ && $flag==0){
					if($form_count==$count){
						$content = $content."*$message - $name (".Util::format_date(time()).")\n";
						$flag = 1;
					} else {
						$form_count++;
					}
				}
			# �ڡ����������ɲäξ��
			} elsif($option eq "tail"){
				$content = $content.$_."\n";
				
			# ��ƽ�ξ��
			} else {
				if(/^{{accomment\s*.*}}$/ && $flag==0){
					if($form_count==$count){
						$content = $content."*$message - $name (".Util::format_date(time()).")\n";
						$flag = 1;
					} else {
						$form_count++;
					}
				}
				$content = $content.$_."\n";
			}
		}
		
		# �ڡ����������ɲäξ��ϺǸ���ɲ�
		if($option eq "tail"){
			$content = $content."*$message - $name (".Util::format_date(time()).")\n";
			$flag = 1;
		}
		
		if($flag==1){
			$wiki->save_page($page,$content);
		}
	}
	
	# ���Υڡ����˥�����쥯��
	$wiki->redirect($page);
}

1;
