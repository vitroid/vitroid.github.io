############################################################
# 
# <p>���ԥ����Ȥ�񤭹��ि��Υե��������Ϥ��ޤ���</p>
# <pre>
# {{accomment}}
# </pre>
# <p>
#   �̾�����Ȥ���ƥե�����β����ɲä���Ƥ����ޤ�����
#   ���ץ����ǥե�����ξ�˿����ɽ������褦�ˤǤ��ޤ���
# </p>
# <pre>
# {{accomment reverse}}
# </pre>
# <p>
#   tail���ץ�����Ĥ���ȥڡ����κǸ�˥����Ȥ��ɲä��ޤ���
#   �եå��ʤɤ�accomment�ץ饰��������֤������ڡ����˥����Ȥ�
#   �Ĥ���������ͭ���Ǥ���
# </p>
# <pre>
# {{accomment tail}}
# </pre>
# 
############################################################
package plugin::accomment::AcComment;
use strict;
use Font::BDF::Reader;

#===========================================================
# ���󥹥ȥ饯��
#===========================================================
sub new {
	my $class = shift;
	my $self = {};

	$self->{bits} = {
			 '0'=>[ 0,0,0,0 ],
			 '1'=>[ 0,0,0,1 ],
			 '2'=>[ 0,0,1,0 ],
			 '3'=>[ 0,0,1,1 ],
			 '4'=>[ 0,1,0,0 ],
			 '5'=>[ 0,1,0,1 ],
			 '6'=>[ 0,1,1,0 ],
			 '7'=>[ 0,1,1,1 ],
			 '8'=>[ 1,0,0,0 ],
			 '9'=>[ 1,0,0,1 ],
			 'A'=>[ 1,0,1,0 ],
			 'B'=>[ 1,0,1,1 ],
			 'C'=>[ 1,1,0,0 ],
			 'D'=>[ 1,1,0,1 ],
			 'E'=>[ 1,1,1,0 ],
			 'F'=>[ 1,1,1,1 ],
			 };


	$self->{lightletters} = [ ',', '.', ' ', '`' ];
	$self->{heavyletters} = [ '#', 'W', 'G', '@' ];


	# See http://search.cpan.org/~dclee/Font-BDF-Reader-0.01/Reader.pm

	return bless $self,$class;
}

#===========================================================
# �����ȥե�����
#===========================================================
sub paragraph {
	my $self = shift;
	my $wiki = shift;
	my $opt  = shift;
	my $cgi  = $wiki->get_CGI;
	
	my $page = $cgi->param("page");
	
	if(!defined($self->{$page})){
		$self->{$page} = 1;
	} else {
		$self->{$page}++;
	}
	
	# ����å������Ѥ��ʤ����Τ�̾�������
	my $name = '';
	unless($wiki->use_cache($page)){
		$name = $cgi->cookie(-name=>'post_name');
		if($name eq ''){
			my $login = $wiki->get_login_info();
			if(defined($login)){
				$name = $login->{id};
			}
		}
	}
	
	my $tmpl = HTML::Template->new(filename=>$wiki->config('tmpl_dir')."/asciicaptchacomment.tmpl",
	                               die_on_bad_params=>0);
	$self->{BDF} = Font::BDF::Reader->new( $wiki->config('tmpl_dir') . "/helvR14.bdf" );
	$self->{BDF}->get_all_ENCODING;
        my ( $banner, $answer ) = $self->asciicaptcha2();
	#print STDERR $banner;
#        my $session = $cgi->get_session( $wiki );
#        if ( $session ){
#	 	$session->param( "answer", $answer );
#	}

        $answer = &Util::md5($answer,$page);

	$tmpl->param(NAME=>$name);
	$tmpl->param(BANNER=>$banner);
	
	my $buf = "<form method=\"post\" action=\"".$wiki->config('script_name')."\">\n".
	          $tmpl->output().
	          "<input type=\"hidden\" name=\"action\" value=\"ACCOMMENT\">\n".
	          "<input type=\"hidden\" name=\"page\" value=\"".&Util::escapeHTML($page)."\">\n".
	          "<input type=\"hidden\" name=\"count\" value=\"".$self->{$page}."\">\n".
	          "<input type=\"hidden\" name=\"answer\" value=\"".$answer."\">\n".
                  "<input type=\"hidden\" name=\"option\" value=\"".&Util::escapeHTML($opt)."\">\n".
	          "</form>\n";
	
	return $buf;
}




sub asciicaptcha1{
    my ( $self ) = @_;
    my $v1 = int rand 10;
    my $v2 = int rand 10;
    my $answer = $v1 * $v2;
    my $string = $v1 . "x" . $v2 . "=?";

    my ( $width, @pos ) = $self->letters( $string, 2 );
    my $banner = $self->toBanner( $width, @pos );
    ( $banner, $answer );
}



sub asciicaptcha2{
    my ( $self ) = @_;
    my @chars = ( 'a' .. 'z' );
    my $v1 = $chars[ int rand 26 ];
    my $v2 = $chars[ int rand 26 ];
    my $v3 = $chars[ int rand 26 ];
    my $v4 = $chars[ int rand 26 ];
    my $v5 = $chars[ int rand 26 ];
    my $answer = $v1.$v2.$v3.$v4.$v5;
    my $string = $answer;

    my ( $width, @pos ) = $self->letters( $string, 2 );
    my $banner = $self->toBanner( $width, @pos );
    ( $banner, $answer );
}



sub toBanner{
    my ( $self, $width, @pos ) = @_;
    my @map;
    my ( $columns, $rows, $xoffset, $yoffset ) = 
	split /\s+/, $self->{BDF}{METADATA}{FONTBOUNDINGBOX};
    foreach my $xy ( @pos ){
	my $x = $xy->[0] - $xoffset;
	my $y = $xy->[1] - $yoffset;
	$map[$y][$x] = 1;
    }

    my $lines;
    for(my $y=$rows-1; $y>=0;$y-- ){
	for(my $x=0; $x<=$width - $xoffset; $x++){
	    $lines .= $self->pix($map[$y][$x]);
	    $lines .= $self->pix($map[$y][$x]);
	}
	$lines .= "\n";
    }
    $lines;
}



sub pix{
    my ( $self, $v ) = @_;
    if ( $v ){
	$self->{heavyletters}[ rand( $#{$self->{heavyletters}} + 1 ) ];
    }
    else{
	if ( rand() < 0.05 ){
	    $self->{heavyletters}[ rand( $#{$self->{heavyletters}} + 1 ) ];
	}
	else{
	    $self->{lightletters}[ rand( $#{$self->{lightletters}} + 1 ) ];
	}
    }
}




    
sub letters{
    my ( $self, $string, $fluc ) = @_;
    my $xoffset = 0;
    my @pos;
    
    foreach my $letter ( split //, $string ){
	my ( $width, @p ) = $self->letter( $letter, $fluc );
	foreach my $xy ( @p ){
	    $xy->[0] +=  $xoffset;
	    push @pos, $xy;
	}
	$xoffset += $width;
    }
    ( $xoffset, @pos );
}


#
#
#
sub letter{
    my ( $self, $code, $fluc ) = @_;
    $code = ord( $code );
    my $char = $self->{BDF}->get_font_info_by_ENCODING( $code );

    my $width = $char->{DWIDTH}[0];
    my $firstline = $char->{BBX}[1] + $char->{BBX}[3] + int(rand($fluc*2+1)-$fluc);
    my $lines     = $char->{BBX}[1];
    my $xoffset   = $char->{BBX}[2];


    my @pos;
    foreach my $y ( 0 .. $lines - 1 ){
	my $line = $char->{BITMAP}[$y];
	my @chars = split //, $line;
	my @bits;
	foreach my $letter ( @chars ){
	    push @bits, @{$self->{bits}{$letter}};
	}
	for(my $x=0; $x<=$#bits; $x++){
	    if ( $bits[$x] ){
		push @pos, [ $x + $xoffset, $firstline - $y ];
	    }
	}
    }
    ( $width, @pos );
}
1;
