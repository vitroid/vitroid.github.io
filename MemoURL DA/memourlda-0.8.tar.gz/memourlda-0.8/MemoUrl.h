/******************************************************************************
 *
 * Copyright (c) 1999-2000 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: MemoUrl.h
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 *****************************************************************************/

#ifndef _MEMOURL_H_

#define _MEMOURL_H_

#include <PalmOS.h>

#define appFileCreator			'asUR'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01
#define AppType					'appl'
#define DBType					'Data'
//#define DBType					'asUR'
#define MEMOURL_DBNAME			"asDB_URL"

#ifdef VERSION1_0
#define MEMOURL_DB_MAX			255

#define TITLE_LEN				128
#define URL_LEN					256
#endif

#define AMSOFT_URL_TITLE		"AMsoft WEB Page"
#define AMSOFT_URL				"http://www.geocities.co.jp/SiliconValley/6737/"

#define CHECK_ON				1
#define CHECK_OFF				0

#define OPENTYPE_NUM			3
#define OPENTYPE_NONE			0
#define OPENTYPE_ONCE			1
#define OPENTYPE_EVERY			2

#define DEF_URL					"http://www."
#define DEF_URL_TITE			"�V�K�u�b�N�}�[�N"

#define EDITMODE_NEW			0
#define EDITMODE_EDIT			1

#define COUNTER_LEN				13

#ifdef VERSION1_0
// �u�b�N�}�[�N���R�[�h - �f�[�^�x�[�X�̂P���R�[�h�f�[�^
typedef struct {
	short key;
	short openType;
	char url[URL_LEN];
	char title[TITLE_LEN];
} BookmarkRec;
#else
//1.4�ȍ~�́Aurl��title��ASCIZ�A�ϒ��ƂȂ���
typedef struct {
	short key;
	short openType;
} BookmarkRec;
#endif

#endif // _MEMOURL_H_
