#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "googleda_rcp.h"
#include "MemoUrl.h"
#include "memourlcore.h"

void GoogleUrl(const Char *word, const Char *params, Char *url)
{
    Char binhex[]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f',};
    Char* p=url;
    unsigned char* wp;
    StrPrintF(url,"http://www.google.com/search?%s&q=",params);
    p+=StrLen(url);
    wp=word;
    while(*wp!=0){
	if(((*wp>='0')&&(*wp<='9'))||
	   ((*wp>='A')&&(*wp<='Z'))||
	   ((*wp>='a')&&(*wp<='z'))){
	    *p=*wp;
	    p++;
	}else{
	    p[0]='%';
	    p[1]=binhex[(*wp)>>4];
	    p[2]=binhex[(*wp)&15];
	    p+=3;
	}
	wp++;
    }
    *p='\0';
}

static void *GetObjectPtr(UInt16 objectID)
{
    FormPtr form;
    UInt16     index;
    void    *ptr;

    form  = FrmGetActiveForm();
    index = FrmGetObjectIndex(form, objectID);
    ptr   = FrmGetObjectPtr(form, index);
    return (ptr);
}

static Boolean DAHandleEvent(EventPtr event, DmOpenRef UrlDB)
{
    Boolean done = false;
    Boolean handled = false;
    //FormPtr form;
    FieldPtr field;
    Char* word;
    //Char test[200];
    
    RectangleType rec;
    UInt16 length;
    switch (event->eType) {
    case keyDownEvent:
      /*
      if (TxtCharIsHardKey(event->data.keyDown.chr)) {
	EvtAddEventToQueue(event);
	done = true;
	handled = true;
      }else if(event->data.keyDown.chr == pageUpChr && g->len != 0){
	Findnext(g,-1,-1);
	handled = true;
      }else if(event->data.keyDown.chr == pageDownChr && g->len !=0){
	Findnext(g,1,1);
	handled = true;
      }
      */
      break;
    case appStopEvent:
      EvtAddEventToQueue(event);
      done = true;
      handled = true;
      break;
    case penDownEvent:
      RctSetRectangle( &rec, 0, 0, coordGoogleW, coordGoogleH );
      if ( ! RctPtInRectangle( event->screenX, event->screenY, &rec ) ){
        done = true;
        handled = true;
      }
      break;
      
    case ctlSelectEvent:
      
      switch (event->data.ctlSelect.controlID) {
        
      case IdButtonC:
        done = true;
        handled = true;
        break;
        
      case IdButtonR:
        field=GetObjectPtr(IdWord);
	word = FldGetTextPtr(field);
	length = FldGetTextLength( field );
	if(word!=NULL){
	    UInt16 jp;
	    Char text[length+1];
	    Char title[length+30];
	    Char url[length*3+100];
	    //Char *text=MemPtrNew(length+1);
	    //Char *title=MemPtrNew(length+20);
	    //Char *url=MemPtrNew(length*3+100);
	    StrNCopy(text,word,length);//buggy
	    text[length]=0;//So it is required.
	    StrCopy(title,"Google search ");
	    StrCat(title,text);
	    jp=CtlGetValue( GetObjectPtr(IdJPages));
	    if(jp){
		GoogleUrl(text,"hl=ja&lr=lang_ja&ie=Windows-31J",url);
	    }else{
		GoogleUrl(text,"hl=ja",url);
	    }
	    AddUrlToDatabase(url,title,OPENTYPE_ONCE,UrlDB);
	    //MemPtrFree(text);
	    //MemPtrFree(title);
	    //MemPtrFree(url);
	}
        done = true;
        handled = true;
        break;
      }
      
      break;
      
    default:
      break;
    }
    if (!handled) {
      FrmHandleEvent(FrmGetActiveForm(), event);
    }
    return (done);
}


void EventLoop(DmOpenRef UrlDB)
{
    EventType event;
    Boolean done = false;
    UInt16 error;
    do {
	EvtGetEvent(&event, evtWaitForever);
	if (SysHandleEvent(&event))
	    continue;
	if (MenuHandleEvent(NULL, &event, &error))
	    continue;
	done = DAHandleEvent(&event, UrlDB);
    } while (!done);
}

