/*Register MML to syssoundDB*/
#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "memourlda_rcp.h"
#include "memourlcore.h"
#include "selection.h"
extern void EventLoop(DmOpenRef);

/*
 * start routine
 */

void da_main();

void start()
{
    da_main();
}

#define MemoURLDACreatorID 'mmuA'

void da_main()
{
    Char HTTP[]="http://";
    UInt16 selectionlength=7;
    DmOpenRef UrlDB;
    FormPtr form;
    UInt32 romVersion;
    Char *selection=NULL;
    UInt32 feature = 0;
    if (FtrGet(MemoURLDACreatorID, 0, &feature) == 0) {
	return;
    } else {
	FtrSet(MemoURLDACreatorID, 0, feature);
    }
    FtrGet(sysFtrCreator,sysFtrNumROMVersion,&romVersion);
    if(romVersion<0x03000000) return;
    selection=GetSelection(true,&selectionlength);
//$B$3$3$G@h$K(BDB$B$r3+$$$F$_$F!"<:GT$7$?$i(Bexit$B$7$F$7$^$(!#(B
    UrlDB=MemoUrlOpenDatabase();
    if(UrlDB){
	FieldType*  field;
	Char url[selectionlength+1];
	Char* pos=NULL;
	Char null[]="\0";
	Char* titleP;
	Char* urlP;
	UInt16 titlelen,urllen;
	if(selection)
	    pos=StrStr(selection,"http");
	if(pos){
	    titlelen=pos-selection;
	    urllen=selectionlength-titlelen;
	    StrNCopy(url,pos,urllen);
	    *pos='\0';
	    titleP=selection;
	    urlP=url;
	}else{
	    titlelen=0;
	    titleP=null;
	    //if(MemPtrResize(selection,selectionlength+8)){
	    MemMove(selection+7,selection,selectionlength+1);
	    MemMove(selection,HTTP,7);
	    selectionlength+=7;
	    //}
	    urllen=selectionlength;
	    urlP=selection;
	}
	form=FrmInitForm(IdForm);
	field = FrmGetObjectPtr( form, FrmGetObjectIndex( form, IdTitle) );
	FldInsert( field, titleP, titlelen );
	field = FrmGetObjectPtr( form, FrmGetObjectIndex( form, IdUrl ) );
	FldInsert( field, urlP, urllen );
	MemPtrFree(selection);
	FrmSetActiveForm(form);
	FrmDrawForm(form);
	FrmSetFocus(form,FrmGetObjectIndex(form,IdTitle));
	EventLoop(UrlDB);
	if(UrlDB)
	    DmCloseDatabase( UrlDB );
	FrmEraseForm(form);
	FrmDeleteForm(form);
    }else{
	if(selection!=NULL)
	    MemPtrFree(selection);
    }
    /*release feature*/
    if (FtrGet(MemoURLDACreatorID, 0, &feature) == 0) {
	FtrUnregister(MemoURLDACreatorID, 0);
    }
}

