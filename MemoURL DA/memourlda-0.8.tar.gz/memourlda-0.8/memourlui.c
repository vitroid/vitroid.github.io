/*Register MML to syssoundDB*/
#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "memourlda_rcp.h"
#include "MemoUrl.h"
#include "memourlcore.h"

static void *GetObjectPtr(UInt16 objectID)
{
    FormPtr form;
    UInt16     index;
    void    *ptr;

    form  = FrmGetActiveForm();
    index = FrmGetObjectIndex(form, objectID);
    ptr   = FrmGetObjectPtr(form, index);
    return (ptr);
}

static Boolean DAHandleEvent(EventPtr event, DmOpenRef UrlDB)
{
    Boolean done = false;
    Boolean handled = false;
    FormPtr form;
    Char *url, *title, null[]="\0";
    RectangleType rec;
    switch (event->eType) {
    case keyDownEvent:
      /*
      if (TxtCharIsHardKey(event->data.keyDown.chr)) {
	EvtAddEventToQueue(event);
	done = true;
	handled = true;
      }else if(event->data.keyDown.chr == pageUpChr && g->len != 0){
	Findnext(g,-1,-1);
	handled = true;
      }else if(event->data.keyDown.chr == pageDownChr && g->len !=0){
	Findnext(g,1,1);
	handled = true;
      }
      */
      break;
    case appStopEvent:
      EvtAddEventToQueue(event);
      done = true;
      handled = true;
      break;
    case penDownEvent:
      RctSetRectangle( &rec, 0, 0, coordMemoURLDAW, coordMemoURLDAH );
      //form = FrmGetActiveForm();
      //FrmGetFormBounds( form, &rec );
      if ( ! RctPtInRectangle( event->screenX, event->screenY, &rec ) ){
        done = true;
        handled = true;
      }
      break;
      
    case ctlSelectEvent:
      
      switch (event->data.ctlSelect.controlID) {
        
      case IdButtonC:
        done = true;
        handled = true;
        break;
        
      case IdButtonR:
	//idfield��������擾���Atitle��o�^����B
	  //����14�N3��17��(��)���݁AURL�͕ҏW���Ă����������B
	title = FldGetTextPtr(GetObjectPtr(IdTitle));
	url   = FldGetTextPtr(GetObjectPtr(IdUrl));
	if(url==NULL)
	    url=null;
	if(title==NULL)
	    title=null;
	AddUrlToDatabase(url,title,OPENTYPE_ONCE,UrlDB);
        done = true;
        handled = true;
        break;
      }
      
      break;
      
    default:
      break;
    }
    if (!handled) {
      FrmHandleEvent(FrmGetActiveForm(), event);
    }
    return (done);
}


void EventLoop(DmOpenRef UrlDB)
{
    EventType event;
    Boolean done = false;
    UInt16 error;
    do {
	EvtGetEvent(&event, evtWaitForever);
	if (SysHandleEvent(&event))
	    continue;
	if (MenuHandleEvent(NULL, &event, &error))
	    continue;
	done = DAHandleEvent(&event, UrlDB);
    } while (!done);
}

