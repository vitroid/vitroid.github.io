#define IdForm          1000
#define IdHelp          1001
#define IdLabelT        2000
#define IdLabelU        2001
#define IdTitle         3000
#define IdUrl           3001
#define IdButtonR       4000
#define IdButtonC       4001

#define coordMemoURLDAX    2
#define coordMemoURLDAY    66
#define coordMemoURLDAW    156
#define coordMemoURLDAH    92
