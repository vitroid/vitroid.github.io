#ifndef MEMOURLUI_H
#define MEMOURLUI_H
void EventLoop(DmOpenRef UrlDB);
#endif
