#include "selection.h"

/*clearclipboard: cleans clipboard if set
  length: given: excess string length(usually 0, it is a dirty hack to avoid using MemPtrResize....)
  returns: length of selected text (not including the terminator)*/
Char *GetSelection(Boolean clearclipboard, UInt16 *length)
{
    UInt16 selectionlength=0;
    MemHandle handle=NULL;
    FormPtr form;
    UInt16 focus;

    Char *selectioncopy=NULL;
    form=FrmGetActiveForm();
    focus=FrmGetFocus(form);
    if(focus!=noFocus){
	Char *selection=NULL;
	UInt16 start,end;
	FieldPtr field;
	field=FrmGetObjectPtr(form,focus);
	switch(FrmGetObjectType(form,focus)){
	case frmTableObj:
	    field=TblGetCurrentField(field);
	    //continue
	case frmFieldObj:
	    selection=FldGetTextPtr(field);
	    if(selection!=NULL){
		FldGetSelection(field,&start,&end);
		selectionlength=end-start;
		selectioncopy=MemPtrNew(selectionlength+1+*length);
		if(selectioncopy!=NULL){
		    StrNCopy(selectioncopy,selection+start,selectionlength);
		    selectioncopy[selectionlength]=0;
		}
	    }
	    break;
	default:
	    break;
	}
    }
    if(selectioncopy==NULL||selectionlength==0){
	handle = ClipboardGetItem(clipboardText,&selectionlength);
	if (handle != NULL) {
	    selectioncopy=MemPtrNew(selectionlength+1+*length);
	    if(selectioncopy!=NULL){
		StrNCopy(selectioncopy,MemHandleLock(handle),selectionlength);
		selectioncopy[selectionlength]=0;
		MemHandleUnlock(handle);
	    }
	}
	if(clearclipboard){
	    Char null[]="";
	    ClipboardAddItem(clipboardText,null,0);
	}
    }
    if(selectioncopy==NULL){
	selectionlength=0;
	selectioncopy = MemPtrNew(1+*length);
    }
    *length=selectionlength;
    return selectioncopy;
}
