#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#define DWord UInt32
#define Ptr void *
#define Byte Char
#define Word UInt16
#include "DropModule.h"
#include "MemoUrl.h"
#include "memourlcore.h"

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Char HTTP[]="http://";
  tDropLaunchCmdParamPtr param = (tDropLaunchCmdParamPtr)cmdPBP;
  if(cmd == dDropLaunchSupportCmd) {
    DWord romVersion;
    FtrGet(sysFtrCreator,sysFtrNumROMVersion,&romVersion);
    if(romVersion<0x03000000)
      return 0;
    else
      return dYes_Support;
  } else if(cmd == dDropLaunchCmd) {
    // set as default settings
    param->resultBehavior = eBehavior_Do_Nothing;
    param->resultText = 0;
    // dispatch...
    switch (param->selector) {
    case 0:
    {
        //open db
	DmOpenRef urldb=MemoUrlOpenDatabase();
	if(urldb){
	    char text[param->srcTextLength+8];
	    char url[param->srcTextLength+1];
	    char null[]="\0";
	    char *pos;
	    UInt16 urllen,titlelen;
	    //Add 0 to selected text
	    StrNCopy(text,param->srcText,param->srcTextLength);
	    text[param->srcTextLength]=0;//$BG0$N$?$a!#$3$l$,$J$$$H$J$<$+8mF0:n$9$k!#(B
	    //separate title and url
	    pos=StrStr(text,"http");
	    if(pos){
		titlelen=pos-text;
		urllen=param->srcTextLength-titlelen;
		StrNCopy(url,pos,urllen);
		url[urllen]=0;
		*pos='\0';
		AddUrlToDatabase(url,text,OPENTYPE_ONCE,urldb);
	    }else{
		//whole string is regarded as a url
		MemMove(text+7,text,param->srcTextLength+1);
		MemMove(text,HTTP,7);
		AddUrlToDatabase(text,null,OPENTYPE_ONCE,urldb);
	    }
	    if(urldb)
		DmCloseDatabase( urldb );
	}
	return 0;
    }
    default:
      break;
    }
    return 0; // never executed.
  } else if(cmd == sysAppLaunchCmdNormalLaunch) {
  }
}
