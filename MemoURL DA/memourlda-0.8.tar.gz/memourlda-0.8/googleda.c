#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "googleda_rcp.h"
#include "memourlcore.h"
#include "selection.h"
extern void EventLoop(DmOpenRef);

/*
 * start routine
 */

void da_main();

void start()
{
    da_main();
}

#define GoogleDACreatorID 'gsuA'

void da_main()
{
    UInt16 selectionlength=0;
    DmOpenRef UrlDB;
    UInt32 romVersion;
    Char *selection=NULL;
    UInt32 feature = 0;
    if (FtrGet(GoogleDACreatorID, 0, &feature) == 0) {
	return;
    } else {
	FtrSet(GoogleDACreatorID, 0, feature);
    }
    FtrGet(sysFtrCreator,sysFtrNumROMVersion,&romVersion);
    if(romVersion<0x03000000) return;
    selection=GetSelection(true,&selectionlength);
//$B$3$3$G@h$K(BDB$B$r3+$$$F$_$F!"<:GT$7$?$i(Bexit$B$7$F$7$^$(!#(B
    UrlDB=MemoUrlOpenDatabase();
    if(UrlDB){
	FieldType*  field;
	FormPtr form;
	form=FrmInitForm(IdForm);
	if(selectionlength){
	    field = FrmGetObjectPtr( form, FrmGetObjectIndex( form, IdWord) );
	    FldInsert( field, selection, selectionlength );
	    FldSetSelection( field, 0, selectionlength);
	}
	CtlSetValue( FrmGetObjectPtr( form, FrmGetObjectIndex( form, IdJPages)), true );
	FrmSetActiveForm(form);
	FrmDrawForm(form);
	FrmSetFocus(form,FrmGetObjectIndex(form,IdWord));
	EventLoop(UrlDB);
	if(UrlDB)
	    DmCloseDatabase( UrlDB );
	FrmEraseForm(form);
	FrmDeleteForm(form);
    }
    if(selection!=NULL)
	MemPtrFree(selection);
    /*release feature*/
    if (FtrGet(GoogleDACreatorID, 0, &feature) == 0) {
	FtrUnregister(GoogleDACreatorID, 0);
    }
}

