#define IdForm          1000
#define IdHelp          1001
#define IdLabelW        2000
#define IdWord          3000
#define IdButtonR       4000
#define IdButtonC       4001
#define bmpBanner       5000
#define IdJPages        6000

#define coordGoogleX    2
#define coordGoogleY    55
#define coordGoogleW    156
#define coordGoogleH    103
