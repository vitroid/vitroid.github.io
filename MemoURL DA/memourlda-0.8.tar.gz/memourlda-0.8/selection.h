#ifndef _SELECTION_M
#define _SELECTION_M

#include <PalmOS.h>
Char *GetSelection(Boolean clearclipboard, UInt16 *length);

#endif
