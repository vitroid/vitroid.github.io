#ifndef MEMOURLCORE_H
#define MEMOURLCORE_H

DmOpenRef MemoUrlOpenDatabase();
int AddUrlToDatabase(char* url, char* title,short opentype, DmOpenRef UrlDB);
#endif
