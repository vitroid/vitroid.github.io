#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "memourlda_rcp.h"
#include "MemoUrl.h"

#ifdef VERSION1_0
/***********************************************************************

	BookmarkRec $B=i4|2==hM}(B

 ***********************************************************************/
Boolean InitBookmark(BookmarkRec *pBookmarkRec){
	Err err;
	
	pBookmarkRec->key = 0;
	pBookmarkRec->openType = 0;
	err = MemSet(pBookmarkRec->url, sizeof(pBookmarkRec->url), 0);
	if( err )
		return false;
	err = MemSet(pBookmarkRec->title, sizeof(pBookmarkRec->title), 0);
	if( err )
		return false;
	return true;	
}

/***********************************************************************

	Bookmark $B%Q%i%a!<%?@_Dj4X?t(B

 ***********************************************************************/
Boolean SetBookmark(BookmarkRec *pBookmarkRec, short key, short openType, char *pUrl, char *pTitle){
    UInt16 len;
	
	InitBookmark(pBookmarkRec);
	pBookmarkRec->key = key;
	pBookmarkRec->openType = openType;
	len = StrLen(pUrl);
	if( len > URL_LEN )
		len = URL_LEN;
	StrNCopy(pBookmarkRec->url, pUrl, len);
	len = StrLen(pTitle);
	if( len > TITLE_LEN )
		len = TITLE_LEN;
	StrNCopy(pBookmarkRec->title, pTitle, len);
	
	return true;
}
#endif /*VERSION1_0*/

DmOpenRef MemoUrlOpenDatabase()
{
    return DmOpenDatabaseByTypeCreator( DBType, appFileCreator, dmModeReadWrite );
}

#ifdef VERSION1_0
int AddUrlToDatabase(char* url, char* title,short opentype, DmOpenRef UrlDB)
{
    BookmarkRec bookmark;
    UInt16	recordSize, index, offset;
    MemHandle recHdl;
    SetBookmark(&bookmark, 1, opentype, url, title);
    recordSize = sizeof(bookmark);
    recHdl = DmNewRecord(UrlDB, &index, recordSize);// $B%l%3!<%I$r3NJ](B
    if( recHdl ){
	MemPtr recPtr;
	// $B%l%3!<%I$rDI2C(B
	recPtr = MemHandleLock(recHdl);
	DmSet( recPtr, 0, recordSize, 0);
	offset = 0;
	
	DmWrite(recPtr, offset, &bookmark, sizeof(bookmark));
	
	MemHandleUnlock(recHdl);
	DmReleaseRecord(UrlDB, index, true);
    }
    return 0;
}
#else /*VERSION1_0*/
int AddUrlToDatabase(char* url, char* title,short opentype, DmOpenRef   UrlDB)
{
    UInt16	recordSize, index, offset;
    MemHandle   recHdl;
    BookmarkRec bookmark;
    bookmark.key = 1;
    bookmark.openType = opentype;
    recordSize = sizeof(bookmark);
    recHdl = DmNewRecord(UrlDB, &index, recordSize + 2 + StrLen( url ) + StrLen( title ) );// $B%l%3!<%I$r3NJ](B
    
    if( recHdl ){
        MemPtr recPtr;
        Int16 length;
        // $B%l%3!<%I$rDI2C(B
        recPtr = MemHandleLock(recHdl);
        DmSet( recPtr, 0, recordSize, 0);
        offset = 0;
        length = sizeof( bookmark );
        DmWrite(recPtr, offset, &bookmark, length);
        offset += length;
        
        length = StrLen( url ) + 1;
        DmWrite(recPtr, offset, url, length );
        offset += length;
        
        length = StrLen( title ) + 1;
        DmWrite(recPtr, offset, title, length);
        
        MemHandleUnlock(recHdl);
        DmReleaseRecord(UrlDB, index, true);
    }
}
#endif /*VERSION1_0*/
