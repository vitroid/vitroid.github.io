void rotmx2(double x1,double y1,double z1,double x2,double y2,double z2,double *qa,double *qb,double *qc,double *qd);

