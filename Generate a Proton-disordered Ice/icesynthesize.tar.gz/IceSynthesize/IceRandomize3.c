/*$BJ?@.#1#3G/#17n#9F|(B($B2P(B)IceMCMC$B$r%Y!<%9$K!"C1$K%i%s%@%`(BIce$B$r@8@.$9$k!#(B15$BJ,$[$I$G$G$-$?!#(B
$BJ?@.#1#3G/#17n#9F|(B($B2P(B)$B%7%9%F%`%5%$%:$,Bg$-$$;~$O!"4DO)$rA\$9$N$KHs>o$K;~4V$,$+$+$k$N$G!"$"$^$j$h$$J}K!$G$O$J$$!#$O$8$a$K%i%s%@%`$K7k9g$r$P$i$^$$$F!"$=$3$+$iBP>CLG$5$;$?J}$,B.$$$K$A$,$$$J$$!#(B*/
/*$BJ?@.#1#3G/#17n#1#0F|(B($B?e(B)ProtonXfer/IceRandomize2$B$r%Y!<%9$K!":BI8Hs0MB8$K2~NI$9$k!#(B*/
/*$BJ?@.#1#3G/#17n#1#1F|(B($BLZ(B)$B7g4Y$rF3F~$7$?>l9g$G$b?tIC$G7W;;$G$-$k$h$&$K$J$C$?!#(B*/

/* $Id: IceRandomize3.c,v 1.1 2002/08/26 09:53:27 matto Exp $
 * $Log: IceRandomize3.c,v $
 * Revision 1.1  2002/08/26 09:53:27  matto
 * Many programs are added for backup.
 * I don't know which is important one.
 *
 * Revision 1.1  2001/01/09 04:53:35  matto
 * Ice_SetPath is modified to use new Ice_DopeDefects subroutine.
 * IceRandomize makes a graph random.
 *
 * Revision 1.3  2000/10/04 10:45:56  matto
 * Ice_SetGraph is replaced by Ice_SetGraph2.
 *
 * Revision 1.2  1999/09/07 07:49:00  matto
 * IceConfig produces one proton configuration from a graph.
 *
 * Revision 1.1  1999/09/04 05:23:07  matto
 * *** empty log message ***
 *
 * Revision 1.4  98/02/03  14:38:11  14:38:11  matto (Masakazu MATSUMOTO)
 * First version of runnable canonical monte carlo.
 * 
 * Revision 1.3  98/02/03  14:13:05  14:13:05  matto (Masakazu MATSUMOTO)
 * Energy calculation is checked. now ready for MC.
 * 
 * Revision 1.2  98/02/03  10:41:22  10:41:22  matto (Masakazu MATSUMOTO)
 * the field "outbit" of the structure sIceNode is removed.
 * 
 * Revision 1.1  98/02/03  09:31:43  09:31:43  matto (Masakazu MATSUMOTO)
 * Initial revision
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "SparseMatrix.h"
#define Error(x,y) fprintf(stderr,x,y),exit(1)
extern double drand48();
extern double exp(double);

/*SparseMatrix$B$rL58~NY@\9TNs$H$_$J$7!"%i%s%@%`$K7k9g$rM-8~2=$9$k!#(B*/
void SparseMatrix_RandomDirectionalize(sSparseMatrix *g)
{
  int i,j;
  for(i=0;i<g->nline;i++){
    for(j=0;j<g->e_line[i].nadj;j++){
      int k=g->e_line[i].adj[j];
      if(k>i){
	int r=drand48()>0.5;
	SparseMatrix_RegisterValue(g,i,k,1+r);/*the value is 1 or 2*/
	SparseMatrix_RegisterValue(g,k,i,2-r);
      }
    }
  }
}

/*defect list*/
int *stack,sp=0;

int IsDefect(sSparseMatrix *g,int i)
{
  int j;
  int na=0;
  for(j=0;j<g->e_line[i].nadj;j++){
    int k=g->e_line[i].adj[j];
    na+=(SparseMatrix_QueryValue(g,i,k)==2);
  }
  return na;
}

/*SparseMatrix$B$rI9$NNY@\9TNs$H$_$J$7!"(B2$BK\0J>eF~7k9g$N$"$k@aE@$r5-O?$9$k!#(B*/
void PushAllDefects(sSparseMatrix *g)
{
  int i;
  for(i=0;i<g->nline;i++){
    if(IsDefect(g,i)>2){
      stack[sp]=i;
      sp++;
    }
  }
}

void EraseAllDefects(sSparseMatrix *g)
{
  while(sp>0){
    int i,na,j,k;
    sp--;
    i=stack[sp];
    while((na=IsDefect(g,i))>2){
      if(na>3){
	stack[sp]=i;
	sp++;
      }
      j=drand48()*g->e_line[i].nadj;
      k=g->e_line[i].adj[j];
      if(SparseMatrix_QueryValue(g,i,k)==2){
	SparseMatrix_RegisterValue(g,i,k,1);
	SparseMatrix_RegisterValue(g,k,i,2);
	i=k;
      }
    }
  }
}

void SparseMatrix_NormalizeDirMatrix(sSparseMatrix *g)
{
  int i,j;
  for(i=0;i<g->nline;i++){
    for(j=0;j<g->e_line[i].nadj;j++){
      int k=g->e_line[i].adj[j];
      if(SparseMatrix_QueryValue(g,i,k)==2){
	SparseMatrix_RegisterValue(g,i,k,0);
      }
    }
  }
}

int *mark;

/*$B$3$N(BSAW$B$O$"$^$j$KCY$9$.$k!#<+8J2sHr$7$J$$$G9bB.$K?lJb$9$kJ}K!$r9M$($h!#(B
$B:GC;7PO)$G$h$1$l$P!"$7$i$_$D$V$7$K$"$?$kJ}$,$h$$!#(B*/
int FindPath(sSparseMatrix *g,int start,int end)
{
  int j,head,bottom,skip;
  /*printf("%d\n",start);*/
  if(start==end){
    stack[sp]=start;
    sp++;
    return 1;
  }
  if(mark[start])return 0;
  stack[sp]=start;
  sp++;
  mark[start]=1;
  /*
  for(j=0;j<sp;j++){
    printf("%d:%d ",stack[j],mark[stack[j]]);
  }
  printf("\n");
  */
  if(drand48()<0.5){
    head=0;
    bottom=g->e_line[start].nadj;
    skip=1;
  }else{
    head=g->e_line[start].nadj-1;
    bottom=-1;
    skip=-1;
  }
  for(j=head;j!=bottom;j+=skip){
    int k;
    k=g->e_line[start].adj[j];
    /*printf("%d/%d/%d \n",j,k,mark[93]);*/
    if(SparseMatrix_QueryValue(g,start,k)==1)
      if(FindPath(g,k,end))
	return 1;
  }
  mark[start]=0;
  sp--;
  return 0;
}

void FlipAlongThePath(sSparseMatrix *g)
{
  int i,j;
  while(sp>1){
    i=stack[sp-2];
    j=stack[sp-1];
    sp--;
    /*printf("%d ",SparseMatrix_QueryValue(g,i,j));*/
    SparseMatrix_RegisterValue(g,i,j,2);
    SparseMatrix_RegisterValue(g,j,i,1);
  }
  /*printf("\n");*/
}

/*spread.$B$G$-$k$@$16Q<A$KC5:w$9$k$h$&!"(Bstep by step$B$G@.D9$5$;$k!#(B*/
int FindPath2(sSparseMatrix *g,int start,int end)
{
  int s,sps,spe;
  for(s=0;s<g->nline;s++){
    mark[s]=-1;
  }
  mark[start]=-2;
  sp=0;
  sps=sp;
  stack[sp++]=start;
  spe=sp;
  while(1){
    for(s=sps;s<spe;s++){
      int j,i=stack[s];
      for(j=0;j<g->e_line[i].nadj;j++){
	int k=g->e_line[i].adj[j];
	if((mark[k]==-1)&&(SparseMatrix_QueryValue(g,i,k)==1)){
	  mark[k]=i;
	  if(k==end)return;
	  stack[sp++]=k;
	}
      }
    }
    sps=spe;
    spe=sp;
  }
}

void FlipAlongThePath2(sSparseMatrix *g,int end)
{
  int i,j;
  while(1){
    i=mark[end];
    if(i<0)return;
    j=end;
    /*printf("%d ",SparseMatrix_QueryValue(g,i,j));*/
    SparseMatrix_RegisterValue(g,i,j,2);
    SparseMatrix_RegisterValue(g,j,i,1);
    end=i;
  }
  /*printf("\n");*/
}

int main(int argc,char *argv[])
{
  /*Network Topology*/
  sSparseMatrix *graph=NULL;
  /*work*/
  char buf[256];
  int seed=getpid();
  /*getopt*/
  int error=0;
  int start=-1,end;
  
  switch(argc)
    {
    case 4:
      start=atoi(argv[2]);
      end=atoi(argv[3]);
    case 2:
      seed=atoi(argv[1]);
    case 1:
      break;
    default:
      error++;
      break;
    }
  if(error)
    {
      fprintf(stderr,"usage : %s [randomseed [start end]]\n",argv[0]);
      fprintf(stderr,"\tstart and end specify the positions of the defects to be doped.\n");
      
      exit(1);
    }
  srand48(seed);/*$BK\HV$OGO>l$/$s$N;;Dx$r;H$&$3$H(B*/
  fprintf(stderr,"RandomSeed: %d\n",seed);
  while(NULL!=fgets(buf,sizeof(buf),stdin))
    {
    retry:
      /*find and read graph*/
      if(0==strncmp(buf,"@GRPH",5)){
	fprintf(stderr,buf);
	graph = SparseMatrix_LoadGRPH(stdin,16,5);
      }
      /*find and read graph*/
      if(0==strncmp(buf,"@NGPH",5)){
	fprintf(stderr,buf);
	graph = SparseMatrix_LoadNGPH(stdin,17,5);
      }
    }
  if(graph==NULL){
    Error("Insufficient input.\n",0);
  }
  stack=calloc(graph->nline*4,sizeof(int));
  /*$B7k9g$r%i%s%@%`$KM-8~2=$9$k!#(B*/
  SparseMatrix_RandomDirectionalize(graph);
  PushAllDefects(graph);
  EraseAllDefects(graph);
  if(start>=0){
    mark=calloc(graph->nline,sizeof(int));
    FindPath2(graph,start,end);
    FlipAlongThePath2(graph,end);
    free(mark);
  }
  SparseMatrix_NormalizeDirMatrix(graph);
  SparseMatrix_SaveNGPH(stdout,graph);
    
  exit(0);
}

