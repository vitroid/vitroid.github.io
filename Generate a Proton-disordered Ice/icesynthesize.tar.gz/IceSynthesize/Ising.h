#ifndef _ISING_H
#define _ISING_H
/* $Id: Ising.h,v 1.2 2001/09/10 08:42:21 matto Exp $
 * $Log: Ising.h,v $
 * Revision 1.2  2001/09/10  08:42:21  matto
 * o Dijkstra's algorithm is implemented in Graph.c to make distance matrix.
 * o Mcmc.c is modified.
 *
 * Revision 1.1.1.1  1998/09/29 16:10:34  matto
 *
 * Revision 1.1  98/02/03  09:31:52  09:31:52  matto (Masakazu MATSUMOTO)
 * Initial revision
 * 
 */

/*Ising$B%b%G%k$N3J;RE@$rI=8=$9$k7?(B*/
typedef struct
{
  /*$BAj8_:nMQ$9$kAj<j$N?t(B*/
  int npartner;
  /*$BAj8_:nMQ$9$kAj<j$X$N%]%$%s%?$NI=!#(B*/
  /*  struct _sIsingNode **partner;*/
  /*$B$G$-$l$P%]%$%s%?$GI=$7$?$$$N$@$,!"(B2$BBNAj8_:nMQI=$,(B2$B<!85G[Ns$K$J$C$F(B
  /*$B$$$k$?$a!"$3$3$@$1%]%$%s%?$K$7$F$b!"$"$H$N%3!<%I$,$d$d$3$7$/$J$k$@(B
  /*$B$1!#%N!<%I$KHV9f$rIU$1$k$N$O!"HFMQ@-$,0-$/$J$k$,!"(BHash$BI=$r:n@.$9$k(B
  /*$B$N$HF1MM$N9bB.2=$N8z2L$b$"$k!#(B*/
  /*$BAj8_:nMQ$9$kAj<j$NHV9f(B*/
  int *partner;
  /*$B$H$j$&$k>uBV$N?t(B*/
  int nstatus;
  /*$B8=:_$N>uBV(B*/
  int status;
}
sIsingNode;
/*status$B$r$I$N$h$&$K(Bupdate$B$9$k$+$O!"<BAu0MB8(B*/

/*$B3J;RA4BN$NAj8_:nMQ$rI=8=$9$k7?(B*/
typedef struct
{
  /*$B%7%9%F%`$K4^$^$l$k%N!<%I$N?t(B*/
  int nnode;
  sIsingNode *node;
  /*$BAj8_:nMQ$N?t(B ( <nnode*nnode/2 )*/
  int nintr;
  /*$B$=$l$>$l$N%N!<%IBP$N!"Aj8_:nMQI=$NI=!#(Bintr[i*nnode+j][ci*j.nstatus+cj]$B$O(B
    $B%N!<%IBP(B{i,j}($B$?$@$7(Bi<j)$B$K$*$$$F!"%N!<%I(Bi$B$,>uBV(Bci$B!"%N!<%I(Bj$B$,>uBV(Bcj
    $B$r$H$k;~$NBPAj8_:nMQ%(%M%k%.!<$rI=$o$9!#(B*/
  double **intr;
}
sIsing;

void IsingNode_Init(sIsingNode *i,int maxpartner,int maxstatus);
void IsingNode_InsertPartner(sIsingNode *i,int j);
/*Methods definition*/
sIsing *Ising(FILE *etbl);
/*$B%N!<%IBP(B{i,j}$B$N%(%M%k%.!<$r7W;;$9$k!#(B*/
double Ising_PairEnergy(sIsing *ising,int i,int j);
/*$BA4%(%M%k%.!<$r$^$H$a$F7W;;$9$k!#(B*/
double Ising_TotalEnergy(sIsing *ising);
/*$BJ#?t$N%N!<%I$N>uBV$rJQ2=$5$;$?;~$N!"A4%(%M%k%.!<$N:9J,$r7W;;$9$k(B*/
double Ising_DiffEnergy(sIsing *ising,int nnode,int *node,int
		       *newstatus);
void Ising_Snapshot(sIsing *i,FILE *file);

#endif
