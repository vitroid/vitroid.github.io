#include "Ice.h"
#include "SparseMatrix.h"

sSparseMatrix *Ice_ConvertIntoSparseMatrix(sIce *ice)
{
  int i;
  sSparseMatrix *graph=SparseMatrix_Init(ice->nnode,ice->nnode,16,4);
  for(i=0;i<ice->nnode;i++){
    sIceNode *in=&ice->icenode[i];
    if(in->out0>=0)
      SparseMatrix_RegisterValue(graph,i,in->out0,1);
    if(in->out1>=0)
      SparseMatrix_RegisterValue(graph,i,in->out1,1);
  }
  return graph;
}
