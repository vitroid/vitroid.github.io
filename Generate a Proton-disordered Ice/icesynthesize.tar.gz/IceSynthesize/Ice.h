#ifndef _ICE_H
#define _ICE_H
#include "Graph.h"
#include "SparseMatrix.h"
/*$BI9$N9=B$$H!"(BIsing$B$r7R$0$?$a$N9=B$BN(B*/
typedef struct {
  /*$B%0%i%U$G@\B3$5$l$F$$$kNY@\%N!<%I$N?t(B*/
  int nadj;/*to be read in Ice()*/
  /*$BNY@\%N!<%I$NHV9f!#>.$5$$=g$KJB$Y$k!#(B*/
  int *adj;/*to be read in Ice()*/
  /*$B6!M?7k9g$NK\?t(B*/
  int nout;
  /*$B8=:_$N>uBV$rI=$9%S%C%HNs!#6!M?7k9g$J$i(B1$B$r$o$j$"$F$k(B*/
  /*  int outbit;$B$d$d$3$7$/$J$k85$J$N$G!":o=|$9$k!#(B*/
  /*Only two bonds will be donated because it is ICE! negative number
    indicates it is unbonded.*/
  /* out0 must be < out1 */
  int out0,out1;
  /*they are used for mc trials*/
  /* new0 < new1 */
  int new0,new1;
  /*$B%S%C%HJB$S$GI=8=$5$l$k!"%N!<%I$N>uBV$r!">uBVHV9f$KJQ49$9$k$?$a$N%F!<(B
  /*$B%V%k(B*/
  int nstatus; /*to be read in Ice()*/
  int *encoding;/*to be read in Ice()*/
  int *status;/*$BJ?@.#1#3G/#17n#1#9F|(B($B6b(B)$BDI2C(B*/
}
sIceNode;

/*Structure of the Ice*/
typedef struct{
  int nnode;
  sIceNode *icenode;
  /*chain reaction path node*/
  int path[100];
  /*flags for searching paths*/
  int *mark;
  /*length of the reaction path*/
  int last;
}
sIce;

int Ice_NodeOutBit(sIceNode *in);
/*same routine as IceNodeOutBit(), for new0 and new1*/
int Ice_NodeNewOutBit(sIceNode *in);
/*read gcnf for ice*/
sIce *Ice(FILE *gcnf);
/*find a route to rearrange the hydrogen bond. Next node to go is */
/*chosen from two output node. Route should be self-avoiding.*/
/*This routine is moved from chainreaction.c 31JAN98*/
/*end indicates whether the path should be a chain or ring. If the
/*path should be a chain, a minus value is specified. If the path
/*should be a ring, the start node is specified.*/
/*depth indicates the depth of the recursion*/
/*current indicates the current node*/
/*if a appropriate path is found, the routine returns 1*/
int Ice_Route(sIce *ice,int end,int depth,int current);
/*Find a flip-flop rearrangement path randomly.*/
int Ice_DopeDefects(sIce *ice,int start,int end);
void Ice_SetPath(sIce *ice);
void Ice_SetPath2(sIce *ice);
void Ice_Snapshot(sIce *ice);
void Ice_Snapshot_NGPH(sIce *ice);
void Ice_TrialRearrangeAlongThePath(sIce *ice);
void IceNode_AcceptTrial(sIceNode *in);
/*set graph to ice*/
void Ice_SetGraph(sIce *ice,sGraph *g);
void Ice_SetGraph2(sIce *ice,sGraph *g);
void Ice_SetGraph3(sIce *ice,sSparseMatrix *g);
/*ice to graph*/
sSparseMatrix *Ice_ConvertIntoSparseMatrix(sIce *ice);


#endif
