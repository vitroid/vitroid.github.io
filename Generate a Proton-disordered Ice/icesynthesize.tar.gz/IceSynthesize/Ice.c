#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "Graph.h"
#include "Ising.h"
#define Error(x,y) fprintf(stderr,x,y),exit(1)
extern double exp(double);
#include "Ice.h"

int IceNode_OutBit(sIceNode *in)
{
  int i,bit=0,mask;
  if(in->out0>=0){
    for(i=0,mask=1;i<in->nadj;i++,mask+=mask)
      {
        if(in->adj[i]==in->out0){
          bit |= mask;
          break;
        }
      }
    if(in->out1>=0){
      for(i=0,mask=1;i<in->nadj;i++,mask+=mask)
        {
          if(in->adj[i]==in->out1){
            bit |= mask;
            break;
          }
        }
    }
  }
  return bit;
}
/*same routine as IceNodeOutBit(), for new0 and new1*/
int IceNode_NewOutBit(sIceNode *in)
{
  int i,bit=0,mask;
  if(in->new0>=0){
    for(i=0,mask=1;i<in->nadj;i++,mask+=mask)
      {
        if(in->adj[i]==in->new0){
          bit |= mask;
          break;
        }
      }
    if(in->new1>=0){
      for(;i<in->nadj;i++,mask+=mask)
        {
          if(in->adj[i]==in->new1){
            bit |= mask;
            break;
          }
        }
    }
  }
  return bit;
}

      

/*read gcnf for ice*/
sIce *Ice(FILE *gcnf)
{
  sIce *ice;
  char buf[4096];
  /*maximum number of the bit expression of the states.*/
  int max;
  int statetable[1024];
  char *token,*p;
  int k,bit,i,j;

  ice=malloc(sizeof(sIce));
  /*read nnode*/
  fgets(buf,sizeof(buf),gcnf);
  ice->nnode=atoi(buf);
  /**/
  ice->mark=calloc(ice->nnode,sizeof(int));
  /*IceNode allocation*/
  ice->icenode=calloc(sizeof(sIceNode),ice->nnode);
  for(i=0;i<ice->nnode;i++){
    /*read number of adjacent nodes*/
    fgets(buf,sizeof(buf),gcnf);
    ice->icenode[i].nadj=atoi(buf);
    ice->icenode[i].adj=calloc(sizeof(int),ice->icenode[i].nadj);
    /*read the adjacent node list*/
    fgets(buf,sizeof(buf),gcnf);
    p=buf;
    for(j=0;j<ice->icenode[i].nadj;j++){
      token=strtok(p," ");
      ice->icenode[i].adj[j]=atoi(token);
      p=NULL;
    }
    /*read the number of available states for node i*/
    fgets(buf,sizeof(buf),gcnf);
    ice->icenode[i].nstatus=atoi(buf);
    ice->icenode[i].status=malloc(sizeof(int)*ice->icenode[i].nstatus);
    /*read how the states correspond to the real bit state*/
    max=0;
    fgets(buf,sizeof(buf),gcnf);
    p=buf;
    for(j=0;j<ice->icenode[i].nstatus;j++){
      token=strtok(p," ");
      sscanf(token,"%x",&statetable[j]);
      ice->icenode[i].status[j]=statetable[j];
      p=NULL;
      if(max<statetable[j])
	max=statetable[j];
    }
    /*bit sequence to status encoding table*/
    ice->icenode[i].encoding = malloc(sizeof(int)*(max+1));
    for(j=0;j<=max;j++)
      ice->icenode[i].encoding[j]=-1;
    for(j=0;j<ice->icenode[i].nstatus;j++){
      ice->icenode[i].encoding[statetable[j]]=j;
    }
  }
  /*sGraph is now no use.*/
  return ice;
}

/*set graph to ice*/
void Ice_SetGraph(sIce *ice,sGraph *g)
{
  char buf[4096];
  /*maximum number of the bit expression of the states.*/
  int max;
  int statetable[1024];
  char *token,*p;
  int k,bit,i,j;

  /*read nnode*/
  if(ice->nnode != g->nnode){
    Error("Graph size differs from Gcnf size %d.\n",ice->nnode);
  }
  /*embed graph topology info into IceNode*/
  /*clear the counters*/
  for(i=0;i<ice->nnode;i++){
    ice->icenode[i].nadj=0;
    ice->icenode[i].nout=0;
  }
  /*count how many bonds are connected to a node*/ 
  for(i=0;i<ice->nnode;i++){
    for(j=0;j<ice->nnode;j++){
      if(g->am[i*ice->nnode+j]){
	ice->icenode[i].nadj++;
        /*	ice->icenode[i].nout++;*/
      }
      if(g->am[j*ice->nnode+i]){
	ice->icenode[i].nadj++;
      }
    }
  }
  for(i=0;i<ice->nnode;i++){
    ice->icenode[i].nout=0;
    ice->icenode[i].out0=-1;
    ice->icenode[i].out1=-1;
    if(ice->icenode[i].adj!=NULL)
      free(ice->icenode[i].adj);
    ice->icenode[i].adj=malloc(sizeof(int)*ice->icenode[i].nadj);
    k=0;
    /*bit=0;*/
    for(j=0;j<ice->nnode;j++){
      /*if a connection is donated, set the bit*/
      if(g->am[i*ice->nnode+j]){
        if(ice->icenode[i].nout==0)
          ice->icenode[i].out0 = j;
        else
          ice->icenode[i].out1 = j;
        ice->icenode[i].nout++;
        /*	bit |= (1<<k);*/
      }
      /*if a connection is there, list it*/
      if(g->am[i*ice->nnode+j] /*i->j*/ || g->am[j*ice->nnode+i]){
	ice->icenode[i].adj[k++]=j;
      }
    }
    /*ice->icenode[i].outbit=bit;*/
  }
}

/*set graph to ice*/
/*Ice_SetGraph$B$,(Badj$B$r:F@_Dj$7$F$7$^$&$N$,$^$:$$!#NY@\@aE@$N=g=x$O(Bgcnf$B$N>pJs$rM%@h$7$J$$$H$$$1$J$$!#(BIce_SetGraph$B$rB>$G;H$C$F$$$k$+$b$7$l$J$$$N$G!"JLL>$r:n@.$7$?!#(BIce_SetGraph$B$H$N0c$$$O(Badj$B$N@_Dj$r$7$J$$$3$H$N$_!#(B*/
void Ice_SetGraph2(sIce *ice,sGraph *g)
{
  char buf[4096];
  /*maximum number of the bit expression of the states.*/
  int max;
  int statetable[1024];
  char *token,*p;
  int k,bit,i,j;

  /*read nnode*/
  if(ice->nnode != g->nnode){
    Error("Graph size differs from Gcnf size %d.\n",ice->nnode);
  }
  /*embed graph topology info into IceNode*/
  /*clear the counters*/
  for(i=0;i<ice->nnode;i++){
    /*ice->icenode[i].nadj=0;*/
    ice->icenode[i].nout=0;
  }
  /*count how many bonds are connected to a node*/ 
  /*  
  for(i=0;i<ice->nnode;i++){
    for(j=0;j<ice->nnode;j++){
      if(g->am[i*ice->nnode+j]){
	ice->icenode[i].nadj++;
      }
      if(g->am[j*ice->nnode+i]){
	ice->icenode[i].nadj++;
      }
    }
  }*/
  for(i=0;i<ice->nnode;i++){
    ice->icenode[i].nout=0;
    ice->icenode[i].out0=-1;
    ice->icenode[i].out1=-1;
    /*if(ice->icenode[i].adj!=NULL)
      free(ice->icenode[i].adj);*/
    /*ice->icenode[i].adj=malloc(sizeof(int)*ice->icenode[i].nadj);*/
    k=0;
    /*bit=0;*/
    for(j=0;j<ice->nnode;j++){
      /*if a connection is donated, set the bit*/
      if(g->am[i*ice->nnode+j]){
        if(ice->icenode[i].nout==0)
          ice->icenode[i].out0 = j;
        else
          ice->icenode[i].out1 = j;
        ice->icenode[i].nout++;
        /*	bit |= (1<<k);*/
      }
      /*if a connection is there, list it*/
      /*if(g->am[i*ice->nnode+j] || g->am[j*ice->nnode+i]){
	ice->icenode[i].adj[k++]=j;
      }*/
    }
    /*ice->icenode[i].outbit=bit;*/
  }
}

void Ice_SetGraph3(sIce *ice,sSparseMatrix *g)
{
  char buf[4096];
  /*maximum number of the bit expression of the states.*/
  int max;
  int statetable[1024];
  char *token,*p;
  int k,bit,i,j;
  if(ice->nnode != g->nline){
    Error("Graph size differs from Gcnf size %d.\n",ice->nnode);
  }
  for(i=0;i<ice->nnode;i++){
    ice->icenode[i].nout=0;
  }
  for(i=0;i<ice->nnode;i++){
    ice->icenode[i].nout=g->e_line[i].nadj;
    if(g->e_line[i].nadj>0)
      ice->icenode[i].out0=g->e_line[i].adj[0];
    else
      ice->icenode[i].out0=-1;
    if(g->e_line[i].nadj>1){
      if(g->e_line[i].adj[0]<g->e_line[i].adj[1]){
	ice->icenode[i].out0=g->e_line[i].adj[0];
	ice->icenode[i].out1=g->e_line[i].adj[1];
      }else{
	ice->icenode[i].out0=g->e_line[i].adj[1];
	ice->icenode[i].out1=g->e_line[i].adj[0];
      }
    }else
      ice->icenode[i].out1=-1;
  }
}

/*find a route to rearrange the hydrogen bond. Next node to go is */
/*chosen from two output node. Route should be self-avoiding.*/
/*This routine is moved from chainreaction.c 31JAN98*/
/*end indicates whether the path should be a chain or ring. If the
/*path should be a chain, a minus value is specified. If the path
/*should be a ring, the start node is specified.*/
/*depth indicates the depth of the recursion*/
/*current indicates the current node*/
/*if a appropriate path is found, the routine returns 1*/
int count=0;
int Ice_Route(sIce *ice,int end,int depth,int current)
{
  /*current$B$O!"2DG=@-$N$"$kNY@\%N!<%I$+$i%i%s%@%`$KA*$s$@$@$1$J$N$G!"(B */
  /*$B$=$l$,E,@Z$+$I$&$+$^$:H=CG$9$kI,MW$,$"$k!#(B*/
  int i,j;
  ice->path[depth]=current;
  count++;
  /*
  if(count<10){
    for(i=0;i<depth;i++)
      {
	fprintf(stderr,"%d-",ice->path[i]);
      }
    fprintf(stderr,"(%d)?\n",ice->path[depth]);
  }else if(count==10){
    fprintf(stderr,"Skipping indications...\n");
  }else
    if((count%1000)==0){
      fprintf(stderr,"+");
    }*/
  /*reject if the path is too long*/
  if(depth>30)
    return 0;
  /*reject if the node is already visited*/
  for(i=1;i<depth;i++)
    if(ice->path[i]==current)
      return 0;
  /*reject if the node already has more than two donating bonds*/
  if(ice->icenode[current].nout>2)
    return 0;
  else
    /*if the node has only 1 donating nodes,*/ 
    if(ice->icenode[current].nout==1)
      {
	/*if the path should be a chain,*/
	if(end<0)
	  {
	    ice->last=depth;
	    /*ok accepted.*/
	    return 1;
	  }
	else
	  /*rejected*/
	  return 0;
      }
    else/*if the node has two donating bonds, */
      {
        int out0,out1;
	/*if ring is made,*/
	if(current==end)
	  {
	    /*accepted*/
	    ice->last=depth;
	    return 1;
	  }
	/*else seek the next node. The candidate is one of the*/
	/*donating nodes. Here the order is randomly decided.*/
	j=lrand48()%2;
        out0 = ice->icenode[current].out0;
        out1 = ice->icenode[current].out1;
	if(j)
	  {
            if(Ice_Route(ice,end,depth+1,out0))return 1;
            if(Ice_Route(ice,end,depth+1,out1))return 1;
	  }
	else
	  {
            if(Ice_Route(ice,end,depth+1,out1))return 1;
            if(Ice_Route(ice,end,depth+1,out0))return 1;
          }
      }
  return 0;
}

/*Find a flip-flop rearrangement path randomly.*/
void Ice_SetPath_ORG(sIce *ice){
  while(1)
    {
      int out0,out1;
      /*find the first node randomly*/
      int current = lrand48()%ice->nnode;
      out0 = ice->icenode[current].out0;
      out1 = ice->icenode[current].out1;
      /*if the node has 2+2 bonds,*/
      if((ice->icenode[current].nout==2)&&(ice->icenode[current].nadj==4))
	{
	  /*ring rearrangement*/
	  /*choose the order*/
	  int j=lrand48()%2;
	  /*ffirst node is stored*/
	  ice->path[0]=current;
	  if(j)
	    {
              if(Ice_Route(ice,current,1,out0))return;
              if(Ice_Route(ice,current,1,out1))return;
	    }
	  else
	    {
              if(Ice_Route(ice,current,1,out1))return;
              if(Ice_Route(ice,current,1,out0))return;
	    }
	}
      if((ice->icenode[current].nout==2)&&(ice->icenode[current].nadj==3))
	{
	  /*chain rearrangement*/
	  int j=lrand48()%2;
	  ice->path[0]=current;
	  if(j)
	    {
              if(Ice_Route(ice,-1,1,out0))return;
	    }
	  else
	    {
              if(Ice_Route(ice,-1,1,out1))return;
	    }
	}
    }
}

/*Find a flip-flop rearrangement path randomly.*/
/*Modified from Ice_SetPath()*/
/*$BJ?@.#1#3G/#17n#9F|(B($B2P(B)defect$BBP$rF3F~$7$?>l9g(B(start!=end)$B$O!"(BH$B$r(B3$B$D$b$C(B
  $B$??e$d(B1$B$D$7$+$b$?$J$$?e$,$G$-$k$N$G!"(BIceNode$B$NFbMF$O0UL#$,$J$/$J$k!#(B
  $B$7$?$,$C$F!"(BTrial$B$d(BAccept$B$J$I!"(BIceNode$B$r;HMQ$7$?%5%V%k!<%A%s$NBe$o$j(B
  $B$,I,MW$H$J$k!#(BsIce$B9=B$BN$,(Bdefect$B$r5vMF$7$J$$9=B$$K$J$C$F$$$k!#(B*/
int Ice_DopeDefects(sIce *ice,int start,int end){
  int out0,out1;
  out0 = ice->icenode[start].out0;
  out1 = ice->icenode[start].out1;
  /*if the node has 2+2 bonds,*/
  if((ice->icenode[start].nout==2)&&(ice->icenode[start].nadj==4))
    {
      /*ring rearrangement*/
      /*choose the order*/
      int j=lrand48()%2;
      /*ffirst node is stored*/
      ice->path[0]=start;
      if(j)
	{
	  if(Ice_Route(ice,end,1,out0))return 1;
	  if(Ice_Route(ice,end,1,out1))return 1;
	}
      else
	{
	  if(Ice_Route(ice,end,1,out1))return 1;
	  if(Ice_Route(ice,end,1,out0))return 1;
	}
    }
  if((ice->icenode[start].nout==2)&&(ice->icenode[start].nadj==3))
    {
      /*chain rearrangement*/
      int j=lrand48()%2;
      ice->path[0]=start;
      if(j)
	{
	  if(Ice_Route(ice,-1,1,out0))return 1;
	}
      else
	{
	  if(Ice_Route(ice,-1,1,out1))return 1;
	}
    }
  return 0;
}

void Ice_SetPath(sIce *ice){
  while(1)
    {
      int current = lrand48()%ice->nnode;
      if(Ice_DopeDefects(ice,current,current))return;
    }
}

/*$BM-8~4DO)$r$_$D$1$k!#$?$@$7!"(Bcurrent$B$rDL$kI,MW$O$J$$!#(B*/
/*$B4{B8$N;;Dx$H$&$^$/@09g$7$J$$$N$G!"A4It=q$-$*$m$9!#(B*/
int Ice_RingFollow(sIce *ice,int next,int depth)
{
  int j;
  int out0,out1;
  out0 = ice->icenode[next].out0;
  out1 = ice->icenode[next].out1;
  /*  fprintf(stderr,"[%d]",depth);*/
  if(ice->mark[next]){
    int start=ice->mark[next];
    int end=depth;
    int i;
    ice->last=end-start;
    for(i=0;i<ice->last;i++){
      ice->path[i]=ice->path[i+start];
    }
    /*for(i=0;i<ice->last;i++){
      fprintf(stderr,"%d ",ice->path[i]);
    }*/
    /*$B47=,E*$K!"(Bring$B$N>l9g!"(Blast$BMWAG$K:G=i$NMWAG$rF~$l$F$*$/!#(B*/
    ice->path[ice->last]=next;
    /*fprintf(stderr,":%d %d %d %d\n",ice->last,start,end,next);*/
    return 1;
  }
  if(depth>99)return 0;
  
  ice->mark[next]=depth;
  ice->path[depth]=next;
  j=lrand48()%2;
  if(j){
    if(Ice_RingFollow(ice,out0,depth+1)){ice->mark[next]=0;return 1;}
    if(Ice_RingFollow(ice,out1,depth+1)){ice->mark[next]=0;return 1;}
  }else{
    if(Ice_RingFollow(ice,out1,depth+1)){ice->mark[next]=0;return 1;}
    if(Ice_RingFollow(ice,out0,depth+1)){ice->mark[next]=0;return 1;}
  }
  ice->mark[next]=0;
  return 0;
}

int Ice_RingStart(sIce *ice,int start)
{
  int j=lrand48()%2;
  int out0,out1;
  out0 = ice->icenode[start].out0;
  out1 = ice->icenode[start].out1;
  ice->path[0]=start;
/*  mark[start]=1;*/
  if(j){
    if(Ice_RingFollow(ice,out0,1))return 1;
    if(Ice_RingFollow(ice,out1,1))return 1;
  }else{
    if(Ice_RingFollow(ice,out1,1))return 1;
    if(Ice_RingFollow(ice,out0,1))return 1;
  }
  return 0;
}

void Ice_SetPath2(sIce *ice){
  while(1)
    {
      int current = lrand48()%ice->nnode;
      if(Ice_RingStart(ice,current)){
	return;
	
      }
    }
}

void Ice_Snapshot(sIce *ice)
{
  int i,j;
  printf("@GRPH\n%d\n",ice->nnode);
  for(i=0;i<ice->nnode;i++){
    for(j=0;j<ice->nnode;j++){
      if((ice->icenode[i].out0==j)||(ice->icenode[i].out1==j))
	putchar('1');
      else
	putchar('0');
    }
    putchar('\n');
  }
}

void Ice_Snapshot_NGPH(sIce *ice)
{
  int i,j;
  printf("@NGPH\n%d\n",ice->nnode);
  for(i=0;i<ice->nnode;i++){
    printf("%d %d\n",i,ice->icenode[i].out0);
    printf("%d %d\n",i,ice->icenode[i].out1);
  }
  printf("-1 -1\n");
}

void Ice_TrialRearrangeAlongThePath(sIce *ice)
{
  int i;
  for(i=0;i<ice->last;i++){
    int from_=ice->path[i];
    int to_  =ice->path[i+1];
    /*remove outbonds*/
    if(ice->icenode[from_].out0==to_){
      ice->icenode[from_].new0=ice->icenode[from_].out1;
      ice->icenode[from_].new1=-1;
    }else if(ice->icenode[from_].out1==to_){
      ice->icenode[from_].new0=ice->icenode[from_].out0;
      ice->icenode[from_].new1=-1;
    }else{
      Error("Why there is no bond %d?\n",from_);
    }
  }
  
  for(i=0;i<ice->last;i++){
    int from_=ice->path[i];
    int to_  =ice->path[i+1];
    /*insert outbonds*/
    if(ice->icenode[to_].new0<0){
      ice->icenode[to_].new0=from_;
    }else if(ice->icenode[to_].new1<0){
      if(ice->icenode[to_].new0 < from_)
	ice->icenode[to_].new1=from_;
      else{
	ice->icenode[to_].new1=ice->icenode[to_].new0;
	ice->icenode[to_].new0=from_;
      }
    }else{
      Error("Why there is no room for the new bond ?%d\n",i);
    }
  }
}

void IceNode_AcceptTrial(sIceNode *in)
{
  int tmp;
  tmp=in->out0;
  in->out0= in->new0;
  in->new0=tmp;
  tmp=in->out1;
  in->out1= in->new1;
  in->new1=tmp;
}

