/*
 *waterconfig2.c
 *3$B<!85%0%i%U$KJ,;R$r3dEv$F$k(B
 cat @GRPH @AR3A | Align | ./waterconfig2.pbc | quench | traj2mol3 | mol3 -
 *$Id: waterconfig2.c,v 1.1 2002/08/26 09:43:38 matto Exp $
 *$Log: waterconfig2.c,v $
 *Revision 1.1  2002/08/26 09:43:38  matto
 *waterconfig2.c is added.
 *
 *Revision 1.2  1999/09/07 07:50:36  matto
 *NGPH data type is available.
 *
 *Revision 1.1.1.2  1998/09/29 21:27:15  matto
 **** empty log message ***
 *
 *Revision 1.1.1.1  1998/09/29 20:59:58  matto
 *
 */
#define _INCLUDE_XOPEN_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "Rotmx2.h"
extern double acos(double);
extern double cos(double);
extern double sin(double);
extern double sqrt(double);
extern double rint(double);


int main(int argc,char *argv[])
{
    int n,i;
    char buf[10000];
    double *p=NULL;
    double error=1e-10;
    int *am=NULL;
    double cx,cy,cz;
    double boxx,boxy,boxz;
    int pbc = 0;

    while(NULL!=fgets(buf,sizeof(buf),stdin))
      {
	if(0==strncmp(buf,"@GRPH",5))
	  {
	    if(am==NULL)
	      {
		printf("%s",buf);
		fgets(buf,sizeof(buf),stdin);
		printf("%s",buf);
		n=atoi(buf);
		am=malloc(sizeof(int)*n*n);
		for(i=0;i<n;i++)
		  {
		    int j;
		    fgets(buf,sizeof(buf),stdin);
		    printf("%s",buf);
		    for(j=0;j<n;j++)
		      am[i*n+j]=(buf[j]=='1');
		  }
	      }
	  }				
	if(0==strncmp(buf,"@NGPH",5))
	  {
	    if(am==NULL)
	      {
		printf("%s",buf);
		fgets(buf,sizeof(buf),stdin);
		printf("%s",buf);
		n=atoi(buf);
		am=calloc(n*n,sizeof(int));
		while(1){
		  int j;
		  fgets(buf,sizeof(buf),stdin);
		  printf("%s",buf);
		  sscanf(buf,"%d %d",&i,&j);
		  if(i<0)break;
		  am[i*n+j]=1;
		}
	      }
	  }				
	if(0==strncmp(buf,"@BXLA",5))
	  {
	    printf(buf);
	    fgets(buf,sizeof(buf),stdin);
	    boxx=boxy=boxz=atof(buf);
	    printf(buf);
	    pbc = 1;
	  }
	if(0==strncmp(buf,"@BOX3",5))
	  {
	    printf(buf);
	    fgets(buf,sizeof(buf),stdin);
	    sscanf(buf,"%lf %lf %lf",&boxx,&boxy,&boxz);
	    printf(buf);
	    pbc = 1;
	  }
	if((0==strncmp(buf,"@NX3A",5))||(0==strncmp(buf,"@NX4A",5))||(0==strncmp(buf,"@AR3A",5)))
	  {
	    if(p==NULL)
	      {
		int niter;
		fgets(buf,sizeof(buf),stdin);
		n=atoi(buf);
		p=malloc(sizeof(double)*n*7);
		cx=cy=cz=0;
		for(i=0;i<n;i++)
		  {
		    fgets(buf,sizeof(buf),stdin);
		    sscanf(buf,"%lf %lf %lf",
			   &p[i+n*0],&p[i+n*1],&p[i+n*2]);
		    cx+=p[i+n*0];
		    cy+=p[i+n*1];
		    cz+=p[i+n*2];
		  }
	      }  
	  }
      }
    cx/=n;
    cy/=n;
    cz/=n;
    
    for(i=0;i<n;i++)
      {
	  double x,y,z;
	  double x1,y1,z1;
	  double x2,y2,z2;
	  int j1,j2;
	  x=p[i+n*0];
	  y=p[i+n*1];
	  z=p[i+n*2];
	  j1=0;
	  while(j1<n)
	    {
		if(am[i*n+j1]==1)
		  break;
		j1++;
	    }
	  
	  j2=j1+1;
	  while(j2<n)
	    {
		if(am[i*n+j2]==1)
		  break;
		j2++;
	    }
	  
	  /*if(i==42)
	    fprintf(stderr,"%d :%d %d\n",i,j1,j2);*/
	  if(j2>=n)
	    if(j1>=n)
	      {
		  /*2$BK\$H$b3NDj$7$F$$$J$$;~$O$I$&$7$h$&!)30$K8~$1$k$h(B */
		  /*$B$j$7$+$?$,$J$$!#E,Ev$K308~$-%Y%/%H%k$r@8@.$9$k!#=E(B */
		  /*$B?4$+$i$N%Y%/%H%k$KD>8r$7!"(Bxy$BJ?LL>e$K$"$k$h$&$J%Y%/(B */
		  /*$B%H%k$r:n$k!#(B*/
		  /*$B<~4|6-3&>r7o$N>l9g$K$I$&$9$l$P$$$$$+!";X?K$O$J$$!#(B */
		  /*($BCf?4$H$$$&$b$N$,B8:_$7$J$$!#(B)$B$H$j$"$($:!"%/%i%9%?(B */
		  /*$B$N%3!<%I$r$=$N$^$^;HMQ$9$k!#(B*/
		  double x0,y0,z0;
		  /*		  fprintf(stderr,"(0)");*/
		  x0=p[i+n*0]-cx;
		  y0=p[i+n*1]-cy;
		  z0=p[i+n*2]-cz;
		  x1=1.0/(1.0+x0*x0/(y0*y0));
		  y1=1.0-x1;
		  z1=0;
		  x1=sqrt(x1);
		  y1=sqrt(y1);
		  x2=x0-x1;
		  y2=y0-y1;
		  z2=z0-z1;
		  x1=x0+x1;
		  y1=y0+y1;
		  z1=z0+z1;
		  rotmx2(x1,y1,z1,x2,y2,z2,&p[i+n*3],&p[i+n*4],&p[i+n*5],&p[i+n*6]);
	      }
	    else
	      {
		  /*$B3NDj$7$F$$$J$$%Y%/%H%k$OE,Ev$K8~$1$k(B*/
		  double a;
		  x1=p[j1+n*0]-p[i+n*0];
		  y1=p[j1+n*1]-p[i+n*1];
		  z1=p[j1+n*2]-p[i+n*2];
		  if ( pbc ){
		    x1 -= rint(x1/boxx)*boxx;
		    y1 -= rint(y1/boxy)*boxy;
		    z1 -= rint(z1/boxz)*boxz;
		  }
		  x2=p[i+n*0]-cx;
		  y2=p[i+n*1]-cy;
		  z2=p[i+n*2]-cz;
		  /*		  fprintf(stderr,"(1)");*/
		  a=1.3*(x1*x2+y1*y2+z1*z2)/(x1*x1+y1*y1+z1*z1);
		  x2-=a*x1;
		  y2-=a*y1;
		  z2-=a*z1;
		  rotmx2(x1,y1,z1,x2,y2,z2,&p[i+n*3],&p[i+n*4],&p[i+n*5],&p[i+n*6]);
	      }
	  else
	    {
		  x1=p[j1+n*0]-p[i+n*0];
		  y1=p[j1+n*1]-p[i+n*1];
		  z1=p[j1+n*2]-p[i+n*2];
		  x2=p[j2+n*0]-p[i+n*0];
		  y2=p[j2+n*1]-p[i+n*1];
		  z2=p[j2+n*2]-p[i+n*2];
		  if ( pbc ){
		    x1 -= rint(x1/boxx)*boxx;
		    y1 -= rint(y1/boxy)*boxy;
		    z1 -= rint(z1/boxz)*boxz;
		    x2 -= rint(x2/boxx)*boxx;
		    y2 -= rint(y2/boxy)*boxy;
		    z2 -= rint(z2/boxz)*boxz;
		  }
		  /*		  fprintf(stderr,"%f\n",sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2)));*/
                  /*if((i==42)||(i==40)){
		    fprintf(stderr,"%f %f %f\n",x1,y1,z1);
		    fprintf(stderr,"%f %f %f\n",x2,y2,z2);
		  }*/
		  rotmx2(x1,y1,z1,x2,y2,z2,&p[i+n*3],&p[i+n*4],&p[i+n*5],&p[i+n*6]);
		  /*                  fprintf(stderr,"%f %f %f\n",p[i+n*3],p[i+n*4],p[i+n*5]);*/
	      }
      }
    printf("@NX4A\n%d\n",n);
    for(i=0;i<n;i++)
      {
	printf("%f %f %f %f %f %f %f\n",
		 p[i+n*0],p[i+n*1],p[i+n*2],p[i+n*3],p[i+n*4],p[i+n*5],p[i+n*6]);
      }
    exit(0);
    
}
