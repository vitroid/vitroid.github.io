#include <stdlib.h>
#include <stdio.h>
#include <math.h>

void normalize(double* x,double* y,double* z)
{
    double r=1.0/sqrt((*x)*(*x)+(*y)*(*y)+(*z)*(*z));
    (*x)*=r;
    (*y)*=r;
    (*z)*=r;
}

int op(double xi,double yi,double zi,double xj,double yj,double zj,double* ax,double* ay,double* az)
{
    /*fprintf(stderr,"a\n");*/
    if((xi*xi+yi*yi+zi*zi<0.01)||(xj*xj+yj*yj+zj*zj<0.01)){
	return 0;
    }
    *ax=yi*zj-zi*yj;
    *ay=zi*xj-xi*zj;
    *az=xi*yj-yi*xj;
    /*fprintf(stderr,"a: %f %f %f\n",*ax,*ay,*az);*/
    
    if((*ax)*(*ax)+(*ay)*(*ay)+(*az)*(*az)<0.01){
	return 0;
    }
    return 1;
}

/*Quarternion$B$r;;=P(B*/
void rotmx2(double x1,double y1,double z1,double x2,double y2,double z2,double *qa,double *qb,double *qc,double *qd)
{
    double ix,iy,iz;
    double jx,jy,jz;
    double kx,ky,kz;
    
/*$B$^$:5,3J2=$9$k(B*/
    normalize(&x1,&y1,&z1);
    normalize(&x2,&y2,&z2);

/*2$BJ,%Y%/%H%k(B(z)*/
    kx=x1+x2;
    ky=y1+y2;
    kz=z1+z2;
    normalize(&kx,&ky,&kz);
    
/*$BD>8r%Y%/%H%k(B(y)*/
    jx=x2-x1;
    jy=y2-y1;
    jz=z2-z1;
    normalize(&jx,&jy,&jz);
    
/*$BK!@~%Y%/%H%k(B(x=y*z)*/
    ix=jy*kz-jz*ky;
    iy=jz*kx-jx*kz;
    iz=jx*ky-jy*kx;

    {
	/* i$B<4$r(Bx$B<4$K0\$92sE>$N<4$O!"(Bi$B$H(Bx$B$N(B2$BJ,LL$H$J$k!#(B
	   j$B<4$r(By$B<4$K0\$92sE>$N<4$O!"(Bj$B$H(By$B$N(B2$BJ,LL$H$J$k!#(B
	   $B$=$7$F!"$=$l$i$rF1;~$K$_$?$92sE>$N<4$O!"$=$l$i$N8r@~$H$J$k!#(B
	   $B8r@~$O!"(B2$B$D$NLL$NK!@~$N$$$:$l$H$bD>8r$9$k(B=$B30@Q$G$"$k!#(B*/
	double ax,ay,az;
	double i0x,i0y,i0z;
	double x0x,x0y,x0z;
	double ox,oy,oz;
	double cosine,cosh,sinh;
	double t;
	
	if(!op(ix-1.0,iy,iz,jx,jy-1.0,jz,&ax,&ay,&az))
	    if(!op(ix-1.0,iy,iz,kx,ky,kz-1.0,&ax,&ay,&az))
		if(!op(kx,ky,kz-1.0,jx,jy-1.0,jz,&ax,&ay,&az)){
		    fprintf(stderr,"outer prod warning\n");
		    fprintf(stderr, "%f %f %f\n",ix,iy,iz);
		    fprintf(stderr, "%f %f %f\n",jx,jy,jz);
		    fprintf(stderr, "%f %f %f\n",kx,ky,kz);
		    //$BA4$/2sE>$7$J$$%1!<%9(B
		    *qa=1.0;
		    *qb=0.0;
		    *qc=0.0;
		    *qd=0.0;
		    return;
		    //exit(1);
		}
	normalize(&ax,&ay,&az);
	    
	/*$B2sE><4(Ba$B$,5a$^$C$?!#(B*/
	x0x=1;
	x0y=0;
	x0z=0;
	i0x=ix;
	i0y=iy;
	i0z=iz;
	t=ax/(ax*ax+ay*ay+az*az);
	i0x-=t*ax;
	i0y-=t*ay;
	i0z-=t*az;
	x0x-=t*ax;
	x0y-=t*ay;
	x0z-=t*az;
	/*check*/
	/*fprintf(stderr,"%f %f %f\n",i0x,i0y,i0z);*/
	if(i0x*i0x+i0y*i0y+i0z*i0z<0.01){
	    x0x=0;
	    x0y=1;
	    x0z=0;
	    i0x=jx;
	    i0y=jy;
	    i0z=jz;
	    t=ay/(ax*ax+ay*ay+az*az);
	    i0x-=t*ax;
	    i0y-=t*ay;
	    i0z-=t*az;
	    x0x-=t*ax;
	    x0y-=t*ay;
	    x0z-=t*az;
	    /*check*/
	    /*fprintf(stderr,"%f %f %f t=%f\n",i0x,i0y,i0z,t);*/
	}
	
	/*fprintf(stderr,"check: %f %f\n",i0x*ax+i0y*ay+i0z*az,x0x*ax+x0y*ay+x0z*az);*/
	normalize(&i0x,&i0y,&i0z);
	normalize(&x0x,&x0y,&x0z);
	/*inner product to determine angle*/
	cosine=i0x*x0x+i0y*x0y+i0z*x0z;
        if ( cosine < -1.0L || cosine > 1.0 ){
          cosh = 0L;
          sinh = 1.0L;
        }
	else{
          cosh=sqrt((1.0+cosine)*0.5);
          sinh=sqrt(1.0-cosh*cosh);
        }
	//fprintf(stderr,"sinh %24.17e %24.17e %24.17e\n",cosine,cosh,sinh);
	/*outer product to determine direction*/
	ox=i0y*x0z-i0z*x0y;
	oy=i0z*x0x-i0x*x0z;
	oz=i0x*x0y-i0y*x0x;
	if(ox*ax+oy*ay+oz*az<0){
	    sinh=-sinh;
	}
	normalize(&ax,&ay,&az);
	/*printf("%f %f %f\n",ax,ay,az);*/
	
	*qa=cosh;
	*qb=-sinh*ax;
	*qc=+sinh*ay;
	*qd=-sinh*az;
    }
    return;
}
