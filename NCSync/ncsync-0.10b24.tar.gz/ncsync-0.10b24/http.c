#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>

#include <Unix/sys_socket.h>

//#include "stringil.h"
#include "stdio2.h"
#include "log.h"
#include "const.h"
#include "prefsdata.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

#define strncmp(x,y,z) StrNCompare(x,y,z)

char sendstr1[] = "GET ";
char sendstr2[] = " HTTP/1.0\nHost: ";
//char sendstr3[] = "\nAccept: */*\n\n";
char sendstr3[] = "\nAccept: */*\nUser-Agent: "AGENT"\n\n";
char sendstr4[]= "\nIf-Match: ";
char sendstr5[]= "\nRange: bytes=";
char HTTPPREFIX[] = "http://";

typedef struct _strlist
{
    struct _strlist *next;
    char *tag;
    char *value;
}
strlist;

char buf[2050];

int MakeDatabase(FILE * fd);

int nexttoken(char* p)
{
    char* orig=p;
    while(*p && *p != ' '){
	p++;
    }
    while(*p && *p == ' '){
	p++;
    }
    return p-orig;
}

int inttoken(char* p)
{
    char* orig=p;
    while(*p && *p >= '0' && *p <= '9'){
	p++;
    }
    return p-orig;
}

strlist *StrListNew(strlist *next, char *tag, char *value)
{
    strlist *el=MemPtrNew(sizeof(strlist));
    el->next=next;
    el->tag = tag;
    el->value=value;
    return el;
}

void StrListFree(strlist *el)
{
    if(el->next)
	StrListFree(el->next);
    MemPtrFree(el);
}

strlist *ParseHeader(char *a)
{
    char *p,*b;
    strlist *el=NULL;
    p=a;
    do {
	while(*p && *p!=':' && *p!='\r' && *p!='\n')
	    p++;
	if(*p){
	    if(*p==':'){
		*p=0;
		do p++; while (*p == ' ');
		b=p;
		while(*p && *p!='\r' && *p!='\n')
		    p++;
		*p=0;
		p++;
		while(*p=='\r' || *p=='\n')
		    p++;
	    }else{
		*p=0;
		b=p;
		p++;
		while(*p=='\r' || *p=='\n')
		    p++;
	    }
	    el=StrListNew(el,a,b);
	    /*
	    LogAppend("<");
	    LogAppend(a);
	    LogAppend("|");
	    LogAppend(b);
	    LogAppend(">");
	    */
	    a=p;
	}
    }while(*p);
    return el;
}

int GetStatus(char *p)
{
    int len,ret;
    char *q;
    while(*p && 0!=strncmp("HTTP/",p,5)){
	p++;
    }
    if(!*p){
	return 0;
    }
    p+=5;
    //Skip HTTP/*.*SPSPSP
    p+=nexttoken(p);
    //Get integer token, which is return code
    len=inttoken(p);
    q=p+len;
    *q=0;
    ret=StrAToI(p);
    return ret;
}

void SplitURL(char *in, char **scheme, char **host, char **path)
{
    char *p;
    p=in;
    while(*p==' '){
	p++;
    }
    *scheme=p;
    while(*p && *p!=':'){
	p++;
    }
    *host=*path=p;
    if(*p==0) return;
    *p=0;
    p++;
    if(*p==0) return;
    if(0==strncmp("//",p,2)){
	p+=2;
	*host=p;
	//no port No.
	while(*p && *p!='/'){
	    p++;
	}
	if(*p==0){
	    *path=p;
	    return;
	}
	*p=0;
	p++;
    }
    *path=p;
}

int GetAppNetRefnum()
{
  unsigned long version;
  Err err;
  err = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &version);
  if( 0==err && sysGetROMVerMajor(version)>=2){
      err=FtrGet(netFtrCreator, netFtrNumVersion, &version);
      if( 0==err ){
	  err = SysLibFind("Net.lib", &AppNetRefnum);
      }
  }
  if(err){
      LogAppend("No feature for net connection.\n");
      return 1;
  }
  return 0;
}



int viaProxy()
{
    return ( Prefs()->useProxy && *( Prefs()->proxyHost ) && Prefs()->proxyPort );
}



int GetURL2(char *hostp, char *pathp, Boolean store, Boolean immediateClose, ProgressPtr progressDialog)
{
  NetSocketRef sock = -1;       // socked file descriptor
  FILE *fd = NULL;
  char *cursor = NULL;
  EventType event;
  Err err, err2;
  Byte allup;
  unsigned long storedLength, contentLength = 0;
  int hostLength, pathLength;
  char tmpstr[40];
  strlist *header=NULL;
  strlist *el;
  UInt16 status;
  char   relocation[100];
  int    httpPort = 80;
  char*  httpHost = hostp;
  
  if ( viaProxy() ){
      httpPort = Prefs()->proxyPort;
      httpHost = Prefs()->proxyHost;
  }

  hostLength = StrLen(hostp);
  pathLength = StrLen(pathp);
  
  AppNetRefnum = 0;
  
  if(GetAppNetRefnum())
      return 1;

  {
      //AppNetRefnum is specified == CloseNetLib on exit
      err = NetLibOpen(AppNetRefnum, &err2);
      if((err==0 || err==netErrAlreadyOpen)&&(0==err2)){
      }else{
	  char buf[50];
	  StrPrintF(buf,"Fail to open NetLib:%d:%d\n",err,err2);
	  LogAppend(buf);
	  return 1;
      }
      
      
      AppNetTimeout = 3000;
      
      NetLibConnectionRefresh(AppNetRefnum, true, &allup, &err2);
      
  relocate:
      sock = NetUTCPOpen( httpHost, NULL, httpPort );

      if (sock < 0){
	  LogAppend("Failed to open TCP.\n");
	  NetLibClose(AppNetRefnum, immediateClose);
	  return 1;
      }
      
      {
          {
              int numRead;
              
              //socket opened == close socket on exit
              AppNetTimeout = -1;
              
              LogAppend("Connected.\n");
	  
              if( *pathp == '/' ){
                  pathp++;
                  pathLength--;
              }
	  
              // "Get "
              send(sock, sendstr1, StrLen(sendstr1), 0);

              // "/" or "http://host/"
              if ( viaProxy() ){
                  send(sock, HTTPPREFIX, StrLen( HTTPPREFIX), 0);
                  send(sock, hostp, hostLength, 0);
              }
              send(sock, "/", 1, 0);
              
              // path of the target URL
              send(sock, pathp, pathLength, 0);

              // " HTTP/1.0\nHost: "
              send(sock, sendstr2, StrLen(sendstr2), 0);

              // host of the target URL
              send(sock, hostp, hostLength, 0);

              // "\nAccept: */*\nUser-Agent: "AGENT"\n\n";
              send(sock, sendstr3, StrLen(sendstr3), 0);
	  
              storedLength = 0;
              
              for (;;) {
                  
                  LogAppend("Waiting.\n");
                  numRead = recv(sock, &buf[storedLength], 2048 - storedLength, 0);
                  
                  if (numRead < 0)
                      break;
                  
                  if (!numRead) {
                      LogAppend("Bad Header.\n");
                      SysTaskDelay(100);
                      break;
                  }
                  
                  storedLength += numRead;
                  
                  buf[storedLength] = 0;
                  
                  cursor = buf;
                  
                  while ( *cursor && strncmp( cursor, "\r\n\r\n", 4 ) )
                      cursor++;
                  if ( *cursor ) {
                      //WinDrawChars(buf, 80, 0, 100);
                      LogAppend("EOH.\n");
                      //Terminate header
                      cursor += 2;
                      *cursor = 0;
                      cursor += 2;
                      break;
                  }
                  LogAppend("NoEOH.\n");
                  
                  SysTaskDelay(100);
              }
	  
              if (numRead <= 0) {
                  close(sock);
                  NetLibClose(AppNetRefnum, immediateClose);
                  return 1;
              }
          }
	  /*buf$B$NCf$K$O%X%C%@$,$"$j!"(Bcursor$B$O%\%G%#$N@hF,$r;X$7$F$$$k!#(B*/
	  
	  /*$B$^$:(Breturn$BCM$rD4$Y$k!#(B*/
	  if(header)
	      StrListFree(header);
	  header=ParseHeader(buf);
	  status=GetStatus(buf);
	  StrPrintF(tmpstr,"HTTP status code: %d.\n",status);
	  LogAppend(tmpstr);

	  /*
	  el=header;
	  while(el){
	  LogAppend(el->tag);
	  LogAppend("=");
	  LogAppend(el->value);
	  LogAppend(";");
	  el=el->next;
	  }*/

	  if(status==302){
	      el=header;
	      while(el && 0!=strcmp(el->tag,"Location"))
		  el=el->next;
	      if(el){
		  char *schemep;
		  StrCopy(relocation,el->value);
		  //el->value is volatile
		  SplitURL(relocation, &schemep, &hostp, &pathp);
		  LogAppend("Scheme:");
		  LogAppend(schemep);
		  LogAppend("\n");
		  //close(sock);
		  //NetLibClose(AppNetRefnum,Prefs()->immediateclose);
		  //return 1;
		  if( 0 == strcmp( schemep, "http" ) &&
                      0 == strcmp( hostp, Prefs()->serverHost ) ){
		      hostLength = StrLen(hostp);
		      pathLength = StrLen(pathp);
		      close(sock);
		      goto relocate;
		  }else{
		      LogAppend("broken URL.\n");
		      close(sock);
		      NetLibClose(AppNetRefnum, immediateClose);
		      return 1;
		  }
	      }else{
		  LogAppend("No Location.\n");
		  close(sock);
		  NetLibClose(AppNetRefnum, immediateClose);
		  return 1;
	      }
	  }else if(status!=200){
	      /*unsupported return value*/
	    StrPrintF( tmpstr, "Unexpected http status code: %d\n", status );
	      LogAppend(tmpstr);
	      close(sock);
	      NetLibClose(AppNetRefnum, immediateClose);
	      return 1;
	  }
	  
	  LogAppend("Opened.\n");
	  Prefs()->starttime=TimGetSeconds();
	  StrNCopy( Prefs()->redirectedHost, hostp, HOSTMAXLEN );
	  StrNCopy( Prefs()->redirectedPath, pathp, PATHMAXLEN );
          if ( store ) {
              el=header;
              while(el && 0!=strncmp(el->tag,"Content-Length",14)){
                  el=el->next;
              }
              if(el){
                  contentLength = StrAToI(el->value);
                  StrPrintF( tmpstr, "Size: %s\n", el->value );
                  LogAppend( tmpstr );
                  StrPrintF(tmpstr,"%ld kBytes", contentLength / 1024L );
                  Prefs()->contentlen = contentLength;
              }else{
                  //$BDL>o$O(BContent-Length$B$OITL@$G$b$+$^$o$J$$$,!"(BNCSync$B$G$O87L)$5$r5a$a$k!#(B
                  LogAppend( "Length unknown.\n" );
                  close(sock);
                  NetLibClose(AppNetRefnum, immediateClose);
                  return 4;
              }
          }
	  
	  el=header;
	  while(el && 0!=strncmp(el->tag,"ETag",4)){
	      el=el->next;
	  }
	  if(el){
	    LogAppend( "Etag: " );
	    LogAppend( el->value );
	    LogAppend( "\n" );
	      StrNCopy(Prefs()->etag,el->value,ETAGMAXLEN);
	  }else{
	      StrCopy(Prefs()->etag,"");
	  }
	  
	  StrListFree(header);
	  header=NULL;

          if ( store )
              fd = FileOpen(0, TMPDB, 'DATA', 'BRWS', fileModeReadWrite, NULL);
	  {
              int numRead;
              int progressInterval;
              
	      //TMPDB opened
	      storedLength -= ( cursor - buf );

	      if ( fd )
                  fwrite( cursor, 1, storedLength, fd );
	      
	      progressInterval = 10;
	      for (;;) {
		  numRead = recv(sock, buf, 1024, 0);
		  
		  if ( !numRead ) {
		      LogAppend("Stalled.\n");
		      AppNetTimeout = 1000;
		      numRead = recv(sock, buf, 1024, 0);
		      AppNetTimeout = -1;
		      if ( !numRead )
			  break;
		  }
		  
		  if (numRead <= 0)
		      break;
		  progressInterval --;
		  if( progressInterval == 0 ){
		      if ( progressDialog != NULL )
                          PrgUpdateDialog( progressDialog, 0, 
                                           storedLength >> 10, tmpstr, false );
		      progressInterval = 10;
		  }
		  EvtGetEvent(&event, 0);
                  if ( progressDialog != NULL )
                      if ( !PrgHandleEvent( progressDialog, &event))
                          if ( PrgUserCancel( progressDialog )){
                              LogAppend( "Cancelled by user interrupt.\n" );
                              if ( fd )
                                  fclose(fd);
                              close(sock);
                              NetLibClose(AppNetRefnum, immediateClose);
                              SysTaskDelay(300);
                              return 3;
                          }
		  
		  if ( fd ){
                      int numWritten;
		  
                      numWritten          = fwrite(buf, 1, numRead, fd);
                      storedLength       += numWritten;
                      Prefs()->downloaded = storedLength;
                      if (numRead != numWritten){
                          LogAppend("Failed to store.\n");
                          fclose(fd);
                          close(sock);
                          NetLibClose(AppNetRefnum, immediateClose);
                          SysTaskDelay(300);
                          return 3;
                      }
                  }
	      }
              if ( fd )
                  fclose(fd);
	  }
	  close(sock);
      }
      if( store && storedLength != contentLength ){
	  LogAppend("Truncated.\n");
	  NetLibClose(AppNetRefnum, immediateClose);
	  return 5;
      }
      NetLibClose(AppNetRefnum, immediateClose);
  }
  return 0;
}

int ContinueGetURL(char *hostp, char *pathp, ProgressPtr progressDialog, UInt32 downloaded, UInt32 contentLength, char *etag)
{
  NetSocketRef sock = -1;       // socked file descriptor
  FILE *fd;
  char *cursor = NULL;
  EventType event;
  Err err, err2;
  Byte allup;
  unsigned long storedLength;
  int hostLength,pathLength;
  char tmpstr[40];
  strlist *header=NULL;
  strlist *el;
  UInt16 status;
  int   httpPort = 80;
  char* httpHost = hostp;
  
  if ( viaProxy() ){
      httpPort = Prefs()->proxyPort;
      httpHost = Prefs()->proxyHost;
  }

  if(StrNCompare(etag,"W/",2)==0){
      etag+=2;
  }
  
  
  hostLength=StrLen(hostp);
  pathLength=StrLen(pathp);
  
  AppNetRefnum = 0;
  
  if(GetAppNetRefnum())
      return 1;

  {
      //AppNetRefnum is specified == CloseNetLib on exit
      err = NetLibOpen(AppNetRefnum, &err2);
      if((err==0 || err==netErrAlreadyOpen)&&(0==err2)){
      }else{
	  char buf[50];
	  StrPrintF(buf,"Fail 2:%d:%d\n",err,err2);
	  LogAppend(buf);
	  return 1;
      }
      
      
      AppNetTimeout = 3000;
      
      NetLibConnectionRefresh(AppNetRefnum, true, &allup, &err2);
      
      sock = NetUTCPOpen( httpHost, NULL, httpPort);

      if (sock < 0){
	  LogAppend("Failed to open TCP.\n");
	  NetLibClose(AppNetRefnum,Prefs()->immediateclose);
	  return 1;
      }
      
      {
          int numRead;
          
	  //socket opened == close socket on exit
	  AppNetTimeout = -1;
	  
	  LogAppend("Connected.\n");
	  
	  if( *pathp == '/' ){
	      pathp++;
	      pathLength--;
	  }
	  
          // "Get "
	  send(sock, sendstr1, StrLen(sendstr1), 0);

          // "/" or "http://host/"
          if ( viaProxy() ){
              send(sock, HTTPPREFIX, StrLen( HTTPPREFIX), 0);
              send(sock, hostp, hostLength, 0);
          }
          send(sock, "/", 1, 0);
              
          // path of the target URL
	  send(sock, pathp, pathLength, 0);

          // " HTTP/1.0\nHost: "
	  send(sock, sendstr2, StrLen(sendstr2), 0);

          // host of the target URL
	  send(sock, hostp, hostLength, 0);

          // "\nIf-Match: "
	  send(sock, sendstr4, StrLen(sendstr4), 0);

          // send etag
	  send(sock, etag, StrLen(etag), 0);

          // "\nRange: bytes="
	  send(sock, sendstr5, StrLen(sendstr5), 0);

          // part to be retrieved
	  StrPrintF(tmpstr,"%ld-%ld",downloaded,contentLength-1);
	  send(sock, tmpstr, StrLen(tmpstr), 0);

          // "\nAccept: */*\nUser-Agent: "AGENT"\n\n"
	  send(sock, sendstr3, StrLen(sendstr3), 0);
	  
	  storedLength = 0;
	  
	  for (;;) {
	      
	      LogAppend("Waiting.\n");
	      numRead = recv(sock, &buf[storedLength], 2048 - storedLength, 0);
	      
	      if ( numRead < 0 )
		  break;
	      
	      if ( !numRead ) {
		  LogAppend("Bad Header.\n");
		  SysTaskDelay(100);
		  break;
	      }
	      
	      storedLength += numRead;
	      
	      buf[storedLength] = 0;
	      
	      cursor = buf;
	      
	      while ( *cursor && strncmp( cursor, "\r\n\r\n", 4 ) )
		  cursor++;
	      if ( *cursor ) {
		  //WinDrawChars(buf, 80, 0, 100);
		  LogAppend("EOH.\n");
		  //Terminate header
		  cursor += 2;
		  *cursor = 0;
		  cursor += 2;
		  break;
	      }
	      
	      LogAppend("NoEOH.\n");
	      
	      SysTaskDelay(100);
	  }
	  
	  //WinDrawChars(buf, 32, 40, 112);
	  
	  if ( numRead <= 0 ) {
	      close(sock);
	      NetLibClose(AppNetRefnum,Prefs()->immediateclose);
	      return 1;
	  }
	  /*buf$B$NCf$K$O%X%C%@$,$"$j!"(Bcursor$B$O%\%G%#$N@hF,$r;X$7$F$$$k!#(B*/
	  
	  /*$B$^$:(Breturn$BCM$rD4$Y$k!#(B*/
	  if(header)
	      StrListFree(header);
	  header=ParseHeader(buf);
	  status=GetStatus(buf);
	  StrPrintF(tmpstr,"HTTP status code: %d.\n",status);
	  LogAppend(tmpstr);

	  /*
	  el=header;
	  while(el){
	  LogAppend(el->tag);
	  LogAppend("=");
	  LogAppend(el->value);
	  LogAppend(";");
	  el=el->next;
	  }*/

	  if(status!=206){
	      /*unsupported return value*/
	    StrPrintF( tmpstr, "Unexpected http status code: %d\n", status );
	      LogAppend( tmpstr );
	      close(sock);
	      NetLibClose(AppNetRefnum,Prefs()->immediateclose);
	      return 1;
	  }
	  
	  LogAppend("Opened.\n");
	  //Prefs()->starttime=TimGetSeconds();
	  //StrNCopy(Prefs()->host,hostp,HOSTMAXLEN);
	  //StrNCopy(Prefs()->path,pathp,PATHMAXLEN);
	  el=header;
	  while(el && 0!=strncmp(el->tag,"Content-Length",14)){
	      el=el->next;
	  }
	  if(el){
	      //Check length!!!!
	      UInt32 newLength;
	      newLength=StrAToI(el->value);
	      StrPrintF( tmpstr, "Size: %s\n", el->value );
	      StrPrintF(tmpstr,"%ld kBytes",contentLength/1024L);
	      //Prefs()->contentlen=contentlen;
	  }else{
	      //$BDL>o$O(BContent-Length$B$OITL@$G$b$+$^$o$J$$$,!"(BNCSync$B$G$O87L)$5$r5a$a$k!#(B
	      LogAppend("Length unknown.\n");
	      close(sock);
	      NetLibClose(AppNetRefnum,Prefs()->immediateclose);
	      return 4;
	  }
	  
	  StrListFree(header);
	  header=NULL;

	  fd = FileOpen(0, TMPDB, 'DATA', 'BRWS', fileModeAppend, NULL);
	  {
              int numRead;
              int progressInterval;
              
	      //TMPDB opened
	      storedLength -= ( cursor - buf );

	      fwrite(cursor, 1, storedLength, fd);
	      storedLength+=downloaded;
	      progressInterval=10;
	      for (;;) {
		  int numWritten;
		  
		  numRead = recv(sock, buf, 1024, 0);
		  
		  if ( !numRead ) {
		      LogAppend("Stalled.\n");
		      AppNetTimeout = 1000;
		      numRead = recv(sock, buf, 1024, 0);
		      AppNetTimeout = -1;
		      if ( !numRead )
			  break;
		  }
		  
		  if ( numRead <= 0 )
		      break;
		  progressInterval --;
		  if( progressInterval == 0 ){
		      if ( progressDialog != NULL )
                          PrgUpdateDialog( progressDialog, 0,
                                           storedLength >> 10, tmpstr, false );
		      progressInterval = 10;
		  }
		  EvtGetEvent(&event, 0);
                  if ( progressDialog != NULL )
                      if ( !PrgHandleEvent( progressDialog, &event) )
                          if ( PrgUserCancel( progressDialog ) ){
                              LogAppend("Cancelled by user interrupt.\n");
                              fclose(fd);
                              close(sock);
                              NetLibClose(AppNetRefnum,Prefs()->immediateclose);
                              SysTaskDelay(300);
                              return 3;
                          }
		  
		  numWritten          = fwrite(buf, 1, numRead, fd);
		  storedLength       += numWritten;
		  Prefs()->downloaded = storedLength;
		  if ( numRead != numWritten ){
		      LogAppend("Failed to store.\n");
		      fclose(fd);
		      close(sock);
		      NetLibClose(AppNetRefnum,Prefs()->immediateclose);
		      SysTaskDelay(300);
		      return 3;
		  }
	      }
	      fclose(fd);
	  }
	  close(sock);
      }
      if( storedLength != contentLength ){
	  LogAppend("Truncated.\n");
	  NetLibClose(AppNetRefnum,Prefs()->immediateclose);
	  return 5;
      }
      NetLibClose(AppNetRefnum,Prefs()->immediateclose);
  }
  return 0;
}

int Continuable()
{
    Preferences *pref=Prefs();
    char msg[100];
    LogAppend( "host:" );
    LogAppend( pref->redirectedHost );
    LogAppend( ";\npath:" );
    LogAppend( pref->redirectedPath );
    LogAppend( ";\netag:" );
    LogAppend( pref->etag );
    StrPrintF( msg, "(%ld/%ld)\n", pref->downloaded, pref->contentlen );
    LogAppend( msg );
    if( pref->contentlen > 0 ){
	if( pref->starttime+3600*3 > TimGetSeconds() ){
	    if( pref->etag && pref->etag[0] ){
		if( pref->redirectedHost && pref->redirectedHost[0] ){
		    if( pref->redirectedPath && pref->redirectedPath[0] ){
			Err err;
			UInt32  size;
                        FILE *fd;
			
                        fd = FileOpen(0, TMPDB, 'DATA', 'BRWS', fileModeReadOnly, &err);
                        if(err==0){
                            FileTell(fd, &size,NULL);
                            fclose(fd);
                            if(size == pref->downloaded){
                                return 1;
                            }
                        }
		    }
		}
	    }
	}
    }
    return 0;
}

    
	
int NeedDownload()
{
    Preferences *pref=Prefs();
    if(pref->contentlen==0)
	return 1;
    if(pref->contentlen != pref->downloaded)
	return 1;
    return 0;
}
