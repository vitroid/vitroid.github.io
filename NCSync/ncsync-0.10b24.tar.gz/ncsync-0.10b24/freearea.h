#ifndef _FREEAREA_H
#define _FREEAREA_H

/*return size of free memory area*/
UInt32 FreeArea();
#endif
