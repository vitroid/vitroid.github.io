#ifndef _HTTP_H
#define _HTTP_H
#define IGNORE_LENGTH 0
#define CHECK_LENGTH 1

int GetURL(char *host, char *path, int port);
int GetURL2(char *host, char *path, Boolean store, Boolean immediateClose, ProgressPtr prg);
int Continuable();
int NeedDownload();
int ContinueGetURL(char *host, char *path, ProgressPtr prg, UInt32 downloaded, UInt32 contentlen,char *etag);

#endif
