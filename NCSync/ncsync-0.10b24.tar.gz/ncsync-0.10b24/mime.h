#ifndef _MIME_H_
#define _MIME_H_

/*
 * Common symbol
 */

#define TRUE  1
#define FALSE 0

#define YES 1
#define NO  0

/*
 * Commond characters
 */

#define NUL  '\0'
#define CR   '\r'
#define LF   '\n'
#define EQ   '='
#define TAB  '\t'
#define SP   ' '
#define DOT  '.'
#define DEL 127

#define OOB -1
#define EOP -2
#define ELF -3
#define ECR -4

/*linux*/
#define EOF (-1)
#endif
