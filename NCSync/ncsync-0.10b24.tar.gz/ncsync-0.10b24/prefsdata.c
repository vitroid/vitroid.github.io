/*
 * $Id: prefsdata.c,v 1.2 2004/06/05 10:57:33 matto Exp $
 *
 * Viewer - a part of Plucker, the free off-line HTML viewer for PalmOS
 * Copyright (c) 1998-2002, Mark Ian Lillywhite and Michael Nordstrm
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <PalmOS.h>
#include "prefsdata.h"
#include "const.h"



/***********************************************************************
 *
 *      Private variables
 *
 ***********************************************************************/
static Preferences  pref;

void ResetContInfo()
{
    pref.contentlen = 0;
    pref.downloaded = 0;
    StrCopy( pref.etag, "" );
    StrCopy( pref.redirectedHost, "" );
    StrCopy( pref.redirectedPath, "" );
}

/* Retrieve preferences from the Preferences database */
void ReadPrefs( void )
{
    Int16   result;
    UInt16  prefSize = sizeof( Preferences );

    MemSet( &pref, sizeof( Preferences ), 0 );

    result = PrefGetAppPreferences( (UInt32) AppID, (UInt16) PrefID,
                                    &pref, &prefSize, true);
    if ( result == noPreferenceFound || 
         pref.prefsVersion != PREFSVERSION ) {
        pref.dbID                       = NULL;
	pref.format                     = FORMAT_MEDOC;
#ifdef PALMBASKET
	pref.udr                        = UDR25;
#endif
	StrCopy(pref.permanentID1,"");
	StrCopy(pref.permanentID2,"");
	StrCopy(pref.permanentID3,"");
	pref.immediateclose = false;
	pref.starttime      = 0;
	pref.reservedsize   = 100;
        pref.proxyPort      = 3128;
        pref.useProxy       = false;
        pref.prefsVersion   = PREFSVERSION;
        StrCopy( pref.proxyHost, "mbox.chem.nagoya-u.ac.jp" );
        StrCopy( pref.serverHost, "newsclip.chem.nagoya-u.ac.jp" );
	ResetContInfo();
    }
}



/* Store preferences in the Preferences database */
void WritePrefs( void )
{
    PrefSetAppPreferences( (UInt32) AppID, (UInt16) PrefID,
        (Int16) PrefVersion, &pref, sizeof( Preferences ), true );
}


/* Retrieve the value of a preference ( through the pointer ) */
Preferences* Prefs( void )
{
    return &pref;
}
