#ifndef _LOGFORM_H
#define _LOGFORM_H

#define LOGFILE "NCSyncLog"
Boolean LogFormHandleEvent ( EventType* event );
void LogReset();
int LogAppend(char *string);


#endif
