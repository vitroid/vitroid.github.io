#ifndef _PROGRESS_H
#define _PROGRESS_H
int DoDownloadDialog();
int DoExpansionDialog();
#endif
