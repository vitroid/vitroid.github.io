/*id form*/
#include <PalmOS.h>
#include "resourceids.h"
#include "prefsdata.h"
#include "const.h"

static void IdFormInit( void )
{
    FormType*   frm;
    FieldType*  field;

    frm = FrmGetFormPtr( FormID );
    //field = GetObjectPtr( ??? );
    //AddURLToField( field, linkIdx );
    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldEnterID ) );
    FldInsert( field, IDEXP,StrLen(IDEXP) );
    if(Prefs()->permanentID1[0]){
	field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldID1 ) );
	FldInsert( field, Prefs()->permanentID1,StrLen(Prefs()->permanentID1));
	field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldID2 ) );
	FldInsert( field, Prefs()->permanentID2,StrLen(Prefs()->permanentID2));
	field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldID3 ) );
	FldInsert( field, Prefs()->permanentID3,StrLen(Prefs()->permanentID3));
    }
    FrmDrawForm( frm );
}

Boolean IdFormHandleEvent
    (
    EventType* event  /* pointer to an EventType structure */
    )
{
    Boolean     handled;

    handled = false;
    
    switch ( event->eType ) {
    case frmOpenEvent:
	IdFormInit();
	handled = true;
	break;
    case ctlSelectEvent:
	switch ( event->data.ctlSelect.controlID ){
	case ButtonIDCancel:
	    FrmGotoForm(FormMain);
	    handled=true;
	    break;
	case ButtonIDOK:
	{
	    FormPtr frm;
	    FieldType *field;
	    char* word1;
	    char* word2;
	    char* word3;
	    int len1,len2,len3;
	    frm = FrmGetActiveForm ();
	    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldID1 ) );
	    word1 = FldGetTextPtr(field);
	    len1 = FldGetTextLength(field);
	    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldID2 ) );
	    word2 = FldGetTextPtr(field);
	    len2 = FldGetTextLength(field);
	    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldID3 ) );
	    word3 = FldGetTextPtr(field);
	    len3 = FldGetTextLength(field);
	    if(word1 && word2 && word3){
		StrNCopy(Prefs()->permanentID1, word1, len1);
		Prefs()->permanentID1[len1]=0;
		StrNCopy(Prefs()->permanentID2, word2, len2);
		Prefs()->permanentID2[len2]=0;
		StrNCopy(Prefs()->permanentID3, word3, len3);
		Prefs()->permanentID3[len3]=0;
		FrmGotoForm(FormMain);
	    }else{
		//invalid id; 
	    }
	    handled=true;
	    break;
	}
	default:
	    handled=true;
	    break;
	}
	break;
    case frmCloseEvent:
	handled = false;
	break;
	
    default:
	handled = false;
    }

    return handled;
}
