// -*- c++ -*-
#include <PalmOS.h>
#include <FeatureMgr.h>
#include <KeyMgr.h>
#include <Rect.h>
#include <Window.h>
#include "resourceids.h"
#include "prefsdata.h"
#include "log.h"
#include "progress.h"
#include "idform.h"
#include "http.h"
#include "freearea.h"
#include "memourl.h"
#define SELECT_OK 0

static void MakeBanner(FormPtr frm)
{
    UInt32 freearea;
    Preferences *pref=Prefs();
    char msg[1000];
    FieldType*      field;
    int len;
    field=FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldMain ) );
    len=FldGetTextLength(field);
    if(len){
	FldDelete(field,0,len);
    }
    
    if(pref->starttime==0){
	StrCopy(msg,"Welcome");
        FldInsert( field, msg,StrLen(msg) );
    }else{
	DateTimeType dt;
	char date[dateStringLength+1];
	StrCopy(msg,"Last sync: ");
	
	TimSecondsToDateTime(pref->starttime, &dt);
	DateToAscii(dt.month, dt.day, dt.year,dfYMDWithSlashes,date);
	StrCat(msg,date);
	StrCat(msg," ");
	TimeToAscii(dt.hour,dt.minute,tfColon24h,date);
	StrCat(msg,date);
	StrCat(msg,"\n");
	if(Continuable()){
	    if(pref->contentlen==0){
		StrCat(msg," Sync completed.");
	    }else{
		if(pref->downloaded!=pref->contentlen){
		    FldInsert(field,msg,StrLen(msg));
		    StrPrintF(msg,"%ld/%ld kB remain unsynced.",(pref->contentlen - pref->downloaded)>>10, pref->contentlen>>10);
		}else{
		    StrCat(msg," Downloaded but not installed.\n");
		}
	    }
	}
        FldInsert( field, msg,StrLen(msg) );
    }
#ifdef PALMBASKET
#else
    freearea = FreeArea() >> 10 ;
    StrPrintF( msg, "%ldkBytes free\n", freearea );
    FldInsert( field, msg, StrLen(msg) );
    //freearea = Prefs()->reservedsize;
    //StrPrintF( msg, "%ldkBytes reserved\n", freearea );
    //FldInsert( field, msg, StrLen(msg) );
#endif
}

static Boolean StartApplication(void)
{
    ReadPrefs();
    //LogAppend("Pref read.\n");
    if(!(*Prefs()->permanentID1&&*Prefs()->permanentID2&&*Prefs()->permanentID3))
	FrmGotoForm(FormID);
    else{
        FrmGotoForm (FormMain);
    }
    return (0);
}

static void StopApplication(void)
{
    FrmCloseAllForms ();
    WritePrefs();
}

static char gSelectorID[25];

static Boolean MainFormHandleEvent (EventPtr event)
{
  FormPtr frm;
  Boolean handled = false;
#ifdef PALMBASKET
#else   
  FieldType*      field;
  Char            number[10];
#endif

  switch(event->eType){
  case nilEvent:
      break;
  case frmOpenEvent:
      frm = FrmGetActiveForm ();
      {
	  ControlType*    ctl;
	  ListType*       list;
	  Char*           label;
	  int             selection;

	  MakeBanner(frm);

	  ctl= FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, SelectorID ) );
	  if(Prefs()->permanentID1[0]==0){
	      StrCopy(gSelectorID,"-prompt-");
	  }else{
	      StrCopy(gSelectorID,"-assigned-");
	  }
	  CtlSetLabel(ctl,gSelectorID);
	  //set selectiontrigger
	  selection=Prefs()->format;
	  list = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, ListFormat ) );
	  ctl = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, PopupFormat ) );
	  label       = LstGetSelectionText( list, selection );
	  
	  CtlSetLabel( ctl, label );
	  LstSetSelection( list, selection );
#ifdef PALMBASKET
	  //set selectiontrigger
	  selection=Prefs()->udr;
	  list = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, ListUDR ) );
	  ctl = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, PopupUDR ) );
	  label       = LstGetSelectionText( list, selection );
	  
	  CtlSetLabel( ctl, label );
	  LstSetSelection( list, selection );
#endif
	  //set checkboxes
	  ctl = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, CheckboxDisconnect ) );
	  CtlSetValue(ctl,Prefs()->immediateclose);
#ifdef PALMBASKET
#else
	  //set reserved size
	  field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldReservedSize ) );
          if ( Prefs()->reservedsize > 16000 ){
              Prefs()->reservedsize = 100;
          }
	  StrPrintF( number, "%ld", Prefs()->reservedsize );
	  FldInsert( field, number, StrLen(number));
#endif
      }
      FrmDrawForm (frm);
      //Invert the icon if continuable

      handled = true;
      break;
  case ctlSelectEvent:
      switch ( event->data.ctlSelect.controlID ){
      case CheckboxDisconnect:
      {
	  ControlType*    ctl;
	  frm = FrmGetActiveForm ();
	  ctl = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, CheckboxDisconnect ) );
	  Prefs()->immediateclose=CtlGetValue(ctl);
	  handled=true;
	  break;
      }
      case ButtonLog:
	  FrmPopupForm( FormLog );
	  handled=true;
	  break;
	  /*case ButtonGet:
	  FrmPopupForm( FormProgress );
	  handled=true;
	  break;*/
      case ButtonHelp:
          FrmHelp( strHelp );
          handled = true;
          break;
      case ButtonGet:
      {
	  int err=0;
#ifdef PALMBASKET
#else
          //update size of reserved memory area if clip button is pressed.
	  frm = FrmGetActiveForm ();
	  field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, FieldReservedSize ) );
	  Prefs()->reservedsize = StrAToI( FldGetTextPtr(field) );
#endif
	  LogReset();
#ifdef PALMBASKET
#else
          if ( RequireSubscription() ){
              if ( SELECT_OK == FrmAlert( confirmSubscription ) ){
                  err = Subscribe();
                  if ( ! err ){
                      InactivateEntriesInMemoURLDB();
                  }
              }
          }
#endif
	  if(NeedDownload())
	      err=DoDownloadDialog();
	  //preserve the last state for reset
	  WritePrefs();
	  if(!err)
	      DoExpansionDialog();
	  //preserve the last state for reset
	  WritePrefs();
	  MakeBanner(FrmGetActiveForm ());
	  handled=true;
	  break;
      }
      case SelectorID:
	  //FrmPopupForm( FormID );
	  FrmGotoForm( FormID );
	  handled=true;
	  break;
      default:
	  break;
      }
      break;
  case popSelectEvent:
  {
      Int16       selection;
      
      selection = event->data.popSelect.selection;
      if ( selection != noListSelection ) {
	  ControlType*    ctl;
	  ListType*       list;
	  Char*           label;
	  UInt16          controlID;
	  
	  list        = event->data.popSelect.listP;
	  controlID   = event->data.popSelect.controlID;
	  frm = FrmGetActiveForm ();
	  ctl = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, controlID ) );
	  label       = LstGetSelectionText( list, selection );
	  
	  CtlSetLabel( ctl, label );
	  LstSetSelection( list, selection );
	  
	  switch ( controlID ) {
	  case PopupFormat:
	      Prefs()->format = selection;
	      break;
#ifdef PALMBASKET
	  case PopupUDR:
	      Prefs()->udr = selection;
	      break;
#endif
	  default:
	      break;
	  }
	  handled = true;
      }
      break;
  }
  default:
      break;
      
  }
  return(handled);
}


static Boolean ApplicationHandleEvent (EventPtr event)
{
  UInt16 formId;
  FormPtr frm;

  if (event->eType == frmLoadEvent)
    {
      // Load the form resource.
      formId = event->data.frmLoad.formID;
      frm = FrmInitForm (formId);
      FrmSetActiveForm (frm);		
		
      // Set the event handler for the form.  The handler of the currently
      // active form is called by FrmHandleEvent each time is receives an
      // event.
      switch (formId)
	{
	case FormMain:
	  FrmSetEventHandler (frm, MainFormHandleEvent);
	  break;
	case FormLog:
	  FrmSetEventHandler (frm, LogFormHandleEvent);
	  break;
//	case FormProgress:
//	  FrmSetEventHandler (frm, ProgressFormHandleEvent);
//	  break;
	case FormID:
	  FrmSetEventHandler (frm, IdFormHandleEvent);
	  break;
	default:
	    break;
	}
      return (true);
    }
  return (false);
}

static void AppEventLoop()
{
  UInt16 error;
  EventType event;
  
  do
    {
      EvtGetEvent (&event, evtWaitForever);
      if (! SysHandleEvent (&event))
	if (! MenuHandleEvent (0, &event, &error))
	  if (! ApplicationHandleEvent (&event))
	    FrmDispatchEvent (&event); 
    }
  while (event.eType != appStopEvent);
}

UInt32	PilotMain (UInt16 cmd, void *cmdPBP, UInt16 launchFlags)
{
  if ( cmd == sysAppLaunchCmdNormalLaunch )
    {
      if(!StartApplication ()){
	AppEventLoop ();
	StopApplication ();
      }
    }
  return (0);
}


