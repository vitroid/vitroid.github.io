#ifndef PREFERENCES_H
#define PREFERENCES_H

#include "resourceids.h"

#define ViewerVersion 1

/* NOTE: Don't change the order of the options */

#ifdef PALMBASKET
typedef enum {
    FORMAT_MEDOC=0,
    FORMAT_DOC,
    FORMAT_PLUCKER_GRAY16,
    FORMAT_PLUCKER_COLOR,
    FORMAT_ISILO3,
    FORMAT_PLUCKER_GRAY4,
} FormatType;

typedef enum {
    UDR0=0,
    UDR25,
    UDR50,
    UDR75,
} UDRType;
#else
typedef enum {
    FORMAT_MEDOC=0,
    FORMAT_DEFAULT,
    FORMAT_SUBSET1,
    FORMAT_SUBSET2,
} FormatType;
#endif

/*
   Viewer preferences

   New items must be added to the end of the list
 */

#define ETAGMAXLEN 30
#define HOSTMAXLEN 40
#define PATHMAXLEN 100
#ifdef PALMBASKET
#define AppID        'PBSl'
#else
#define AppID        'NCSl'
#endif

typedef struct {
    LocalID             dbID;           /* DEPRECATED */
    FormatType          format;
#ifdef PALMBASKET
    UDRType             udr;
    char                permanentID1[10];
    char                permanentID2[10];
    char                permanentID3[10];
#else
    char                permanentID1[6];
    char                permanentID2[6];
    char                permanentID3[6];
#endif
    Boolean             immediateclose;
    UInt32              contentlen;
    UInt32              downloaded;
    UInt32              starttime;
    UInt32              reservedsize;
    char                etag[ETAGMAXLEN];
    char                host[HOSTMAXLEN];
    char                path[PATHMAXLEN];
} Preferences;


extern Preferences* Prefs( void );
extern void ReadPrefs( void );
extern void WritePrefs( void );
extern void ResetContInfo();

#endif
