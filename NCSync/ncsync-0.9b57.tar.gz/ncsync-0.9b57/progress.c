#include <PalmOS.h>
#include "resourceids.h"
#include "progress.h"
#include "log.h"
#include "http.h"
#include "prefsdata.h"
#include "const.h"
#include "unzip.h"
#include "freearea.h"
#include "memourl.h"

Boolean callbackFunction(PrgCallbackDataPtr cbP)
{
    if (cbP->stage==-1){
	StrCopy(cbP->textP, "Downloading ");
	StrCat(cbP->textP, cbP->message);
	//cbP->bitmapId = startBitmap;
    }else{
	StrPrintF(cbP->textP,"Downloading\n%d/",cbP->stage);
	StrCat(cbP->textP, cbP->message);
	//cbP->bitmapId = endBitmap;
    }
    cbP->textChanged = true;
    return true;
}

Boolean callbackExpansion(PrgCallbackDataPtr cbP)
{
    //StrPrintF(cbP->textP,"%d/",cbP->stage);
    StrCopy(cbP->textP,cbP->message);
    //cbP->bitmapId = endBitmap;
    cbP->textChanged = true;
    return true;
}

void SetNCCommand(char *command,char *message, UInt32 freeSpace)
{
    char buf[32]; /*&maxsize=16000*/
#ifdef DEBUG
    StrCopy(command,"/newsclip.zip");
#else
    StrCopy(command,CGINAME "?id=");
    StrCat(command,Prefs()->permanentID1);
    StrCat(command,"-");
    StrCat(command,Prefs()->permanentID2);
    StrCat(command,"-");
    StrCat(command,Prefs()->permanentID3);
#endif
#ifdef PALMBASKET
    switch (Prefs()->udr){
    case UDR0:
	StrCat(command,"&udr=0");
        break;
    case UDR25:
	StrCat(command,"&udr=25");
        break;
    case UDR50:
	StrCat(command,"&udr=50");
        break;
    case UDR75:
	StrCat(command,"&udr=75");
        break;
    }
#endif
#ifdef PALMBASKET
#else
    StrPrintF( buf, "&maxsize=%ld", freeSpace );
    StrCat( command, buf );
#endif
    switch (Prefs()->format)
    {
    case FORMAT_MEDOC:
#ifdef DEBUG
	StrCopy(message,"Debug");
#else
	StrCat(command,"&mget=2");
	StrCopy(message,"MeDoc");
#endif
	break;
#ifndef PALMBASKET
    case FORMAT_DEFAULT:
	StrCat(command,"&mget=1");
	StrCopy(message,"Default");
	break;
#endif
#ifdef PALMBASKET
    case FORMAT_DOC:
	StrCat(command,"&mget=1&format=5");
	StrCopy(message,"Doc");
	break;
    case FORMAT_PLUCKER_GRAY16:
	StrCat(command,"&mget=1&format=7");
	StrCopy(message,"plucker gray16");
	break;
    case FORMAT_PLUCKER_COLOR:
	StrCat(command,"&mget=1&format=8");
	StrCopy(message,"plucker color");
	break;
    case FORMAT_ISILO3:
	StrCat(command,"&mget=1&format=10");
	StrCopy(message,"isilo3");
	break;
    case FORMAT_PLUCKER_GRAY4:
	StrCat(command,"&mget=1&format=11");
	StrCopy(message,"plucker gray4");
	break;
#endif
        /*
    case FORMAT_ISILO3_HIRES:
	StrCat(command,"&mget=1&format=12");
	StrCopy(message,"isilo3 hires");
	break;
	*/
#ifndef PALMBASKET
    case FORMAT_SUBSET1:
	StrCat(command,"&qmget=1");
	StrCopy(message,"subset1");
	break;
    case FORMAT_SUBSET2:
	StrCat(command,"&qmget=2");
	StrCopy(message,"subset2");
	break;
#endif
    default:
	break;
    }
}


int DoDownloadDialog()
{
    //http://softwaredev.earthweb.com/servdev/article/0,,10528_615961,00.html
//http://members.ping.de/~chris/palmos/ProgressManager.html
    ProgressPtr prg;
    //Int32 i=0, cnt=0;
    char message[100];
    char command[COMMAND_LEN_MAX];
    UInt32 freeSpace;
    //RectangleType r;
    int err;
    PrgCallbackData data;
    int id=1;/*ButtonContNew*/
    //stage 1: downloading zip
    //step1: launch dialog
    //CharPtr title
    if(Continuable()){
	id=FrmAlert(AlertQueryContinue);
	if(id==2){
	    return ButtonContCancel;
	}
    }
    
    /*
     *$BE83+8e5-;vAmNL$r(B($B6u$-MFNL(B-reservedsize)$B0J2<$K;XDj$9$k(B
     */
    freeSpace = FreeArea();
    freeSpace >>= 10;
    if ( freeSpace <= Prefs()->reservedsize ){
      return errInsufficientMemory;
    }
    freeSpace -= Prefs()->reservedsize;
    prg = PrgStartDialog("NewsClip Sync", callbackFunction, &data);
    LogAppend("Start download.\n");
    SetNCCommand(command,message,freeSpace);
    LogAppend("command:");
    LogAppend(command);
    LogAppend("\n");
    //initial message
    PrgUpdateDialog(prg, 0, -1, message, true);
    if(id==0){
	Preferences *pref=Prefs();
	err=ContinueGetURL(pref->host,pref->path,80,prg,pref->downloaded,pref->contentlen, pref->etag);
    }else{
	err=GetURL2(HOSTNAME,command,80,CHECK_LENGTH, prg);
    }
    if(err){
	LogAppend("Download failed.\n");
    }
    PrgStopDialog(prg, false);
    return err;
}

int DoExpansionDialog()
{
    ProgressPtr prg;
    int err;
    PrgCallbackData data;
    prg = PrgStartDialog("Zip Archive", callbackExpansion, &data);
    LogAppend("Start expansion.\n");
    PrgUpdateDialog(prg,0,0,"Start Expansion...",true);
    err=ripunzip2(0,TMPDB,prg);
    if(err){
	LogAppend("Expansion failed.\n");
    }else{
	LogAppend("Finished.\n");
	ResetContInfo();
    }
    PrgStopDialog(prg, false);
    return err;
}
