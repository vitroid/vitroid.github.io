#ifndef _MEMOURL_H_

#define _MEMOURL_H_

#include <PalmOS.h>

#define appFileCreator			'asUR'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01
#define AppType					'appl'
#define DBType					'Data'
//#define DBType					'asUR'
#define MEMOURL_DBNAME			"asDB_URL"


#define AMSOFT_URL_TITLE		"AMsoft WEB Page"
#define AMSOFT_URL				"http://www.geocities.co.jp/SiliconValley/6737/"

#define CHECK_ON				1
#define CHECK_OFF				0

#define OPENTYPE_NUM			3
#define OPENTYPE_NONE			0
#define OPENTYPE_ONCE			1
#define OPENTYPE_EVERY			2

#define DEF_URL					"http://www."
#define DEF_URL_TITE			"�����֥å��ޡ���"

#define EDITMODE_NEW			0
#define EDITMODE_EDIT			1

#define COUNTER_LEN				13

//1.4�ʹߤϡ�url��title��ASCIZ������Ĺ�Ȥʤä�
typedef struct {
	Int16 key;
	Int16 openType;
} BookmarkRec;

extern Int32 GetNextNCSyncURL( DmOpenRef UrlDB, Int16* record );
extern DmOpenRef MemoUrlOpenDatabase();
extern Boolean RequireSubscription();
extern int Subscribe();
extern void InactivateEntriesInMemoURLDB( );

#endif // _MEMOURL_H_
