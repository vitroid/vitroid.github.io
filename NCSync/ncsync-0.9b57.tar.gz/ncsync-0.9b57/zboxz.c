#include <PalmOS.h>
#include "unzip.h"
#include "makedb.h"

extern inline char toupper(register char c)
{
  if( c >= 'a' && c <= 'z' )
    return c - 32;
  return c;
}

#define SORTPREFIX 4

int ripunzip2(int card,char *dbname, ProgressPtr prg)
{
    UInt16 n,k;
    FileHand fd;
    char name[256];
    UInt32 type, crea;
    char *filelist;
    long int *filedisp;
    LocalID lid;
    DmOpenRef scratch;
    UInt16 dbrec;
    MemHandle hand;

    lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
    if (!lid) {
	DmCreateDatabase(0, "ZBOXZSCRATCHPAD", 'BOXR', 'DATA', false);
	lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
    }

    scratch = DmOpenDatabase(0, lid, dmModeReadWrite);
    if (!scratch)
	ErrDisplay("Could not access scratchpad");
    dbrec = 0;
    hand = DmNewRecord(scratch, &dbrec, 20480);
    filelist = MemHandleLock(hand);
    hand = DmNewRecord(scratch, &dbrec, 2048); /* max tar or zip directory size * 4 */
    filedisp = MemHandleLock(hand);
    //hand = DmNewRecord(scratch, &dbrec, 4096);
    //filelp = MemHandleLock(hand);
    //hand = DmNewRecord(scratch, &dbrec, 2048);
    //filesort = MemHandleLock(hand);
    //hand = DmNewRecord(scratch, &dbrec, 1024);
    //filecard = MemHandleLock(hand);
    lid = DmFindDatabase(card, dbname);
    DmDatabaseInfo(card, lid, name, NULL, NULL, NULL, NULL,
                 NULL, NULL, NULL, NULL, &type, &crea);

    fd = FileOpen(card, name, type, crea,
    fileModeUpdate | fileModeAnyTypeCreator, NULL);
    
    k = unzipdir(fd, filelist, filedisp);

    if (k) {
	char *c = filelist + SORTPREFIX, *d, d1,d2;
	n = unzip2(fd, -1,prg);
	FileClose(fd);
	if (n != -1)
	    FileDelete(card, name);
	if (n==0)	    
	for (n = 0; n < k; n++,c += StrLen(c) + 1 + SORTPREFIX) {
	    EventType event;
	    
	    d = &c[StrLen(c) - 4];
	    if ( *d++ != '.' )
		continue;
	    if ( toupper(*d++) != 'P' )
		continue;
	    d1 = toupper(*d++);
	    d2 = toupper(*d++);
	    if(!( d1 == 'R' && d2 == 'C' ) &&
	       !( d1 == 'D' && d2 == 'B' ) &&
	       !( d1 == 'Q' && d2 == 'A' ) )
		continue;

	    //WinEraseWindow();
	    //WinDrawChars(c, StrLen(c), 0, 15);
	    fd = FileOpen(0, c, 'DATA', 'BOXR',
			  fileModeUpdate | fileModeAnyTypeCreator, NULL);
	    MakeDatabase2(fd, 1, prg);
	    FileClose(fd);
	    FileDelete(0, c);
	    EvtGetEvent(&event, 0);
	    if (!PrgHandleEvent(prg, &event))
		if (PrgUserCancel(prg))
		    break;
	}
    }else{
	//Install as a doc
	FileClose(fd);
	//reopen
	fd = FileOpen(card, name, type, crea,
		      fileModeUpdate | fileModeAnyTypeCreator, NULL);
	MakeDatabase2(fd,1,prg);
	FileClose(fd);
	FileDelete(0,name);
    }
    
    MemPtrUnlock(filedisp);
    //MemPtrUnlock(filesort);
    //MemPtrUnlock(filelp);
    //MemPtrUnlock(filecard);
    MemPtrUnlock(filelist);
    while (DmNumRecords(scratch))
	DmRemoveRecord(scratch, 0);
    DmCloseDatabase(scratch);
    return 0;
}
