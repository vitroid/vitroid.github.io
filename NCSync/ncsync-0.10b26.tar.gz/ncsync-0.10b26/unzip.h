#ifndef _UNZIP_H
#define _UNZIP_H
int unzipdir(FileHand infile, char *dir, long int *loc);
int unzip2(FileHand infile, long int loc,ProgressPtr prg);
int ripunzip2(int card,char *dbname, ProgressPtr prg);
#endif
