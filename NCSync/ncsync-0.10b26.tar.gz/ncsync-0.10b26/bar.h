#ifndef _BAR_H
#define _BAR_H
#include <PalmOS.h>
enum {
    BAR_NONE=0,
    BAR_PERCENT,
    BAR_SIZE,
}
;


typedef struct
{
    RectangleType bound;
    int length,type,interval,count;
    UInt32 max,typeval;
}
BarType;

BarType *HBarNew(RectanglePtr r,UInt32 max,int type,int interval);
void HBarUpdate(BarType *bar,UInt32 value);
int BarFree(BarType *bar);
#endif

