/*log form*/
#include <PalmOS.h>
#include "resourceids.h"
#include "log.h"

/*logging; logreset/logappend/logfree*/
static LocalID logdbid=0;
static UInt16  oldsize=0;

static void LogFormInit( void )
{
    FormType*   logForm;
    FieldType*  field;
    logForm = FrmGetFormPtr( FormLog );
    field = FrmGetObjectPtr( logForm, FrmGetObjectIndex(logForm,FieldLog) );
    //FldSetTextHandle(field,log);
    logdbid = DmFindDatabase(0, LOGFILE);
    if(logdbid){
	DmOpenRef logfile;
	logfile = DmOpenDatabase(0, logdbid, dmModeReadWrite);
	if(logfile){
	    MemHandle log;
	    UInt16 dbrec;
	    char *p;
	    dbrec=0;
	    log = DmQueryRecord(logfile,dbrec);
	    p=MemHandleLock(log);
	    FldInsert(field,p,StrLen(p));
	    MemHandleUnlock(log);
	    //DmReleaseRecord(logfile,dbrec,true);
	    DmCloseDatabase(logfile);
	}
    }
    FrmDrawForm( logForm );
}

Boolean LogFormHandleEvent
    (
    EventType* event  /* pointer to an EventType structure */
    )
{
    Boolean     handled;
    //FieldType*  field;

    handled = false;
    //field   = GetObjectPtr( frmExternalLinksLink );
    
    switch ( event->eType ) {
    case frmOpenEvent:
	LogFormInit();
	handled = true;
	break;
    case ctlSelectEvent:
	if ( event->data.ctlSelect.controlID == ButtonLogOK ) {
	    FrmReturnToForm( 0 );
	    handled=true;
	}
	break;
	
    case frmCloseEvent:
    {
	//FormType*   logForm;
	//FieldType*  field;
	
	//logForm = FrmGetFormPtr( FormLog );
	//field = FrmGetObjectPtr( logForm, FrmGetObjectIndex(logForm,FieldLog) );
	//log=FldGetTextHandle(field);
	//FldSetTextHandle(field,0);
	
	handled = false;
	break;
    }
    default:
	handled = false;
    }

    return handled;
}

void LogReset()
{
    char *p;
    DmOpenRef logfile;
    MemHandle log;
    UInt16 dbrec;

    logdbid = DmFindDatabase(0, LOGFILE);
    if (!logdbid) {
	DmCreateDatabase(0, LOGFILE, 'NCSl', 'DATA', false);
	logdbid = DmFindDatabase(0, LOGFILE);
    }

    logfile = DmOpenDatabase(0, logdbid, dmModeReadWrite);
    while(DmNumRecords(logfile))
	DmRemoveRecord(logfile,0);
    dbrec=0;
    log = DmNewRecord(logfile, &dbrec, 1);
    p=MemHandleLock(log);
    DmSet(p,0,1,0);
    MemPtrUnlock(p);
    oldsize=1;
    DmReleaseRecord(logfile,dbrec,false);
    DmCloseDatabase(logfile);
}

int LogAppend(char *string)
{
    char *p;
    int length;
    DmOpenRef logfile;
    UInt16 dbrec;
    MemHandle log;
    if(logdbid==0)
	LogReset();
    if(logdbid==0)
	return 1;
    logfile = DmOpenDatabase(0, logdbid, dmModeReadWrite);
    if(logfile==0)
	return 2;
    dbrec=0;
    length=StrLen(string);
    DmResizeRecord(logfile,dbrec,oldsize+length);
    log = DmGetRecord(logfile,dbrec);
    p=MemHandleLock(log);
    DmWrite(p,oldsize-1,string,length+1);
    oldsize+=length;
    //WinDrawChars(p,StrLen(p),10,10);
    //WinDrawChars(string,length,10,40);
    MemHandleUnlock(log);
    DmReleaseRecord(logfile,dbrec,false);
    DmCloseDatabase(logfile);
    return 0;
}
