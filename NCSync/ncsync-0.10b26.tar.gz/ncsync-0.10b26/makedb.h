#ifndef MAKEDB_H
#define MAKEDB_H
int MakeDatabase(FileHand  fd, int destruct, RectangleType *r);
int MakeDatabase2(FileHand  fd, int destruct, ProgressPtr prg);
#endif
