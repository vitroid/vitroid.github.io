#ifndef _IDFORM_H
#define _IDFORM_H
Boolean IdFormHandleEvent ( EventType* event );
#endif
