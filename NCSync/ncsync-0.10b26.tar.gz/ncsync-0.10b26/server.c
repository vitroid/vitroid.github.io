/*server form*/
#include <PalmOS.h>
#include "resourceids.h"
#include "prefsdata.h"
#include "const.h"

static void ServerFormInit( void )
{
    FormType*    frm;
    FieldType*   field;
    char*        c;
    
    frm = FrmGetFormPtr( frmServer );
    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, fldServerHost ) );
    c     = Prefs()->serverHost;
    FldInsert( field, c, StrLen( c ) );
    FrmDrawForm( frm );
}

Boolean ServerFormHandleEvent
    (
    EventType* event  /* pointer to an EventType structure */
    )
{
    Boolean     handled;

    handled = false;
    
    switch ( event->eType ) {
    case frmOpenEvent:
	ServerFormInit();
	handled = true;
	break;
    case ctlSelectEvent:
	switch ( event->data.ctlSelect.controlID ){

	case btnServerCancel:
	    FrmReturnToForm( 0 );
	    handled=true;
	    break;

	case btnServerOK:
	{
	    FormPtr      frm;
	    FieldType*   field;
	    char*        word;

	    frm = FrmGetActiveForm ();
	    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, fldServerHost ) );
	    word = FldGetTextPtr( field );
            StrNCopy(Prefs()->serverHost, word, StrLen( word ) );

	    FrmReturnToForm( 0 );
	    handled=true;
	    break;
	}
	default:
	    handled=true;
	    break;
	}
	break;
    case frmCloseEvent:
	handled = false;
	break;
	
    default:
	handled = false;
    }

    return handled;
}
