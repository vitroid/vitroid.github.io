#ifndef NCSYNC_SERVER_H
#define NCSYNC_SERVER_H
extern Boolean ServerFormHandleEvent( EventType* event );

#endif
