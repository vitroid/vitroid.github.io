#ifndef NCSYNC_PROXY_H
#define NCSYNC_PROXY_H
extern Boolean ProxyFormHandleEvent( EventType* event );

#endif
