#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <Unix/sys_socket.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>

#include "SysZLib.h"
#include "log.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

int FileGetC(FileHand fp)
{
  unsigned char lastchr;
  if (1 != FileRead(fp, &lastchr, 1, 1, NULL))
    return -1;
  return lastchr;
}

#define STORED            0     /* compression methods */
#define DEFLATED          8

#  define CRCVAL_INITIAL  0L

/* PKZIP header definitions */
#define ZIPMAG 0x4b50           /* two-byte zip lead-in */
#define LOCREM 0x0403           /* remaining two bytes in zip signature */
#define LOCSIG 0x04034b50L      /* full signature */
#define LOCFLG 4                /* offset of bit flag */
#define  CRPFLG 1               /*  bit for encrypted entry */
#define  EXTFLG 8               /*  bit for extended local header */
#define LOCHOW 6                /* offset of compression method */
#define LOCTIM 8                /* file mod time (for decryption) */
#define LOCCRC 12               /* offset of crc */
#define LOCSIZ 16               /* offset of compressed size */
#define LOCLEN 20               /* offset of uncompressed length */
#define LOCFIL 24               /* offset of file name field length */
#define LOCEXT 26               /* offset of extra field length */
#define LOCHDR 28               /* size of local header, including LOCREM */
#define EXTHDR 16               /* size of extended local header, inc sig */

/* GZIP header definitions */
#define GZPMAG 0x8b1f           /* two-byte gzip lead-in */
#define GZPHOW 0                /* offset of method number */
#define GZPFLG 1                /* offset of gzip flags */
#define  GZPMUL 2               /* bit for multiple-part gzip file */
#define  GZPISX 4               /* bit for extra field present */
#define  GZPISF 8               /* bit for filename present */
#define  GZPISC 16              /* bit for comment present */
#define  GZPISE 32              /* bit for encryption */
#define GZPTIM 2                /* offset of Unix file modification time */
#define GZPEXF 6                /* offset of extra flags */
#define GZPCOS 7                /* offset of operating system compressed on */
#define GZPHDR 8                /* length of minimal gzip header */

/* Macros for getting two-byte and four-byte header values */
#define SH(p) ((unsigned short int)(unsigned char)((p)[0]) | ((unsigned short int)(unsigned char)((p)[1]) << 8))
#define LG(p) ((unsigned long)(SH(p)) | ((unsigned long)(SH((p)+2)) << 16))

/* Globals */

#define ZBSIZ (BSIZ/4)

unsigned char ibuf[BSIZ], obuf[ZBSIZ];



#define fprintf(a,b) ErrDisplay(b)
#define err(n, m) {LogAppend(m);ErrDisplay(m);return n;}

int unzipdir(FileHand ifd, char *dir, long int *loc)
{
  unsigned long total, disp = 0, i=0;
  unsigned short int n;
  unsigned char h[LOCHDR];      /* first local header (GZPHDR < LOCHDR) */
  char *c;
  int max;

  DmSet(dir,0,2,0);
  max = 0;

  FileSeek(ifd, 0, fileOriginBeginning);

  /* read ZIPal header, check validity */
  n = FileGetC(ifd);
  if (n > 255 || FileEOF(ifd))
    return 0;
  n |= FileGetC(ifd) << 8;

  if (n != ZIPMAG)
    return 0;

  for (;;) {
    total = FileTell(ifd,NULL,NULL) - 2L;
    DmWrite(loc,(i++)*4,&total,4);

    FileRead(ifd, (char *) h, 1, LOCHDR, NULL);
    if (SH(h) == 0x0201)
      return max;               // start of central directory
    if (SH(h) != LOCREM)
      err(3, "invalid zipfile.\n");

    /* FILENAME */
    ibuf[SH(h + LOCFIL)] = 0;

    FileRead(ifd, ibuf, 1, SH(h + LOCFIL), NULL);

    for (n = SH(h + LOCEXT); n--;)
      FileGetC(ifd);

    total = LG(h + LOCSIZ);
    c = ibuf;

    DmWrite(dir,disp,"    ",4);
    DmWrite(dir,disp+4,c,StrLen(c)+1);
    disp += 4+StrLen(c)+1;
    DmSet(dir,disp,1,0);

    FileSeek(ifd, total, fileOriginCurrent);

    /* if extended header, get it */
    if ((h[LOCFLG] & EXTFLG) &&
        FileRead(ifd, (char *) h + LOCCRC - 4, 1, EXTHDR, NULL) != EXTHDR)
      err(3, "zipfile ended prematurely.\n");

    max++;

    /* read local header, check validity, and skip name and extra fields */
    n = FileGetC(ifd);
    if (n > 255 || FileEOF(ifd))
      return max;
    n |= FileGetC(ifd) << 8;
    if (n != ZIPMAG)
      return max;
  }
}

/* ************************************************************************ */

int unzip2(FileHand ifd, long int loc,ProgressPtr prg)
{
  FileHand ofd;
  unsigned long crc32val;
  unsigned long outsiz;         /* total bytes written to out */
  int encrypted;                /* flag to turn on decryption */
  unsigned long total, itot;
  unsigned short int n;
  unsigned char h[LOCHDR];      /* first local header (GZPHDR < LOCHDR) */
  int k = 0, got;
  z_stream pgpz;
  int gz = 0;                   /* true if gzip format */
  char *c;
  //RectangleType r;
  DmOpenRef db;
  char message[60];

  FileSeek(ifd, 0, fileOriginBeginning);
  /* read ZIPal header, check validity */
  n = FileGetC(ifd);
  if (n > 255 || FileEOF(ifd))
    return 0;
  n |= FileGetC(ifd) << 8;

  if (n != ZIPMAG && n != GZPMAG)
    return -1;

  total = sizeof(db);
  FileControl(fileOpGetOpenDbRef, ifd, &db, &total);

  FileTell(ifd, &total, NULL);

  if (loc == -1) {
    FileSeek(ifd, 0, fileOriginBeginning);
    FileControl(fileOpDestructiveReadMode, ifd, NULL, NULL);
  } else
    FileSeek(ifd, loc, fileOriginBeginning);

  for (;;) {
      EventType event;
      EvtGetEvent(&event, 0);
      if (!PrgHandleEvent(prg, &event))
	  if (PrgUserCancel(prg)){
	      LogAppend("UserIrq during unzip.\n");
	      return 1;
	  }
    /* read local header, check validity, and skip name and extra fields */
    n = FileGetC(ifd);
    if (n > 255 || FileEOF(ifd))
      return 0;

    n |= FileGetC(ifd) << 8;

    //r.topLeft.x = 0, r.topLeft.y = 15, r.extent.x = 160, r.extent.y = 30;
    //WinEraseRectangle(&r, 0);

    if (n == ZIPMAG) {
      FileRead(ifd, (char *) h, 1, LOCHDR, NULL);
      if (SH(h) == 0x0201)
        return 0;               // start of central directory
      if (SH(h) != LOCREM)
        err(3, "invalid zipfile.\n");
      if (SH(h + LOCHOW) != STORED && SH(h + LOCHOW) != DEFLATED)
        err(3, "entry not deflated or stored--cannot unpack.\n");

      /* FILENAME */
      ibuf[SH(h + LOCFIL)] = 0;
      FileRead(ifd,ibuf, 1, SH(h + LOCFIL), NULL);

      for (n = SH(h + LOCEXT); n--;)
        gz = FileGetC(ifd);
      gz = 0;
      encrypted = h[LOCFLG] & CRPFLG;
    }
    else
      return 1;

    if( !gz )
      total = LG(h + LOCSIZ);
    if (!total) {
      if (loc == -1)
        continue;
      else
        return -1;
    }

    /* fix filename and open for write */
    c = ibuf;
    while (*c) {
      if (*c <= ' ' || *c >= 0x7f)
        *c = '_';
      c++;
    }
    c = ibuf;
    if (StrLen(ibuf) >= 32)
      c += StrLen(ibuf) - 31;
    c[31] = 0;
    ofd = FileOpen(0, c, 'DATA', 'BOXR', fileModeReadWrite, NULL);
    //WinDrawChars(c, StrLen(c), 3, 15);
    if( !ofd )
      return -1;

    /* if entry encrypted, decrypt and validate encryption header */
    if (encrypted)
      err(3, "cannot decrypt entry (need to recompile with full crypt.c).\n");

    itot = total;
    //StrPrintF(prgstr,"%dkB %s",total/1024,c);
    //StrPrintF(message,"%ldkB",total/1024L);

    outsiz = 0L;
    crc32val = CRCVAL_INITIAL;

    //r.topLeft.y = 30, r.extent.y = 15;

    /* decompress */
    if (gz || h[LOCHOW]) {      /* deflated entry */
	/*TYPICALLY USED IN NEWSCLIP*/
	StrCopy(message,"Inflating...\n");
	StrCat(message,c);
	PrgUpdateDialog(prg,0,0,message,true);
	outsiz = 0;
	MemSet(&pgpz, sizeof(pgpz), 0 );
	ZLSetup;
	inflateInit2(&pgpz, -15);
	
	while (total && !FileEOF(ifd)) {
	    
	    if (0 > (got = FileRead(ifd, ibuf, 1, total > BSIZ ? BSIZ : total, NULL)))
		break;
	    
	    total -= got;
	    
	    pgpz.next_in = ibuf;
	    pgpz.avail_in = got;
	    while (pgpz.avail_in || !total || FileEOF(ifd) ) {
		pgpz.next_out = obuf;
		pgpz.avail_out = ZBSIZ;
		k = inflate(&pgpz, !total || !FileEOF(ifd) ? 0 : Z_FINISH);
		/* SHOULD CHECK FOR ERRORS */
		FileWrite(ofd, obuf, 1, ZBSIZ - pgpz.avail_out, NULL);
		outsiz += ZBSIZ - pgpz.avail_out;
		crc32val = crc32(crc32val, obuf, ZBSIZ - pgpz.avail_out);
		
		if (k == Z_BUF_ERROR && pgpz.avail_out != ZBSIZ
		    && (total || FileEOF(ifd) ) )  continue; /* for undoc zlib */
		if (k != Z_OK)
		    break;
	    }
	}
	inflateEnd(&pgpz);
	
	//error status:       (k == Z_STREAM_END);
    } else {                      /* stored entry */
	/*This causes fatexp*/
	StrCopy(message,"Extracting...\n");
	StrCat(message,c);
	PrgUpdateDialog(prg,0,0,message,true);
	ZLSetup;
	got = LG(h + LOCLEN);
	if (got != LG(h + LOCSIZ))
	    err(4, "invalid compressed data--length mismatch.\n");
	total = got;
	while (total) {
	    got = FileRead(ifd, ibuf, 1, total > BSIZ ? BSIZ : total, NULL);
	    outsiz += got;
	    total -= got;
	    crc32val = crc32(crc32val, ibuf, got);
	    
	    FileWrite(ofd, ibuf, 1, got, NULL);
	}
    }
    FileClose(ofd);
    EvtResetAutoOffTimer();

    /* if extended header, get it */
    if (gz) {
      if (pgpz.avail_in < 8)
        err(3, "gzip ended prematurely.\n");
      MemMove((char *) h + LOCCRC, pgpz.next_in, 8);

      break;                    //THIS DOESN'T WORK HERE
    }
      else
      if ((h[LOCFLG] & EXTFLG) &&
          FileRead(ifd, (char *) h + LOCCRC - 4, 1, EXTHDR, NULL) != EXTHDR)
        err(3, "zipfile ended prematurely.\n");

    /* validate decompression */
    if (LG(h + LOCCRC) != crc32val)
      err(4, "invalid compressed data--crc error.\n");

    if (LG((gz ? (h + LOCSIZ) : (h + LOCLEN))) != outsiz)
      err(4, "invalid compressed data--length error.\n");

    if (loc != -1)
      break;

  }
  return 0;
}
