#include <PalmOS.h>
#include "freearea.h"
/*
 *$B8=:_$N6u$-%a%b%jMFNL$rJV$9(B
 *$B$[$7$5$s$N(Bpz$B$N%3!<%I$r$=$N$^$^;HMQ(B
 */
#ifndef memHeapFlagReadOnly
#define memHeapFlagReadOnly 0x0001	/* heap is read-only (ROM based) */
#endif
#define DEFAULT_CARD_NO 0
UInt32 FreeArea()
{
  UInt16 num_heaps, i, heap_id;
  UInt32 total, free, max;

  total = 0;
  num_heaps = MemNumHeaps(DEFAULT_CARD_NO);
  for (i = 0; i < num_heaps; ++i) {
    heap_id = MemHeapID(DEFAULT_CARD_NO, i);
    if (MemHeapDynamic(heap_id) == false
	&& (MemHeapFlags(heap_id) & memHeapFlagReadOnly) == 0) {
      MemHeapFreeBytes(heap_id, &free, &max);
      total += free;
    }
  }
  return total;
}
