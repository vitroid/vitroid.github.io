/*proxy form*/
#include <PalmOS.h>
#include "resourceids.h"
#include "prefsdata.h"
#include "const.h"

static void ProxyFormInit( void )
{
    FormType*    frm;
    FieldType*   field;
    ControlType* ctl;
    char*        c;
    char         port[10];
    
    frm = FrmGetFormPtr( frmProxy );
    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, fldProxyHost ) );
    c     = Prefs()->proxyHost;
    FldInsert( field, c, StrLen( c ) );
    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, fldProxyPort ) );
    StrPrintF( port, "%d", Prefs()->proxyPort );
    FldInsert( field, port, StrLen( port ) );
    //set checkboxes
    ctl = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, chkProxyUse ) );
    CtlSetValue( ctl, Prefs()->useProxy );
    FrmDrawForm( frm );
}

Boolean ProxyFormHandleEvent
    (
    EventType* event  /* pointer to an EventType structure */
    )
{
    Boolean     handled;

    handled = false;
    
    switch ( event->eType ) {
    case frmOpenEvent:
	ProxyFormInit();
	handled = true;
	break;
    case ctlSelectEvent:
	switch ( event->data.ctlSelect.controlID ){

	case btnProxyCancel:
	    FrmReturnToForm( 0 );
	    handled=true;
	    break;

	case btnProxyOK:
	{
	    FormPtr      frm;
	    FieldType*   field;
            ControlType* ctl;
	    char*        word;

	    frm = FrmGetActiveForm ();
	    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, fldProxyHost ) );
	    word = FldGetTextPtr( field );
            StrNCopy(Prefs()->proxyHost, word, StrLen( word ) );

	    field = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, fldProxyPort ) );
	    Prefs()->proxyPort = StrAToI( FldGetTextPtr( field ) );

            ctl = FrmGetObjectPtr( frm, FrmGetObjectIndex( frm, chkProxyUse ) );
            Prefs()->useProxy = CtlGetValue( ctl );

	    FrmReturnToForm( 0 );
	    handled=true;
	    break;
	}
	default:
	    handled=true;
	    break;
	}
	break;
    case frmCloseEvent:
	handled = false;
	break;
	
    default:
	handled = false;
    }

    return handled;
}
