#include <PalmOS.h>
#include <FeatureMgr.h>
#include <MemoryMgr.h>
#include <SoundMgr.h>
#include <Clipboard.h>
#include <TextMgr.h>
#include <DataMgr.h>
#include "const.h"
#include "http.h"
#include "memourl.h"
#include "log.h"
#include "prefsdata.h"

#define NCSYNC_PREFIX     "newsclip:"
#define NCSYNC_PREFIX_LEN 9

DmOpenRef MemoUrlOpenDatabase()
{
    DmOpenRef ref = DmOpenDatabaseByTypeCreator( DBType, appFileCreator, dmModeReadWrite );
    /*
    if ( ref == NULL ){
        //create
        Int16 cardNo = 0;
        dbERR = DmCreateDatabase( cardNo, MEMOURL_DBNAME, appFileCreator, DBType, false);
        if(dbERR == errNone) {
            ref = DmOpenDatabaseByTypeCreator( DBType, appFileCreator, dmModeReadWrite );
        }
        else {
            ref = NULL;
            FrmAlert ( AlertCannotOpenDB );
        }
    }
    */
    return ref;
}


/*
 * scan ncsync URL
 */
Int32 GetNextNCSyncURL( DmOpenRef UrlDB, Int16* record )
{
    Int32 channelId=0;
    Int16 numRecords = DmNumRecords( UrlDB );
    
    while ( 0 == channelId && *record < numRecords ){
        MemHandle recHdl = DmQueryRecord( UrlDB, *record );
        if ( 0 == recHdl ){
            //finished
            //LogAppend( "Finished.\n" );
            return 0;
        }
        else{
            //char msg[100];
            MemPtr recPtr;
            BookmarkRec* bookmark;
            //lock and get MemoURL record
            recPtr = MemHandleLock( recHdl );
            bookmark = recPtr;
            //StrPrintF( msg, "openType: %d\n", bookmark->openType );
            //LogAppend( msg );
            
            // if the url is active
            if ( bookmark->openType != OPENTYPE_NONE ){
                Int16 length;
                recPtr += 2 * sizeof(Int16);
                length =  StrLen( recPtr );
                //if url is long enough
                //StrPrintF( msg, "length: %d\n", length );
                //LogAppend( msg );
                if ( 7 <= length ){
                    //if id matches
                    LogAppend( recPtr );
                    LogAppend( ":" );
                    if ( StrNCompare( NCSYNC_PREFIX, recPtr, NCSYNC_PREFIX_LEN ) == 0 ){
                        recPtr += NCSYNC_PREFIX_LEN;
                        channelId = StrAToI( recPtr );
                        //if strange string is given, channelId becomes 0
                        //StrPrintF( msg, "Ch: %ld ", channelId );
                        //LogAppend( msg );
                        //LogAppend( "Accept\n" );
                    }
                    else{
                        //LogAppend( "Reject\n" );
                    }
                    
                }
            }
            MemHandleUnlock( recHdl );
            *record += 1;
        }
    }
    return channelId;
}



/*
 * scan ncsync URL
 */
void InactivateEntriesInMemoURLDB( )
{
    DmOpenRef UrlDB;
    //MemoURL�򥹥���󤷤ƥ��ޥ�ɤ��ɲä��롣
    UrlDB = MemoUrlOpenDatabase();
    LogAppend( "OpenDB " );
    
    if ( NULL != UrlDB ){
        Int16 record = 1;
        Int16 numRecords = DmNumRecords( UrlDB );
        LogAppend( "OK " );
    
        while ( record < numRecords ){
            MemHandle recHdl = DmGetRecord( UrlDB, record );
            if ( 0 == recHdl ){
                LogAppend( "finished. " );
                break;
            }
            else{
                MemPtr recPtr;
                BookmarkRec* bookmark;
                //lock and get MemoURL record
                LogAppend( "Lock " );
                recPtr = MemHandleLock( recHdl );
                bookmark = recPtr;
                // if the url is active
                if ( bookmark->openType != OPENTYPE_NONE ){
                    Int16 length;
                    length =  StrLen( recPtr + 4 );
                    //if url is long enough
                    if ( 7 <= length ){
                        //if id matches
                        if ( StrNCompare( NCSYNC_PREFIX, recPtr + 4, NCSYNC_PREFIX_LEN ) == 0 ){
                            Int16 openType = OPENTYPE_NONE;
                            DmWrite( recPtr, 2, &openType, sizeof(openType) );
                        }
                    }
                }
                MemHandleUnlock( recHdl );
                DmReleaseRecord( UrlDB, record, true );
                record ++;
            }
        }

        DmCloseDatabase( UrlDB );
    }
}







//scan MemoURL DB, return whether there are subscriptions.
Boolean RequireSubscription()
{
    Boolean result=false;
    DmOpenRef ref;
    
    ref = MemoUrlOpenDatabase();
    LogAppend( "Try Open " );
    if ( NULL != ref ){
        Int16 record = 1;
        //Scan MemoURL DB and if there is a new subscription,
        LogAppend( "DB Opened" );
        result = ( 0 != GetNextNCSyncURL( ref, &record ) );
        if ( result )
            LogAppend( " OK" );
        LogAppend( "\n" );
        DmCloseDatabase( ref );
    }
    return result;
}


void ComposeSubscriptionCommands( Char* command )
{
    DmOpenRef ref;
    //MemoURL�򥹥���󤷤ƥ��ޥ�ɤ��ɲä��롣
    ref = MemoUrlOpenDatabase();
    if ( NULL != ref ){
        Int16 commandLen = COMMAND_LEN_MAX - StrLen( command ) - 1;
        Int16 record = 1;
        Int32 channelId;
        
        while( ( 0 != ( channelId = GetNextNCSyncURL( ref, &record ) ) ) &&
               ( 10 < commandLen ) ){
            char add[10];
            if ( 0 < channelId ){
                //subscribe
                StrPrintF( add, "&c%05ld=1", channelId );
            }
            else{
                //unsubscribe
                StrPrintF( add, "&d%05ld=1", -channelId );
            }
            StrCat( command, add );
            commandLen -= StrLen( add );
        }
        DmCloseDatabase( ref );
    }
}



Boolean callbackSubscription(PrgCallbackDataPtr cbP)
{
    StrCopy(cbP->textP, "Subscribing ");
    StrCat(cbP->textP, cbP->message);
    cbP->textChanged = true;
    return true;
}



int Subscribe()
{
    ProgressPtr prg=NULL;
#if 0
    PrgCallbackData data;
    char message[100];
#endif
    char command[COMMAND_LEN_MAX];
    int err=0;

    /* compose command string */
    StrCopy(command,CGINAME "?id=");
    StrCat(command,Prefs()->permanentID1);
    StrCat(command,"-");
    StrCat(command,Prefs()->permanentID2);
    StrCat(command,"-");
    StrCat(command,Prefs()->permanentID3);
    ComposeSubscriptionCommands( command );

    /* begin progress dialog */
#if 0
    prg = PrgStartDialog("Subscription", callbackSubscription, &data);
#endif
    LogAppend("Start subscription.\n");
    LogAppend("command:");
    LogAppend(command);
    LogAppend("\n");
#if 0
    StrCopy( message, "Subscribing..." );
    PrgUpdateDialog(prg, 0, -1, message, true);
#endif

    /* put command over http */
    err = GetURL2( Prefs()->serverHost, command, IGNORE_LENGTH, false, prg);

    /* show result */
    if(err){
	LogAppend("Subscription failed.\n");
    }
#if 0
    PrgStopDialog( prg, false );
#endif
    return err;
}



